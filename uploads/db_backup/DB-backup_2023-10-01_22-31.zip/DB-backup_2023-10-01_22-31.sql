#
# TABLE STRUCTURE FOR: accounts
#

DROP TABLE IF EXISTS `accounts`;

CREATE TABLE `accounts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `balance` double(18,2) NOT NULL DEFAULT 0.00,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: addon
#

DROP TABLE IF EXISTS `addon`;

CREATE TABLE `addon` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `prefix` varchar(255) NOT NULL,
  `version` varchar(100) NOT NULL,
  `purchase_code` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: advance_salary
#

DROP TABLE IF EXISTS `advance_salary`;

CREATE TABLE `advance_salary` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `deduct_month` varchar(20) DEFAULT NULL,
  `year` varchar(20) NOT NULL,
  `reason` text CHARACTER SET utf32 COLLATE utf32_unicode_ci DEFAULT NULL,
  `request_date` datetime DEFAULT NULL,
  `paid_date` varchar(20) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '1=pending,2=paid,3=rejected',
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `issued_by` varchar(200) DEFAULT NULL,
  `comments` varchar(255) DEFAULT NULL,
  `branch_id` int(11) DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: attachments
#

DROP TABLE IF EXISTS `attachments`;

CREATE TABLE `attachments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `remarks` text NOT NULL,
  `type_id` int(11) NOT NULL,
  `uploader_id` varchar(20) NOT NULL,
  `class_id` varchar(20) DEFAULT 'unfiltered',
  `file_name` varchar(255) NOT NULL,
  `enc_name` varchar(255) NOT NULL,
  `subject_id` varchar(200) DEFAULT 'unfiltered',
  `session_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: attachments_type
#

DROP TABLE IF EXISTS `attachments_type`;

CREATE TABLE `attachments_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: award
#

DROP TABLE IF EXISTS `award`;

CREATE TABLE `award` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) DEFAULT NULL,
  `gift_item` varchar(255) NOT NULL,
  `award_amount` decimal(18,2) NOT NULL,
  `award_reason` text NOT NULL,
  `given_date` date NOT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: book
#

DROP TABLE IF EXISTS `book`;

CREATE TABLE `book` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `cover` varchar(255) DEFAULT NULL,
  `author` varchar(255) NOT NULL,
  `isbn_no` varchar(255) NOT NULL,
  `category_id` int(11) NOT NULL,
  `publisher` varchar(255) NOT NULL,
  `edition` varchar(255) NOT NULL,
  `purchase_date` date NOT NULL,
  `description` text NOT NULL,
  `price` decimal(18,2) NOT NULL,
  `total_stock` varchar(20) NOT NULL,
  `issued_copies` varchar(20) NOT NULL DEFAULT '0',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: book_category
#

DROP TABLE IF EXISTS `book_category`;

CREATE TABLE `book_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: book_issues
#

DROP TABLE IF EXISTS `book_issues`;

CREATE TABLE `book_issues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `book_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `date_of_issue` date DEFAULT NULL,
  `date_of_expiry` date DEFAULT NULL,
  `return_date` date DEFAULT NULL,
  `fine_amount` decimal(18,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 = pending, 1 = accepted, 2 = rejected, 3 = returned',
  `issued_by` varchar(255) DEFAULT NULL,
  `return_by` int(11) DEFAULT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: branch
#

DROP TABLE IF EXISTS `branch`;

CREATE TABLE `branch` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `school_name` varchar(255) NOT NULL,
  `email` varchar(100) NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `currency` varchar(100) NOT NULL,
  `symbol` varchar(25) NOT NULL,
  `city` varchar(255) NOT NULL,
  `state` varchar(255) NOT NULL,
  `address` text NOT NULL,
  `stu_generate` tinyint(3) NOT NULL DEFAULT 0,
  `stu_username_prefix` varchar(255) NOT NULL,
  `stu_default_password` varchar(255) NOT NULL,
  `grd_generate` tinyint(3) NOT NULL DEFAULT 0,
  `grd_username_prefix` varchar(255) NOT NULL,
  `grd_default_password` varchar(255) NOT NULL,
  `teacher_restricted` tinyint(1) DEFAULT 1,
  `due_days` float NOT NULL DEFAULT 30,
  `due_with_fine` tinyint(4) NOT NULL DEFAULT 1,
  `translation` varchar(255) NOT NULL DEFAULT 'english',
  `timezone` varchar(255) NOT NULL,
  `weekends` varchar(255) NOT NULL DEFAULT '0',
  `reg_prefix_enable` tinyint(1) NOT NULL DEFAULT 0,
  `reg_start_from` tinyint(4) NOT NULL DEFAULT 1,
  `institution_code` varchar(100) DEFAULT NULL,
  `reg_prefix_digit` int(11) NOT NULL,
  `offline_payments` tinyint(1) NOT NULL DEFAULT 1,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `unique_roll` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `branch` (`id`, `name`, `school_name`, `email`, `mobileno`, `currency`, `symbol`, `city`, `state`, `address`, `stu_generate`, `stu_username_prefix`, `stu_default_password`, `grd_generate`, `grd_username_prefix`, `grd_default_password`, `teacher_restricted`, `due_days`, `due_with_fine`, `translation`, `timezone`, `weekends`, `reg_prefix_enable`, `reg_start_from`, `institution_code`, `reg_prefix_digit`, `offline_payments`, `status`, `unique_roll`, `created_at`, `updated_at`) VALUES (1, 'Mirpur Branch', 'রূপনগর আবাসিক হাই স্কুল', 'info@elitedesign.com.bd', '01775457008', 'BDT', 'TK', 'Lalmonir Hat', 'LH', 'House: Munshi Bari, Beside Nayar Hat High School, Borobari', 1, '3', '12345678', 1, '3', '12345678', 1, '30', 1, 'english', 'Pacific/Midway', '5', 1, 1, 'RAHS-89', 6, 1, 1, 1, '2023-09-22 04:09:27', NULL);


#
# TABLE STRUCTURE FOR: bulk_msg_category
#

DROP TABLE IF EXISTS `bulk_msg_category`;

CREATE TABLE `bulk_msg_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `body` longtext NOT NULL,
  `type` tinyint(4) NOT NULL COMMENT 'sms=1, email=2',
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: bulk_sms_email
#

DROP TABLE IF EXISTS `bulk_sms_email`;

CREATE TABLE `bulk_sms_email` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `campaign_name` varchar(255) DEFAULT NULL,
  `sms_gateway` varchar(55) DEFAULT '0',
  `message` text DEFAULT NULL,
  `email_subject` varchar(255) DEFAULT NULL,
  `message_type` tinyint(3) DEFAULT 0 COMMENT 'sms=1, email=2',
  `recipient_type` tinyint(3) NOT NULL COMMENT 'group=1, individual=2, class=3',
  `recipients_details` longtext DEFAULT NULL,
  `additional` longtext DEFAULT NULL,
  `schedule_time` datetime DEFAULT NULL,
  `posting_status` tinyint(3) NOT NULL COMMENT 'schedule=1,competed=2',
  `total_thread` int(11) NOT NULL,
  `successfully_sent` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: call_log
#

DROP TABLE IF EXISTS `call_log`;

CREATE TABLE `call_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  `purpose_id` int(11) DEFAULT NULL,
  `call_type` tinyint(1) DEFAULT NULL,
  `date` date NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `follow_up` date DEFAULT NULL,
  `note` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: call_purpose
#

DROP TABLE IF EXISTS `call_purpose`;

CREATE TABLE `call_purpose` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: card_templete
#

DROP TABLE IF EXISTS `card_templete`;

CREATE TABLE `card_templete` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `card_type` tinyint(1) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  `user_type` tinyint(1) NOT NULL,
  `background` varchar(355) DEFAULT NULL,
  `logo` varchar(355) DEFAULT NULL,
  `signature` varchar(255) DEFAULT NULL,
  `content` text NOT NULL,
  `layout_width` varchar(11) NOT NULL DEFAULT '54',
  `layout_height` varchar(11) NOT NULL DEFAULT '86',
  `photo_style` tinyint(1) NOT NULL,
  `photo_size` varchar(25) NOT NULL,
  `top_space` varchar(25) NOT NULL,
  `bottom_space` varchar(25) NOT NULL,
  `right_space` varchar(25) NOT NULL,
  `left_space` varchar(25) NOT NULL,
  `qr_code` varchar(25) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `card_templete` (`id`, `card_type`, `name`, `user_type`, `background`, `logo`, `signature`, `content`, `layout_width`, `layout_height`, `photo_style`, `photo_size`, `top_space`, `bottom_space`, `right_space`, `left_space`, `qr_code`, `branch_id`, `created_at`) VALUES (1, 1, 'Templete1', 1, 'id-card.jpg', '1678711200-1182916080640f19a0e94f8!1.png', 'Oprah-Winfrey-Signature-1.png', '<div style=\"line-height: 1.5;\"><div style=\"line-height: 1.6;\"></div><div style=\"text-align: center; line-height: 1.4;\"><br><b>{institute_name}</b><br></div><div style=\"text-align: center; line-height: 1;\"><br></div><div style=\"text-align: center;\">{student_photo}</div><div style=\"text-align: center;\"><br></div><div style=\"text-align: center; line-height: 1.5;\">Name : {name}</div><div style=\"text-align: center; line-height: 1.5;\">Class : {class}</div><div style=\"text-align: center; line-height: 1.5;\">Roll : {roll}</div><div style=\"text-align: center; line-height: 1.5;\">Father Name : {father_name} <br></div><div style=\"text-align: center; line-height: 1.5;\">DOB : {birthday}</div><div style=\"text-align: center; line-height: 1.5;\"> {qr_code} <br></div><div style=\"text-align: center;\"><br></div></div>', '60.452', '96.856', 2, '90', '20', '20', '12', '12', 'register_no', 1, '2023-09-22 09:58:06');
INSERT INTO `card_templete` (`id`, `card_type`, `name`, `user_type`, `background`, `logo`, `signature`, `content`, `layout_width`, `layout_height`, `photo_style`, `photo_size`, `top_space`, `bottom_space`, `right_space`, `left_space`, `qr_code`, `branch_id`, `created_at`) VALUES (2, 1, 'Templete 2', 2, 'id-card1.jpg', '', 'Oprah-Winfrey-Signature-11.png', '<div style=\"line-height: 1.5;\"><div style=\"line-height: 1.6;\"></div><div style=\"text-align: center; line-height: 1.4;\"><br><b>{institute_name}</b><br></div><div style=\"text-align: center; line-height: 1;\"><br></div><div style=\"text-align: center;\">{staff_photo}</div><div style=\"text-align: center;\"><br></div><div style=\"text-align: center; line-height: 1.5;\">Name : {name}</div><div style=\"text-align: center; line-height: 1.5;\">Designation: {designation}</div><div style=\"text-align: center; line-height: 1.5;\">Blood Group : {blood_group}</div><div style=\"text-align: center; line-height: 1.5;\">Joining Date : {joining_date} <br></div><div style=\"text-align: center; line-height: 1.5;\">DOB : {birthday}</div><div style=\"text-align: center; line-height: 1.5;\"> {qr_code} <br></div><div style=\"text-align: center;\"><br></div></div>', '60.452', '96.856', 2, '90', '20', '20', '12', '12', 'staff_id', 1, '2023-09-22 10:07:09');
INSERT INTO `card_templete` (`id`, `card_type`, `name`, `user_type`, `background`, `logo`, `signature`, `content`, `layout_width`, `layout_height`, `photo_style`, `photo_size`, `top_space`, `bottom_space`, `right_space`, `left_space`, `qr_code`, `branch_id`, `created_at`) VALUES (3, 2, 'Exam Admit Card', 1, 'admit-card.jpg', '1678711200-1182916080640f19a0e94f8!12.png', 'Oprah-Winfrey-Signature-13.png', '<div style=\"text-align: center;\"><b><span style=\"font-size: 28px;\">{institute_name}</span><span style=\"font-size: 28px;\"></span></b></div><div style=\"text-align: center;\">{institute_email} | {mobileno} </div><div style=\"text-align: center;\">{institute_address}</div><div style=\"text-align: center;\">{student_photo}                                                                                {qr_code} </div><div style=\"text-align: center;\"><span style=\"font-size: 18px;\"><b><br></b></span></div><div style=\"text-align: center;\"><span style=\"font-size: 18px;\"><b>ADMIT CARD  FIRST TERM EXAMINATION-2020</b></span></div><div style=\"text-align: center;\"><span style=\"font-size: 18px;\"><b><br></b></span></div><table class=\"table table-bordered table-condensed mb-none\"><tbody><tr><td><b>Student Name: </b>{name}<br></td><td><b>Exam Name: </b>{exam_name}<br></td></tr><tr><td><b>Father\'s Name: </b>{father_name}<br></td><td><b>Class: </b>{class}<br></td></tr><tr><td><b>Gender: </b>{gender}<br></td><td><b>Roll:</b> {roll}<br></td></tr><tr><td><b>Date Of Birth: </b>{birthday}<br></td><td><b>Admission On:</b> {admission_date}<br></td></tr><tr><td><b>Email: </b>{email}<br></td><td><b>Student Group: </b>{category}<br></td></tr><tr><td><b>Contact No: </b>{mobileno}<br></td><td><b>Blood Group</b>: {blood_group} <br></td></tr></tbody></table><div style=\"text-align: center;\"><br><div style=\"text-align: left; \"><b>Subject Details :</b></div><div style=\"text-align: left; \"> {subject_list_table} </div><div style=\"\">Date of Publication of  Admit card : {print_date}                                                   Principal Signature</div><div style=\"\">                                                                                                                         {signature} <br></div></div>', '210', '297', 1, '100', '80', '80', '80', '90', 'register_no', 1, '2023-09-22 10:13:01');


#
# TABLE STRUCTURE FOR: certificates_templete
#

DROP TABLE IF EXISTS `certificates_templete`;

CREATE TABLE `certificates_templete` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `user_type` tinyint(1) NOT NULL,
  `background` varchar(355) DEFAULT NULL,
  `logo` varchar(355) DEFAULT NULL,
  `signature` varchar(255) NOT NULL,
  `content` text NOT NULL,
  `page_layout` tinyint(1) NOT NULL,
  `photo_style` tinyint(1) NOT NULL,
  `photo_size` varchar(25) NOT NULL,
  `top_space` varchar(25) NOT NULL,
  `bottom_space` varchar(25) NOT NULL,
  `right_space` varchar(25) NOT NULL,
  `left_space` varchar(25) NOT NULL,
  `qr_code` varchar(25) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `certificates_templete` (`id`, `name`, `user_type`, `background`, `logo`, `signature`, `content`, `page_layout`, `photo_style`, `photo_size`, `top_space`, `bottom_space`, `right_space`, `left_space`, `qr_code`, `branch_id`, `created_at`) VALUES (1, 'SCHOOL CERTIFICATE (QR & Logo)', 1, 'certificate1.jpg', '1678711200-1182916080640f19a0e94f8!11.png', 'Oprah-Winfrey-Signature-12.png', '<p></p><div style=\"text-align: center;\"><b><span style=\"font-size: 28px;\">{institute_name}</span><span style=\"font-size: 28px;\"> </span></b></div><div style=\"text-align: center;\">{institute_email} | {mobileno} </div><div style=\"text-align: center;\">{institute_address}</div><div style=\"text-align: center;\"><br></div><div style=\"text-align: center;\"><b>Registration No</b>: {register_no}                                                {logo}                                         <b>Admission On</b>: {admission_date}</div><div style=\"text-align: center;\"><br></div><div style=\"text-align: center;\"><span style=\"font-size: 24px;\"><b>SCHOOL CERTIFICATE EXAMINATION-2020</b></span></div><div style=\"text-align: center; line-height: 1.2;\"><span style=\"font-size: 24px;\"><b><br></b></span><div style=\"line-height: 1.2;\"><font face=\"Pinyon Script\"><span style=\"font-size: 28px;\">This Is To Certify That  <b>{name} </b>And Of He/she Is Gender As <b>{gender}</b> Son/daughter Of  <b>{father_name}</b> & <b>{mother_name}</b> Of <b>{institute_name}</b> And <b>{institute_address}</b> Bearing Roll- <b>{roll} </b>& Exam Center Campus-04 And Class <b>{class} </b>Dulg Passed The Final</span></font></div><div style=\"line-height: 1.2;\"><font face=\"Pinyon Script\"><span style=\"font-size: 28px;\">school Certificate Examination Of 2020  <b>{category}</b>  And His/her Date Of Birth As Recorded Is <b>{birthday}</b> Obtained  G.p.a <b>4.94</b> In The Scale Of <b>5.00</b>.</span></font></div><div style=\"line-height: 1.2;\"><span style=\"font-size: 14px;\"><font face=\"Arial\"><br></font></span></div><div style=\"line-height: 1.2;\"><span style=\"font-size: 14px;\"><font face=\"Arial\"><br></font></span></div><div style=\"line-height: 1.2;\"><span style=\"font-size: 14px;\"><font face=\"Arial\">Date of Publication of Result: {print_date}                                                                                                                       </font></span> {qr_code} </div><div style=\"line-height: 1.2;\">                                                                                                                                                                                          <span style=\"font-family: Arial;\"><br></span></div><div style=\"line-height: 1.2;\"><font face=\"Arial\">                                             <br></font><br></div></div><p></p>', 2, 1, '100', '80', '80', '80', '80', 'register_no', 1, '2023-09-22 11:20:11');
INSERT INTO `certificates_templete` (`id`, `name`, `user_type`, `background`, `logo`, `signature`, `content`, `page_layout`, `photo_style`, `photo_size`, `top_space`, `bottom_space`, `right_space`, `left_space`, `qr_code`, `branch_id`, `created_at`) VALUES (2, 'EXPRIENCES CERTIFICATE FOR EMPLOYEE', 2, 'certificate-2.jpg', '1678711200-1182916080640f19a0e94f8!13.png', 'Oprah-Winfrey-Signature-14.png', '<div style=\"box-sizing: border-box; text-indent: 0px; text-decoration-style: initial; text-decoration-color: initial; text-align: center; line-height: 1.4;\"><div style=\"line-height: 1.4;\"><span style=\"font-size: 18px;\">{institute_name}</span><span style=\"font-size: 18px;\">&nbsp;</span></div><div style=\"line-height: 1.4;\"><span style=\"font-size: 18px;\">{institute_email} | {mobileno}&nbsp;</span></div><div style=\"line-height: 1.4;\"><span style=\"font-size: 18px;\">{institute_address}</span></div></div><p><br></p><div style=\"box-sizing: border-box; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-size: 14px; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; orphans: 2; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial; text-align: center;\"><span style=\"font-weight: 400;\"><b style=\"font-style: normal;\">Staff ID&nbsp;</b>: <i>{staff_id}&nbsp;</i> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; {staff_photo} &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;&nbsp; </span><b style=\"font-style: normal;\">Joining Date&nbsp;:</b> <i>{joining_date}&nbsp;&nbsp;<br style=\"box-sizing: border-box;\"></i></div><div style=\"box-sizing: border-box; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial; text-align: center;\"><br></div><div style=\"box-sizing: border-box; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; font-weight: 400; letter-spacing: normal; orphans: 2; text-indent: 0px; text-transform: none; white-space: normal; widows: 2; word-spacing: 0px; -webkit-text-stroke-width: 0px; text-decoration-style: initial; text-decoration-color: initial; text-align: center;\"><span style=\"box-sizing: border-box; font-size: 24px;\"><b style=\"box-sizing: border-box; font-weight: bold;\">EXPRIENCES CERTIFICATE OF ACHIVEMENT</b></span></div><div style=\"box-sizing: border-box; orphans: 2; text-indent: 0px; widows: 2; text-decoration-style: initial; text-decoration-color: initial; text-align: center; line-height: 1.2;\"><div style=\"text-align: justify;\"><span style=\"font-size: 24px;\"><b><br></b></span></div><div style=\"text-align: center; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; box-sizing: border-box; line-height: 1.2;\"><font style=\"box-sizing: border-box;\" face=\"Pinyon Script\"><span style=\"box-sizing: border-box; font-size: 28px;\"><span style=\"font-size: 24px;\"><b>This Is To Certify That</b>&nbsp;&nbsp;</span><span style=\"box-sizing: border-box;\"><span style=\"font-size: 24px;\">{name}<b>&nbsp;</b></span></span><span style=\"font-weight: bold; font-size: 24px;\">And Of He/she Is Gender As&nbsp;</span><span style=\"box-sizing: border-box;\"><span style=\"font-size: 24px;\">{gender}<b> &amp;</b></span></span><span style=\"font-weight: bold; box-sizing: border-box;\"><span style=\"font-size: 24px;\"> </span></span><span style=\"font-weight: bold; box-sizing: border-box;\"><span style=\"font-size: 24px;\">permanent resident of</span></span></span></font><span style=\"font-weight: bold; font-size: 24px;\">&nbsp;</span> <font style=\"\" face=\"Pinyon Script\"><span style=\"font-size: 24px;\">{permanent_address} </span></font><span style=\"font-weight: bold; box-sizing: border-box;\"><span style=\"font-size: 24px;\">&nbsp;</span></span><font style=\"font-weight: bold; box-sizing: border-box;\" face=\"Pinyon Script\"><span style=\"box-sizing: border-box; font-size: 24px;\"> and he/she is the</span></font><span style=\"font-weight: bold; font-size: 24px;\">&nbsp;</span><span style=\"box-sizing: border-box; font-size: 24px;\"><font style=\"box-sizing: border-box;\" face=\"Parisienne\"><span style=\"box-sizing: border-box;\">{designation}</span></font></span><span style=\"font-weight: bold; font-size: 24px;\">&nbsp;</span><font style=\"box-sizing: border-box;\" face=\"Parisienne\"><span style=\"box-sizing: border-box; font-size: 28px;\"><span style=\"font-weight: bold; font-size: 24px;\">of</span><span style=\"font-weight: bold; font-size: 24px;\">&nbsp;</span><span style=\"box-sizing: border-box;\"><span style=\"font-size: 24px;\">{department}</span></span><span style=\"font-weight: bold; font-size: 24px;\">&nbsp;</span><span style=\"font-weight: bold; font-size: 24px;\">department.</span></span></font><font style=\"font-weight: bold; box-sizing: border-box;\" face=\"Pinyon Script\"><span style=\"box-sizing: border-box; font-size: 24px;\">&nbsp;</span></font></div><div style=\"text-align: center; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; box-sizing: border-box; line-height: 1.2;\"><font style=\"font-weight: bold; box-sizing: border-box;\" face=\"Pinyon Script\"><span style=\"box-sizing: border-box; font-size: 24px;\">He/she worked as</span></font><font style=\"font-weight: bold; box-sizing: border-box;\" face=\"Parisienne\"><span style=\"box-sizing: border-box; font-size: 28px;\"><span style=\"font-size: 24px;\"><font face=\"Pinyon Script\"> </font></span></span></font><font style=\"\" face=\"Pinyon Script\"><span style=\"font-size: 28px;\"> <span style=\"font-size: 24px;\">{designation}</span></span></font><b>&nbsp; </b><font style=\"font-weight: bold; box-sizing: border-box;\" face=\"Parisienne\"><span style=\"box-sizing: border-box; font-size: 28px;\"><span style=\"font-size: 24px;\">in</span><span style=\"font-size: 24px;\">&nbsp;</span></span></font><font style=\"box-sizing: border-box;\" face=\"Pinyon Script\"><span style=\"box-sizing: border-box; font-size: 28px;\"><span style=\"font-weight: bold; font-size: 24px;\">&nbsp;</span><span style=\"box-sizing: border-box;\"><span style=\"font-size: 24px;\">{institute_name}</span></span><span style=\"font-size: 24px;\">&nbsp;<b> from&nbsp;</b></span></span></font><span style=\"font-weight: bold; font-size: 24px;\">&nbsp;</span><font style=\"\" face=\"Pinyon Script\"><span style=\"font-size: 24px;\">{joining_date}</span></font><span style=\"font-size: 24px;\">&nbsp;</span><span style=\"font-weight: bold; font-size: 24px;\">&nbsp;</span><font style=\"font-weight: bold; box-sizing: border-box;\" face=\"Parisienne\"><font face=\"Pinyon Script\"><span style=\"box-sizing: border-box; font-size: 24px;\">with our entire satisfaction.During of his working period we found of him/his sincere, honest, hardworking, dedicated employee with a professional attitude and very good job knowledge.</span></font><span style=\"box-sizing: border-box; font-size: 24px;\">&nbsp;</span></font></div><div style=\"text-align: center; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; box-sizing: border-box; line-height: 1.2;\"><font style=\"box-sizing: border-box;\" face=\"Pinyon Script\"><b><font style=\"box-sizing: border-box; font-size: 28px;\"><span style=\"box-sizing: border-box; font-size: 24px;\">&nbsp;We have no objection to allow him/his in any better position and have no liabilities&nbsp; in our company.</span></font><span style=\"box-sizing: border-box; font-size: 24px;\">&nbsp;</span></b></font></div><div style=\"text-align: center; color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; box-sizing: border-box; line-height: 1.2;\"><font style=\"box-sizing: border-box;\" face=\"Pinyon Script\"><span style=\"box-sizing: border-box; font-size: 24px;\"><b>We wish him/his great success of life . <br></b></span></font></div><div style=\"color: rgb(0, 0, 0); font-family: Arial, Helvetica, sans-serif; font-size: 14px; font-style: normal; font-variant-ligatures: normal; font-variant-caps: normal; letter-spacing: normal; text-transform: none; white-space: normal; word-spacing: 0px; -webkit-text-stroke-width: 0px; box-sizing: border-box; line-height: 1.2;\"><span style=\"font-family: Arial;\"><b><span style=\"font-size: 12px;\">Date of Publication of Released</span></b><span style=\"font-size: 12px;\">:</span> {print_date}&nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</span><font style=\"font-weight: 400;\" face=\"Pinyon Script\"><span style=\"font-size: 24px;\">&nbsp;</span></font>{qr_code}</div></div>', 2, 1, '100', '80', '80', '80', '80', 'staff_id', 1, '2023-09-22 11:24:44');


#
# TABLE STRUCTURE FOR: class
#

DROP TABLE IF EXISTS `class`;

CREATE TABLE `class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `name_numeric` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (1, 'Class 1', '1', '2023-09-23 17:08:30', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (2, 'Class 2', '2', '2023-09-23 17:08:45', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (3, 'Class 3', '3', '2023-09-23 17:08:57', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (4, 'Class 4', '4', '2023-09-23 17:09:09', NULL, 1);
INSERT INTO `class` (`id`, `name`, `name_numeric`, `created_at`, `updated_at`, `branch_id`) VALUES (5, 'Class 5', '5', '2023-09-23 17:09:48', NULL, 1);


#
# TABLE STRUCTURE FOR: complaint
#

DROP TABLE IF EXISTS `complaint`;

CREATE TABLE `complaint` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  `type_id` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `assigned_id` int(11) DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `date_of_solution` date DEFAULT NULL,
  `file` varchar(500) NOT NULL,
  `note` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: complaint_type
#

DROP TABLE IF EXISTS `complaint_type`;

CREATE TABLE `complaint_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: custom_field
#

DROP TABLE IF EXISTS `custom_field`;

CREATE TABLE `custom_field` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `form_to` varchar(50) DEFAULT NULL,
  `field_label` varchar(100) NOT NULL,
  `default_value` text DEFAULT NULL,
  `field_type` enum('text','textarea','dropdown','date','checkbox','number','url','email') NOT NULL,
  `required` varchar(5) NOT NULL DEFAULT 'false',
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `show_on_table` varchar(5) DEFAULT NULL,
  `field_order` int(11) NOT NULL,
  `bs_column` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: custom_fields_online_values
#

DROP TABLE IF EXISTS `custom_fields_online_values`;

CREATE TABLE `custom_fields_online_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relid` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldid` (`field_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: custom_fields_values
#

DROP TABLE IF EXISTS `custom_fields_values`;

CREATE TABLE `custom_fields_values` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `relid` int(11) NOT NULL,
  `field_id` int(11) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`),
  KEY `relid` (`relid`),
  KEY `fieldid` (`field_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: disable_reason
#

DROP TABLE IF EXISTS `disable_reason`;

CREATE TABLE `disable_reason` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: disable_reason_details
#

DROP TABLE IF EXISTS `disable_reason_details`;

CREATE TABLE `disable_reason_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `reason_id` int(11) NOT NULL,
  `note` varchar(255) NOT NULL,
  `date` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: email_config
#

DROP TABLE IF EXISTS `email_config`;

CREATE TABLE `email_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `protocol` varchar(255) NOT NULL,
  `smtp_host` varchar(255) DEFAULT NULL,
  `smtp_user` varchar(255) DEFAULT NULL,
  `smtp_pass` varchar(255) DEFAULT NULL,
  `smtp_port` varchar(100) DEFAULT NULL,
  `smtp_encryption` varchar(10) DEFAULT NULL,
  `smtp_auth` varchar(10) NOT NULL DEFAULT 'true',
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `email_config` (`id`, `email`, `protocol`, `smtp_host`, `smtp_user`, `smtp_pass`, `smtp_port`, `smtp_encryption`, `smtp_auth`, `branch_id`) VALUES (1, 'info@elitedesign.com.bd', 'smtp', 'mail.elitedesign.com.bd', 'no-reply@elitedesign.com.bd', 'BAngladesh7575@$#', '465', 'ssl', 'true', 1);


#
# TABLE STRUCTURE FOR: email_templates
#

DROP TABLE IF EXISTS `email_templates`;

CREATE TABLE `email_templates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `tags` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (1, 'account_registered', '{institute_name}, {name}, {login_username}, {password}, {user_role}, {login_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (2, 'forgot_password', '{institute_name}, {username}, {email}, {reset_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (3, 'change_password', '{institute_name}, {name}, {email}, {password}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (4, 'new_message_received', '{institute_name}, {recipient}, {message}, {message_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (5, 'payslip_generated', '{institute_name}, {username}, {month_year}, {payslip_url}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (6, 'award', '{institute_name}, {winner_name}, {award_name}, {gift_item}, {award_reason}, {given_date}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (7, 'leave_approve', '{institute_name}, {applicant_name}, {start_date}, {end_date}, {comments}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (8, 'leave_reject', '{institute_name}, {applicant_name}, {start_date}, {end_date}, {comments}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (9, 'advance_salary_approve', '{institute_name}, {applicant_name}, {deduct_motnh}, {amount}, {comments}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (10, 'advance_salary_reject', '{institute_name}, {applicant_name}, {deduct_motnh}, {amount}, {comments}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (11, 'apply_online_admission', '{institute_name}, {admission_id}, {applicant_name}, {applicant_mobile}, {class}, {section}, {apply_date}, {payment_url}, {admission_copy_url}, {paid_amount}');
INSERT INTO `email_templates` (`id`, `name`, `tags`) VALUES (12, 'student_admission', '{institute_name}, {academic_year}, {admission_date}, {admission_no}, {roll}, {category}, {student_name}, {student_mobile}, {class}, {section}, {login_username}, {password}, {login_url}');


#
# TABLE STRUCTURE FOR: email_templates_details
#

DROP TABLE IF EXISTS `email_templates_details`;

CREATE TABLE `email_templates_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `template_body` text NOT NULL,
  `notified` tinyint(1) NOT NULL DEFAULT 1,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `email_templates_details` (`id`, `template_id`, `subject`, `template_body`, `notified`, `branch_id`) VALUES (1, 12, 'Admission', '<p>{institute_name}, {academic_year}, {admission_date}, {admission_no}, {roll}, {category}, {student_name}, {student_mobile}, {class}, {section}, {login_username}, {password}, {login_url}<br></p>', 1, 1);
INSERT INTO `email_templates_details` (`id`, `template_id`, `subject`, `template_body`, `notified`, `branch_id`) VALUES (2, 11, 'Online Admission', '<p>{institute_name}, {admission_id}, {applicant_name}, {applicant_mobile}, {class}, {section}, {apply_date}, {payment_url}, {admission_copy_url}, {paid_amount}</p><p><b>TERMINOS Y CONDICIONES</b></p>', 1, 1);
INSERT INTO `email_templates_details` (`id`, `template_id`, `subject`, `template_body`, `notified`, `branch_id`) VALUES (3, 1, 'Congratulations, here are your login details to {institute_name}', '<p>Hello,<b> <span xss=\"removed\">{name}</span></b></p><p>Your account has been created. Please log in using the following details:</p><p>Login URL: <b>{login_url}</b></p><p>Username:<b> {login_email}</b></p><p>Password: <b>{password}</b></p><p>Please keep your login credentials confidential and do not share them with anyone else.</p>', 1, 1);


#
# TABLE STRUCTURE FOR: enquiry
#

DROP TABLE IF EXISTS `enquiry`;

CREATE TABLE `enquiry` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `birthday` date DEFAULT NULL,
  `gender` tinyint(1) DEFAULT 0,
  `father_name` varchar(255) DEFAULT NULL,
  `mother_name` varchar(255) DEFAULT NULL,
  `mobile_no` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `address` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `previous_school` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `reference_id` int(11) NOT NULL,
  `response_id` int(11) NOT NULL,
  `response` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `note` varchar(255) NOT NULL,
  `assigned_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `no_of_child` float NOT NULL,
  `class_id` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `branch_id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: enquiry_follow_up
#

DROP TABLE IF EXISTS `enquiry_follow_up`;

CREATE TABLE `enquiry_follow_up` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enquiry_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `next_date` date NOT NULL,
  `response` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL,
  `note` varchar(255) NOT NULL,
  `follow_up_by` int(11) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: enquiry_reference
#

DROP TABLE IF EXISTS `enquiry_reference`;

CREATE TABLE `enquiry_reference` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: enquiry_response
#

DROP TABLE IF EXISTS `enquiry_response`;

CREATE TABLE `enquiry_response` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: enroll
#

DROP TABLE IF EXISTS `enroll`;

CREATE TABLE `enroll` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `roll` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` tinyint(3) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `enroll` (`id`, `student_id`, `class_id`, `section_id`, `roll`, `session_id`, `branch_id`, `created_at`, `updated_at`) VALUES (1, 1, 1, 1, 101, 6, 1, '2023-09-24 06:47:00', NULL);
INSERT INTO `enroll` (`id`, `student_id`, `class_id`, `section_id`, `roll`, `session_id`, `branch_id`, `created_at`, `updated_at`) VALUES (2, 2, 1, 1, 102, 6, 1, '2023-09-25 13:47:31', NULL);
INSERT INTO `enroll` (`id`, `student_id`, `class_id`, `section_id`, `roll`, `session_id`, `branch_id`, `created_at`, `updated_at`) VALUES (3, 3, 1, 1, 103, 6, 1, '2023-09-25 13:52:13', NULL);


#
# TABLE STRUCTURE FOR: event
#

DROP TABLE IF EXISTS `event`;

CREATE TABLE `event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `remark` text NOT NULL,
  `status` tinyint(1) NOT NULL,
  `type` text NOT NULL,
  `audition` longtext NOT NULL,
  `selected_list` longtext NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `image` varchar(255) NOT NULL,
  `created_by` varchar(200) NOT NULL,
  `session_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `show_web` tinyint(3) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: event_types
#

DROP TABLE IF EXISTS `event_types`;

CREATE TABLE `event_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `icon` varchar(200) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: exam
#

DROP TABLE IF EXISTS `exam`;

CREATE TABLE `exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `term_id` int(11) DEFAULT NULL,
  `type_id` tinyint(4) NOT NULL COMMENT '1=mark,2=gpa,3=both',
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `remark` text NOT NULL,
  `mark_distribution` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `exam` (`id`, `name`, `term_id`, `type_id`, `session_id`, `branch_id`, `remark`, `mark_distribution`, `created_at`, `updated_at`) VALUES (1, '1st Tutorial', 1, 1, 6, 1, '', '[\"1\",\"2\"]', '2023-09-25 14:46:36', NULL);
INSERT INTO `exam` (`id`, `name`, `term_id`, `type_id`, `session_id`, `branch_id`, `remark`, `mark_distribution`, `created_at`, `updated_at`) VALUES (2, '1st Semister', 2, 3, 6, 1, 'Mark & GPA Based', '[\"1\",\"2\"]', '2023-09-25 14:55:56', NULL);


#
# TABLE STRUCTURE FOR: exam_attendance
#

DROP TABLE IF EXISTS `exam_attendance`;

CREATE TABLE `exam_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `status` varchar(4) DEFAULT NULL COMMENT 'P=Present, A=Absent, L=Late',
  `remark` varchar(255) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: exam_hall
#

DROP TABLE IF EXISTS `exam_hall`;

CREATE TABLE `exam_hall` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `hall_no` longtext NOT NULL,
  `seats` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `exam_hall` (`id`, `hall_no`, `seats`, `branch_id`) VALUES (1, '101', 30, 1);
INSERT INTO `exam_hall` (`id`, `hall_no`, `seats`, `branch_id`) VALUES (2, '102', 30, 1);
INSERT INTO `exam_hall` (`id`, `hall_no`, `seats`, `branch_id`) VALUES (3, '103', 30, 1);
INSERT INTO `exam_hall` (`id`, `hall_no`, `seats`, `branch_id`) VALUES (4, '104', 30, 1);
INSERT INTO `exam_hall` (`id`, `hall_no`, `seats`, `branch_id`) VALUES (5, '105', 30, 1);


#
# TABLE STRUCTURE FOR: exam_mark_distribution
#

DROP TABLE IF EXISTS `exam_mark_distribution`;

CREATE TABLE `exam_mark_distribution` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `exam_mark_distribution` (`id`, `name`, `branch_id`) VALUES (1, 'Practical', 1);
INSERT INTO `exam_mark_distribution` (`id`, `name`, `branch_id`) VALUES (2, 'Theory', 1);


#
# TABLE STRUCTURE FOR: exam_term
#

DROP TABLE IF EXISTS `exam_term`;

CREATE TABLE `exam_term` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `session_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `exam_term` (`id`, `name`, `branch_id`, `session_id`) VALUES (1, '1st Tutorial', 1, 6);
INSERT INTO `exam_term` (`id`, `name`, `branch_id`, `session_id`) VALUES (2, '1st Semister', 1, 6);
INSERT INTO `exam_term` (`id`, `name`, `branch_id`, `session_id`) VALUES (3, '2nd Tutorial', 1, 6);
INSERT INTO `exam_term` (`id`, `name`, `branch_id`, `session_id`) VALUES (4, '2nd Semister', 1, 6);
INSERT INTO `exam_term` (`id`, `name`, `branch_id`, `session_id`) VALUES (5, '3rd Tutorial', 1, 6);
INSERT INTO `exam_term` (`id`, `name`, `branch_id`, `session_id`) VALUES (6, '3rd Semister', 1, 6);


#
# TABLE STRUCTURE FOR: fee_allocation
#

DROP TABLE IF EXISTS `fee_allocation`;

CREATE TABLE `fee_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `prev_due` decimal(18,2) NOT NULL DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `fee_allocation` (`id`, `student_id`, `group_id`, `branch_id`, `session_id`, `prev_due`, `created_at`) VALUES (1, 1, 4, 1, 6, '0.00', '2023-09-25 13:17:57');
INSERT INTO `fee_allocation` (`id`, `student_id`, `group_id`, `branch_id`, `session_id`, `prev_due`, `created_at`) VALUES (2, 2, 4, 1, 6, '0.00', '2023-09-25 13:56:14');
INSERT INTO `fee_allocation` (`id`, `student_id`, `group_id`, `branch_id`, `session_id`, `prev_due`, `created_at`) VALUES (3, 3, 4, 1, 6, '0.00', '2023-09-25 13:56:14');


#
# TABLE STRUCTURE FOR: fee_fine
#

DROP TABLE IF EXISTS `fee_fine`;

CREATE TABLE `fee_fine` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `fine_value` varchar(20) NOT NULL,
  `fine_type` varchar(20) NOT NULL,
  `fee_frequency` varchar(20) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `fee_fine` (`id`, `group_id`, `type_id`, `fine_value`, `fine_type`, `fee_frequency`, `branch_id`, `session_id`) VALUES (1, 1, 1, '200', '1', '30', 1, 4);
INSERT INTO `fee_fine` (`id`, `group_id`, `type_id`, `fine_value`, `fine_type`, `fee_frequency`, `branch_id`, `session_id`) VALUES (2, 2, 5, '10', '1', '30', 1, 4);


#
# TABLE STRUCTURE FOR: fee_groups
#

DROP TABLE IF EXISTS `fee_groups`;

CREATE TABLE `fee_groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `session_id` int(11) NOT NULL,
  `system` tinyint(4) NOT NULL DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `fee_groups` (`id`, `name`, `description`, `session_id`, `system`, `branch_id`, `created_at`) VALUES (1, 'Admision All Fee', 'Admision All Fee', 4, 0, 1, '2023-09-23 16:59:27');
INSERT INTO `fee_groups` (`id`, `name`, `description`, `session_id`, `system`, `branch_id`, `created_at`) VALUES (2, 'Tution Fee', 'Tution Fee', 4, 0, 1, '2023-09-23 17:00:04');
INSERT INTO `fee_groups` (`id`, `name`, `description`, `session_id`, `system`, `branch_id`, `created_at`) VALUES (3, 'Exam Fee', 'Exam Fee', 4, 0, 1, '2023-09-23 17:01:01');
INSERT INTO `fee_groups` (`id`, `name`, `description`, `session_id`, `system`, `branch_id`, `created_at`) VALUES (4, 'New Student Admission', 'New Student Admission', 6, 0, 1, '2023-09-25 13:17:32');


#
# TABLE STRUCTURE FOR: fee_groups_details
#

DROP TABLE IF EXISTS `fee_groups_details`;

CREATE TABLE `fee_groups_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fee_groups_id` int(11) NOT NULL,
  `fee_type_id` int(11) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `due_date` date DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `fee_groups_details` (`id`, `fee_groups_id`, `fee_type_id`, `amount`, `due_date`, `created_at`) VALUES (1, 1, 1, '500.00', '2025-12-11', '2023-09-23 16:59:27');
INSERT INTO `fee_groups_details` (`id`, `fee_groups_id`, `fee_type_id`, `amount`, `due_date`, `created_at`) VALUES (2, 1, 3, '120.00', '2025-08-22', '2023-09-23 16:59:27');
INSERT INTO `fee_groups_details` (`id`, `fee_groups_id`, `fee_type_id`, `amount`, `due_date`, `created_at`) VALUES (3, 1, 4, '200.00', '2025-07-24', '2023-09-23 16:59:27');
INSERT INTO `fee_groups_details` (`id`, `fee_groups_id`, `fee_type_id`, `amount`, `due_date`, `created_at`) VALUES (4, 1, 5, '300.00', '2025-07-17', '2023-09-23 16:59:27');
INSERT INTO `fee_groups_details` (`id`, `fee_groups_id`, `fee_type_id`, `amount`, `due_date`, `created_at`) VALUES (5, 1, 6, '2000.00', '2025-03-13', '2023-09-23 16:59:27');
INSERT INTO `fee_groups_details` (`id`, `fee_groups_id`, `fee_type_id`, `amount`, `due_date`, `created_at`) VALUES (6, 2, 5, '300.00', '2025-08-06', '2023-09-23 17:00:04');
INSERT INTO `fee_groups_details` (`id`, `fee_groups_id`, `fee_type_id`, `amount`, `due_date`, `created_at`) VALUES (7, 3, 2, '200.00', '2025-03-13', '2023-09-23 17:01:01');
INSERT INTO `fee_groups_details` (`id`, `fee_groups_id`, `fee_type_id`, `amount`, `due_date`, `created_at`) VALUES (8, 3, 7, '300.00', '2025-02-27', '2023-09-23 17:01:01');
INSERT INTO `fee_groups_details` (`id`, `fee_groups_id`, `fee_type_id`, `amount`, `due_date`, `created_at`) VALUES (9, 4, 1, '3000.00', '2023-09-25', '2023-09-25 13:17:32');
INSERT INTO `fee_groups_details` (`id`, `fee_groups_id`, `fee_type_id`, `amount`, `due_date`, `created_at`) VALUES (10, 4, 3, '120.00', '2023-09-25', '2023-09-25 13:17:32');
INSERT INTO `fee_groups_details` (`id`, `fee_groups_id`, `fee_type_id`, `amount`, `due_date`, `created_at`) VALUES (11, 4, 4, '200.00', '2023-09-25', '2023-09-25 13:17:32');
INSERT INTO `fee_groups_details` (`id`, `fee_groups_id`, `fee_type_id`, `amount`, `due_date`, `created_at`) VALUES (12, 4, 5, '300.00', '2023-09-25', '2023-09-25 13:17:32');
INSERT INTO `fee_groups_details` (`id`, `fee_groups_id`, `fee_type_id`, `amount`, `due_date`, `created_at`) VALUES (13, 4, 6, '3000.00', '2023-09-25', '2023-09-25 13:17:32');


#
# TABLE STRUCTURE FOR: fee_payment_history
#

DROP TABLE IF EXISTS `fee_payment_history`;

CREATE TABLE `fee_payment_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `allocation_id` int(11) NOT NULL,
  `type_id` int(11) NOT NULL,
  `collect_by` varchar(20) DEFAULT NULL,
  `amount` decimal(18,2) NOT NULL,
  `discount` decimal(18,2) NOT NULL,
  `fine` decimal(18,2) NOT NULL,
  `pay_via` varchar(20) NOT NULL,
  `remarks` longtext NOT NULL,
  `date` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `fee_payment_history` (`id`, `allocation_id`, `type_id`, `collect_by`, `amount`, `discount`, `fine`, `pay_via`, `remarks`, `date`) VALUES (1, 1, 6, '1', '3000.00', '0.00', '0.00', '1', '', '2023-09-25');
INSERT INTO `fee_payment_history` (`id`, `allocation_id`, `type_id`, `collect_by`, `amount`, `discount`, `fine`, `pay_via`, `remarks`, `date`) VALUES (2, 1, 1, '1', '3000.00', '0.00', '0.00', '1', '', '2023-09-25');
INSERT INTO `fee_payment_history` (`id`, `allocation_id`, `type_id`, `collect_by`, `amount`, `discount`, `fine`, `pay_via`, `remarks`, `date`) VALUES (3, 1, 3, '1', '120.00', '0.00', '0.00', '1', '', '2023-09-25');
INSERT INTO `fee_payment_history` (`id`, `allocation_id`, `type_id`, `collect_by`, `amount`, `discount`, `fine`, `pay_via`, `remarks`, `date`) VALUES (4, 1, 4, '1', '200.00', '0.00', '0.00', '1', '', '2023-09-25');
INSERT INTO `fee_payment_history` (`id`, `allocation_id`, `type_id`, `collect_by`, `amount`, `discount`, `fine`, `pay_via`, `remarks`, `date`) VALUES (5, 2, 1, '1', '3000.00', '0.00', '0.00', '1', '', '2023-09-25');
INSERT INTO `fee_payment_history` (`id`, `allocation_id`, `type_id`, `collect_by`, `amount`, `discount`, `fine`, `pay_via`, `remarks`, `date`) VALUES (6, 2, 3, '1', '120.00', '0.00', '0.00', '1', '', '2023-09-25');
INSERT INTO `fee_payment_history` (`id`, `allocation_id`, `type_id`, `collect_by`, `amount`, `discount`, `fine`, `pay_via`, `remarks`, `date`) VALUES (7, 2, 4, '1', '200.00', '0.00', '0.00', '1', '', '2023-09-25');
INSERT INTO `fee_payment_history` (`id`, `allocation_id`, `type_id`, `collect_by`, `amount`, `discount`, `fine`, `pay_via`, `remarks`, `date`) VALUES (8, 2, 5, '1', '300.00', '0.00', '0.00', '1', '', '2023-09-25');
INSERT INTO `fee_payment_history` (`id`, `allocation_id`, `type_id`, `collect_by`, `amount`, `discount`, `fine`, `pay_via`, `remarks`, `date`) VALUES (9, 2, 6, '1', '3000.00', '0.00', '0.00', '1', '', '2023-09-25');


#
# TABLE STRUCTURE FOR: fees_reminder
#

DROP TABLE IF EXISTS `fees_reminder`;

CREATE TABLE `fees_reminder` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `frequency` varchar(255) NOT NULL,
  `days` varchar(20) NOT NULL,
  `message` text NOT NULL,
  `dlt_template_id` varchar(255) DEFAULT NULL,
  `student` tinyint(3) NOT NULL,
  `guardian` tinyint(3) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: fees_type
#

DROP TABLE IF EXISTS `fees_type`;

CREATE TABLE `fees_type` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `fee_code` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `branch_id` int(11) NOT NULL DEFAULT 0,
  `system` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `fees_type` (`id`, `name`, `fee_code`, `description`, `branch_id`, `system`, `created_at`) VALUES (1, 'Admission Fee', 'admission-fee', 'Admission Fee', 1, 0, '2023-09-23 16:54:27');
INSERT INTO `fees_type` (`id`, `name`, `fee_code`, `description`, `branch_id`, `system`, `created_at`) VALUES (2, 'Admid card', 'admid-card', 'Admid card', 1, 0, '2023-09-23 16:54:48');
INSERT INTO `fees_type` (`id`, `name`, `fee_code`, `description`, `branch_id`, `system`, `created_at`) VALUES (3, 'ID Card', 'id-card', 'ID Card', 1, 0, '2023-09-23 16:55:02');
INSERT INTO `fees_type` (`id`, `name`, `fee_code`, `description`, `branch_id`, `system`, `created_at`) VALUES (4, 'Syllybus Fee', 'syllybus-fee', 'Syllybus Fee', 1, 0, '2023-09-23 16:55:16');
INSERT INTO `fees_type` (`id`, `name`, `fee_code`, `description`, `branch_id`, `system`, `created_at`) VALUES (5, 'Tution Fee', 'tution-fee', 'Tution Fee', 1, 0, '2023-09-23 16:55:32');
INSERT INTO `fees_type` (`id`, `name`, `fee_code`, `description`, `branch_id`, `system`, `created_at`) VALUES (6, 'Unifrom', 'unifrom', 'Unifrom', 1, 0, '2023-09-23 16:55:57');
INSERT INTO `fees_type` (`id`, `name`, `fee_code`, `description`, `branch_id`, `system`, `created_at`) VALUES (7, 'Exam Fee', 'exam-fee', 'Exam Fee', 1, 0, '2023-09-23 16:56:20');


#
# TABLE STRUCTURE FOR: front_cms_about
#

DROP TABLE IF EXISTS `front_cms_about`;

CREATE TABLE `front_cms_about` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `page_title` varchar(255) NOT NULL,
  `content` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `about_image` varchar(255) NOT NULL,
  `elements` mediumtext NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_about` (`id`, `title`, `subtitle`, `page_title`, `content`, `banner_image`, `about_image`, `elements`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'রূপনগর আবাসিক হাই স্কুল', 'বিশ্ব সেরা স্কুল', 'About Us', '<p>একবিংশ শতাব্দীর চ্যালেঞ্জ মোকাবেলা ও মেধার সঠিক বিকাশ সাধন এবং নৈতিকতার আত্মবিশ্বাসী সুনাগরিক হিসেবে গড়ে তোলার লক্ষে বিজ্ঞানভিত্তিক শ্রেণি কার্যক্রম, পদ্ধতিগত শিক্ষা, নিয়মিত পরীক্ষা, ধারাবাহিক অনুশীলন, আধুনিক শিক্ষা উপকরণ ব্যবহার পূর্বক পাঠদান করা হয়্ রাজনীতি ও ধূমপান মুক্ত, নিরাপদ ও সুশৃঙ্খল শিক্ষা পরিবেশ।</p><p><br></p><p>সুপরিকল্পিত শিক্ষা পদ্ধতি, দক্ষ ব্যবস্থাপনা ও শিক্ষক মন্ডলীর ঐকান্তিক প্রচেষ্টায় এখানে শিক্ষার সুন্দর পরিবেশ নিশ্চিত করা সম্ভব হয়েছে । বিদ্যালয়ের আভ্যন্তরীন পরীক্ষা সহ পিইসি, জেএসসি ও এসএসসি পরীক্ষার ফলাফল অত্যন্ত ভাল। সকল পাবলিক পরীক্ষায় বিগত বছরগুলোতে প্রায় শতভাগ সাফল্য আমাদের একটি বড় অর্জন । তবে শুধু ভাল ফল অর্জনই নয়, মানসম্মত শিক্ষা ও প্রযুক্তিনির্ভর জ্ঞানার্জনের মাধ্যমে শিক্ষার্থীদেরকে যোগ্য নাগরিক হিসেবে গড়ে তোলাই আমাদের অন্যতম লক্ষ্য । আমরা চেষ্টা করে যাচ্ছি । আশা করছি অচিরেই এ প্রতিষ্ঠানের শিক্ষার্থীরা জীবনের প্রতিটি ক্ষেত্রে তাদের প্রতিভা বিকাশে উজ্জ্বল স্বাক্ষর রাখার পাশাপশি নিজেদেরকে ভাল মানুষ হিসেবে গড়ে তুলতে সক্ষম হবে ।&nbsp;</p>', 'about1.jpg', 'about1.png', '{\"cta_title\":\"Get in touch to join our community\",\"button_text\":\"Contact Our Office\",\"button_url\":\"contact\"}', '', '', 1);


#
# TABLE STRUCTURE FOR: front_cms_admission
#

DROP TABLE IF EXISTS `front_cms_admission`;

CREATE TABLE `front_cms_admission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `terms_conditions_title` varchar(255) DEFAULT NULL,
  `terms_conditions_description` text NOT NULL,
  `fee_elements` text DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_admission` (`id`, `title`, `description`, `page_title`, `terms_conditions_title`, `terms_conditions_description`, `fee_elements`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'অনলাইন এডমিশন ফরম', '<p>নিচের ফরমটি খুব ভালোভাবে পুরন করুন, খেয়াল রাখবেন পুরন করার সময় যেন কোন ভুল না হয়।</p>\r\n', 'অনলাইন এডমিশন', '', '', '[]', 'admission1.jpg', 'অনলাইন এডমিশন', 'admisshion', 1);


#
# TABLE STRUCTURE FOR: front_cms_admitcard
#

DROP TABLE IF EXISTS `front_cms_admitcard`;

CREATE TABLE `front_cms_admitcard` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) DEFAULT NULL,
  `templete_id` int(11) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_admitcard` (`id`, `page_title`, `templete_id`, `banner_image`, `description`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'এডমিট কার্ড', 3, 'admit_card1.jpg', 'আপনার এডমিট কার্ডটি ডাউনলোড করে নিন।', 'এডমিট কার্ড', 'এডমিট কার্ড', 1);


#
# TABLE STRUCTURE FOR: front_cms_certificates
#

DROP TABLE IF EXISTS `front_cms_certificates`;

CREATE TABLE `front_cms_certificates` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_certificates` (`id`, `page_title`, `banner_image`, `description`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'সার্টিফিকেট', 'certificates1.jpg', 'সার্টিফিকেট দেখতে রোল নাম্বার দিয়ে সাবমিট করুন।', 'সার্টিফিকেট দেখতে রোল নাম্বার দিয়ে সাবমিট করুন।', 'সার্টিফিকেট দেখতে রোল নাম্বার দিয়ে সাবমিট করুন।', 1);


#
# TABLE STRUCTURE FOR: front_cms_contact
#

DROP TABLE IF EXISTS `front_cms_contact`;

CREATE TABLE `front_cms_contact` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `box_title` varchar(255) DEFAULT NULL,
  `box_description` varchar(500) DEFAULT NULL,
  `box_image` varchar(255) DEFAULT NULL,
  `form_title` varchar(355) DEFAULT NULL,
  `address` varchar(355) DEFAULT NULL,
  `phone` varchar(355) DEFAULT NULL,
  `email` varchar(355) DEFAULT NULL,
  `submit_text` varchar(355) NOT NULL,
  `map_iframe` text DEFAULT NULL,
  `page_title` varchar(255) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_contact` (`id`, `box_title`, `box_description`, `box_image`, `form_title`, `address`, `phone`, `email`, `submit_text`, `map_iframe`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'আমাদের সাথে যোগাযোগ করুন', 'আমাদের সাথে যোগাযোগ করতে নিচের পদ্ধতি, গুল অনুসরন করুন।', 'contact-info-box1.png', 'Get in touch by filling the form below', 'House: Munshi Bari, Beside Nayar hat High School, Boro Bari Lalmonir Hat', '+8801775457008, \r\n+8801954578089', 'info@elitedesign.com.bd\r\nsupport@elitedesign.com.bd', 'Send', '<iframe src=\"https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d57414.587442472315!2d89.40850722288096!3d25.92170287398638!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x39e2d915b0c3148d%3A0xfdd5019e20200f4!2sLalmonirhat!5e0!3m2!1sen!2sbd!4v1695390245794!5m2!1sen!2sbd\" width=\"600\" height=\"450\" style=\"border:0;\" allowfullscreen=\"\" loading=\"lazy\" referrerpolicy=\"no-referrer-when-downgrade\"></iframe>', 'যোগাযোগ', 'contact1.jpg', '', '', 1);


#
# TABLE STRUCTURE FOR: front_cms_events
#

DROP TABLE IF EXISTS `front_cms_events`;

CREATE TABLE `front_cms_events` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_events` (`id`, `title`, `description`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Upcoming Events', '<p>Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident.</p><p>Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.</p>', 'Events', 'events1.jpg', 'Ramom - School Management System With CMS', 'Ramom Events Page', 1);


#
# TABLE STRUCTURE FOR: front_cms_exam_results
#

DROP TABLE IF EXISTS `front_cms_exam_results`;

CREATE TABLE `front_cms_exam_results` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) DEFAULT NULL,
  `grade_scale` tinyint(1) NOT NULL,
  `attendance` tinyint(1) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `description` text NOT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_exam_results` (`id`, `page_title`, `grade_scale`, `attendance`, `banner_image`, `description`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'পরীক্ষার রেজাল্ট', 1, 1, 'exam_results1.png', 'পরীক্ষার রেজাল্ট দেখতে আপনার রোল নাম্বার দিয়ে ক্লাশ নির্বাচন করে সাবমিট করুন।', 'পরীক্ষার রেজাল্ট', 'পরীক্ষার রেজাল্ট', 1);


#
# TABLE STRUCTURE FOR: front_cms_faq
#

DROP TABLE IF EXISTS `front_cms_faq`;

CREATE TABLE `front_cms_faq` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_faq` (`id`, `title`, `description`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'নোটিশ', '<p>সকল নোটিশ নিচে দেওয়া হল।</p>', 'Faq', 'faq1.jpg', '', '', 1);


#
# TABLE STRUCTURE FOR: front_cms_faq_list
#

DROP TABLE IF EXISTS `front_cms_faq_list`;

CREATE TABLE `front_cms_faq_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (1, '২০২৩ সালের সরকারি-বেসরকারি স্কুল ছুটির তালিকা প্রকাশ করা হয়েছে। মাধ্যমিক ও উচ্চ শিক্ষা অধিদপ্তর (মাউশি) স্কুলের এই ছুটির তালিকা প্রকাশ করেছে।', '<p>\r\nLorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.\r\n</p>\r\n<ul>\r\n<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</li>\r\n<li>Sed do eiusmod tempor incididunt ut labore et dolore magna aliq.</li>\r\n<li>Ut enim ad minim veniam, quis nostrud exercitation ullamco quat. It is a long established fact.</li>\r\n<li>That a reader will be distracted by the readable content of a page when looking at its layout.</li>\r\n<li>Lorem ipsum dolor sit amet, consectetur adipisicing elit.</li>\r\n<li>Eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam.</li>\r\n<li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n<li>Readable content of a page when looking at its layout.</li>\r\n<li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n<li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n</ul>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (2, 'এই প্রতিবেদন থেকে, দেশের সকল মাধ্যমিক বিদ্যালয়ের বার্ষিক শিক্ষাপঞ্জি ও ছুটির প্রজ্ঞাপনের pdf ক্যালেন্ডার দেখুন।', '<p>\r\n                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.\r\n                            </p>\r\n                            <ol>\r\n                                <li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n                                <li>Readable content of a page when looking at its layout.</li>\r\n                                <li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n                                <li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n                            </ol>\r\n                            <p>\r\n                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.\r\n                            </p>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (3, 'মহামান্য রাষ্ট্রপতির আদেশক্রমে, শিক্ষা মন্ত্রণালয়ের সিনিয়র সহকারী সচিব মোছামাৎ রহিমা আক্তার স্বাক্ষরিত ছুটির প্রজ্ঞাপন জারি করেন।', '<p>\r\n                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.\r\n                            </p>\r\n                            <ol>\r\n                                <li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n                                <li>Readable content of a page when looking at its layout.</li>\r\n                                <li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n                                <li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n                            </ol>\r\n                            <p>\r\n                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.\r\n                            </p>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (4, 'মহামান্য রাষ্ট্রপতির আদেশক্রমে, শিক্ষা মন্ত্রণালয়ের সিনিয়র সহকারী সচিব মোছামাৎ রহিমা আক্তার স্বাক্ষরিত ছুটির প্রজ্ঞাপন জারি করেন।', '<p>\r\n                                Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven\'t heard of them accusamus labore sustainable VHS.\r\n                            </p>\r\n                            <ol>\r\n                                <li>Quis nostrud exercitation ullamco quat. It is a long established fact that a reader will be distracted.</li>\r\n                                <li>Readable content of a page when looking at its layout.</li>\r\n                                <li>The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters.</li>\r\n                                <li>Opposed to using \'Content here, content here\', making it look like readable English.</li>\r\n                            </ol>\r\n                            <p>\r\n                                Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et.\r\n                            </p>', 1);
INSERT INTO `front_cms_faq_list` (`id`, `title`, `description`, `branch_id`) VALUES (5, 'মহামান্য রাষ্ট্রপতির আদেশক্রমে, শিক্ষা মন্ত্রণালয়ের সিনিয়র সহকারী সচিব মোছামাৎ রহিমা আক্তার স্বাক্ষরিত ছুটির প্রজ্ঞাপন জারি করেন।', '<p><strong>Lorem ipsum</strong> dolor sit amet, an labores explicari qui, eu nostrum copiosae argumentum has. Latine propriae quo no, unum ridens expetenda id sit, at usu eius eligendi singulis. Sea ocurreret principes ne. At nonumy aperiri pri, nam quodsi copiosae intellegebat et, ex deserunt euripidis usu. Per ad ullum lobortis. Duo volutpat imperdiet ut, postea salutatus imperdiet ut per, ad utinam debitis invenire has.</p>\r\n\r\n<ol>\r\n <li>labores explicari qui</li>\r\n <li>labores explicari qui</li>\r\n <li>labores explicari quilabores explicari qui</li>\r\n <li>labores explicari qui</li>\r\n</ol>', 1);


#
# TABLE STRUCTURE FOR: front_cms_gallery
#

DROP TABLE IF EXISTS `front_cms_gallery`;

CREATE TABLE `front_cms_gallery` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_gallery` (`id`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'Gallery', 'gallery1.png', 'Gallery', 'Gallery', 1);


#
# TABLE STRUCTURE FOR: front_cms_gallery_category
#

DROP TABLE IF EXISTS `front_cms_gallery_category`;

CREATE TABLE `front_cms_gallery_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: front_cms_gallery_content
#

DROP TABLE IF EXISTS `front_cms_gallery_content`;

CREATE TABLE `front_cms_gallery_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `alias` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `thumb_image` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `category_id` int(11) NOT NULL,
  `added_by` int(11) NOT NULL,
  `file_type` varchar(255) NOT NULL,
  `elements` longtext NOT NULL,
  `show_web` tinyint(4) NOT NULL DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  `created_at` date NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: front_cms_home
#

DROP TABLE IF EXISTS `front_cms_home`;

CREATE TABLE `front_cms_home` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `item_type` varchar(20) NOT NULL,
  `description` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `elements` mediumtext NOT NULL,
  `color1` varchar(100) DEFAULT NULL,
  `color2` varchar(100) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  `active` tinyint(3) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `color1`, `color2`, `branch_id`, `active`) VALUES (1, 'রুপনগর আবাসিক হাই স্কুল', 'বিশ্ব সেরা স্কুল', 'wellcome', 'একবিংশ শতাব্দীর চ্যালেঞ্জ মোকাবেলা ও মেধার সঠিক বিকাশ সাধন এবং নৈতিকতার আত্মবিশ্বাসী সুনাগরিক হিসেবে গড়ে তোলার লক্ষে বিজ্ঞানভিত্তিক শ্রেণি কার্যক্রম, পদ্ধতিগত শিক্ষা, নিয়মিত পরীক্ষা, ধারাবাহিক অনুশীলন, আধুনিক শিক্ষা উপকরণ ব্যবহার পূর্বক পাঠদান করা হয়্ রাজনীতি ও ধূমপান মুক্ত, নিরাপদ ও সুশৃঙ্খল শিক্ষা পরিবেশ।\r\n\r\nসুপরিকল্পিত শিক্ষা পদ্ধতি, দক্ষ ব্যবস্থাপনা ও শিক্ষক মন্ডলীর ঐকান্তিক প্রচেষ্টায় এখানে শিক্ষার সুন্দর পরিবেশ নিশ্চিত করা সম্ভব হয়েছে । বিদ্যালয়ের আভ্যন্তরীন পরীক্ষা সহ পিইসি, জেএসসি ও এসএসসি পরীক্ষার ফলাফল অত্যন্ত ভাল। সকল পাবলিক পরীক্ষায় বিগত বছরগুলোতে প্রায় শতভাগ সাফল্য আমাদের একটি বড় অর্জন । তবে শুধু ভাল ফল অর্জনই নয়, মানসম্মত শিক্ষা ও প্রযুক্তিনির্ভর জ্ঞানার্জনের মাধ্যমে শিক্ষার্থীদেরকে যোগ্য নাগরিক হিসেবে গড়ে তোলাই আমাদের অন্যতম লক্ষ্য । আমরা চেষ্টা করে যাচ্ছি । আশা করছি অচিরেই এ প্রতিষ্ঠানের শিক্ষার্থীরা জীবনের প্রতিটি ক্ষেত্রে তাদের প্রতিভা বিকাশে উজ্জ্বল স্বাক্ষর রাখার পাশাপশি নিজেদেরকে ভাল মানুষ হিসেবে গড়ে তুলতে সক্ষম হবে । \r\nMaking it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).', '{\"image\":\"wellcome1.png\"}', '#000', NULL, 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `color1`, `color2`, `branch_id`, `active`) VALUES (2, 'আমাদের সম্মানিত শিক্ষকগন', NULL, 'teachers', 'আমাদের দক্ষ শিক্ষকগনদের তালিকা নিচে দেওয়া হল।', '{\"teacher_start\":\"6\",\"image\":\"featured-parallax1.png\"}', '#fff', '#fff', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `color1`, `color2`, `branch_id`, `active`) VALUES (3, 'WHY CHOOSE US', NULL, 'services', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry.', '', NULL, NULL, 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `color1`, `color2`, `branch_id`, `active`) VALUES (4, 'Request for a free Education Class', 'Medical Services', 'cta', '', '{\"mobile_no\":\"+8801775457008\",\"button_text\":\"Request Now\",\"button_url\":\"http:\\/\\/localhost\\/multi_pro\\/home\\/admission\\/\"}', '#464646', '#fff', 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `color1`, `color2`, `branch_id`, `active`) VALUES (7, 'Online Classes', NULL, 'features', 'Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu.', '{\"button_text\":\"Read More\",\"button_url\":\"#\",\"icon\":\"fas fa-video\"}', NULL, NULL, 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `color1`, `color2`, `branch_id`, `active`) VALUES (8, 'Scholarship', NULL, 'features', 'Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu.', '{\"button_text\":\"Read More\",\"button_url\":\"#\",\"icon\":\"fas fa-graduation-cap\"}', NULL, NULL, 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `color1`, `color2`, `branch_id`, `active`) VALUES (9, 'Books & Liberary', NULL, 'features', 'Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu.', '{\"button_text\":\"Read More\",\"button_url\":\"#\",\"icon\":\"fas fa-book-reader\"}', NULL, NULL, 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `color1`, `color2`, `branch_id`, `active`) VALUES (10, 'Trending Courses', NULL, 'features', 'Nulla metus metus ullamcorper vel tincidunt sed euismod nibh Quisque volutpat condimentum velit class aptent taciti sociosqu.', '{\"button_text\":\"Read More\",\"button_url\":\"#\",\"icon\":\"fab fa-discourse\"}', NULL, NULL, 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `color1`, `color2`, `branch_id`, `active`) VALUES (11, 'WHAT PEOPLE SAYS', NULL, 'testimonial', 'Fusce sem dolor, interdum in efficitur at, faucibus nec lorem. Sed nec molestie justo.', '', NULL, NULL, 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `color1`, `color2`, `branch_id`, `active`) VALUES (12, '20 years experience in the field of study', NULL, 'statistics', 'Lorem Ipsum is simply dummy text printer took a galley of type and scrambled it to make a type specimen book.', '{\"image\":\"counter-parallax1.jpg\",\"widget_title_1\":\"Certified Teachers\",\"widget_icon_1\":\"fas fa-user-tie\",\"type_1\":\"teacher\",\"widget_title_2\":\"Students Enrolled\",\"widget_icon_2\":\"fas fa-user-graduate\",\"type_2\":\"student\",\"widget_title_3\":\"Classes\",\"widget_icon_3\":\"fas fa-graduation-cap\",\"type_3\":\"class\",\"widget_title_4\":\"Section\",\"widget_icon_4\":\"fas fa-award\",\"type_4\":\"section\"}', NULL, NULL, 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `color1`, `color2`, `branch_id`, `active`) VALUES (13, 'আপনাকে রূপনগর আবাসিক হাই স্কুলে স্বাগতম', NULL, 'slider', 'আমাদের কিছু সেবা সমূহ', '{\"position\":\"c-left\",\"button_text1\":\"\\u09b0\\u09c7\\u099c\\u09be\\u09b2\\u09cd\\u099f\",\"button_url1\":\"#\",\"button_text2\":\"\\u0985\\u09a8\\u09b2\\u09be\\u0987\\u09a8 \\u098f\\u09a1\\u09ae\\u09bf\\u09b6\\u09a8\",\"button_url2\":\"#\",\"image\":\"home-slider-1695371258.jpg\"}', NULL, NULL, 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `color1`, `color2`, `branch_id`, `active`) VALUES (14, 'আপনাকে রূপনগর আবাসিক হাই স্কুলে স্বাগতম', NULL, 'slider', 'আমাদের কিছু সেবা সমূহ', '{\"position\":\"c-left\",\"button_text1\":\"\\u09b0\\u09c7\\u099c\\u09be\\u09b2\\u09cd\\u099f\",\"button_url1\":\"#\",\"button_text2\":\"\\u0985\\u09a8\\u09b2\\u09be\\u0987\\u09a8 \\u098f\\u09a1\\u09ae\\u09bf\\u09b6\\u09a8\",\"button_url2\":\"#\",\"image\":\"home-slider-1695371380.jpg\"}', NULL, NULL, 1, 1);
INSERT INTO `front_cms_home` (`id`, `title`, `subtitle`, `item_type`, `description`, `elements`, `color1`, `color2`, `branch_id`, `active`) VALUES (15, 'আপনাকে রূপনগর আবাসিক হাই স্কুলে স্বাগতম', NULL, 'slider', 'আমাদের কিছু সেবা সমূহ', '{\"position\":\"c-left\",\"button_text1\":\"\\u09b0\\u09c7\\u099c\\u09be\\u09b2\\u09cd\\u099f\",\"button_url1\":\"#\",\"button_text2\":\"\\u0985\\u09a8\\u09b2\\u09be\\u0987\\u09a8 \\u098f\\u09a1\\u09ae\\u09bf\\u09b6\\u09a8\",\"button_url2\":\"#\",\"image\":\"home-slider-1695371409.png\"}', NULL, NULL, 1, 1);


#
# TABLE STRUCTURE FOR: front_cms_home_seo
#

DROP TABLE IF EXISTS `front_cms_home_seo`;

CREATE TABLE `front_cms_home_seo` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `meta_keyword` text NOT NULL,
  `meta_description` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_home_seo` (`id`, `page_title`, `meta_keyword`, `meta_description`, `branch_id`) VALUES (1, 'Roup Nagar Abasik High School', 'Roup Nagar Abasik High School', 'Roup Nagar Abasik High School', 1);


#
# TABLE STRUCTURE FOR: front_cms_menu
#

DROP TABLE IF EXISTS `front_cms_menu`;

CREATE TABLE `front_cms_menu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(100) NOT NULL,
  `alias` varchar(100) NOT NULL,
  `ordering` int(11) NOT NULL,
  `parent_id` int(11) DEFAULT 0,
  `open_new_tab` int(11) NOT NULL DEFAULT 0,
  `ext_url` tinyint(3) NOT NULL DEFAULT 0,
  `ext_url_address` text DEFAULT NULL,
  `publish` tinyint(3) NOT NULL,
  `system` tinyint(3) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (1, 'Home', '', 1, 0, 0, 0, '', 1, 1, 0, '2019-08-09 08:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (2, 'Events', 'events', 3, 0, 0, 0, '', 1, 1, 0, '2019-08-09 08:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (3, 'Teachers', 'teachers', 2, 0, 0, 0, '', 1, 1, 0, '2019-08-09 08:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (4, 'About Us', 'about', 4, 0, 0, 0, '', 1, 1, 0, '2019-08-09 08:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (5, 'FAQ', 'faq', 5, 0, 0, 0, '', 1, 1, 0, '2019-08-09 08:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (6, 'Online Admission', 'admission', 6, 0, 0, 0, '', 1, 1, 0, '2019-08-09 08:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (7, 'Contact Us', 'contact', 9, 0, 0, 0, '', 1, 1, 0, '2019-08-09 08:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (8, 'Pages', 'pages', 8, 0, 0, 1, '#', 1, 1, 0, '2019-08-09 08:18:54');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (9, 'Admit Card', 'admit_card', 10, 8, 0, 0, '', 1, 1, 0, '2021-03-16 00:24:32');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (10, 'Exam Results', 'exam_results', 11, 8, 0, 0, '', 1, 1, 0, '2021-03-16 00:24:32');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (13, 'Certificates', 'certificates', 14, 8, 0, 0, '', 1, 1, 0, '2021-03-21 08:04:44');
INSERT INTO `front_cms_menu` (`id`, `title`, `alias`, `ordering`, `parent_id`, `open_new_tab`, `ext_url`, `ext_url_address`, `publish`, `system`, `branch_id`, `created_at`) VALUES (14, 'Gallery', 'gallery', 7, 0, 0, 0, '', 1, 1, 0, '2021-03-21 08:04:44');


#
# TABLE STRUCTURE FOR: front_cms_menu_visible
#

DROP TABLE IF EXISTS `front_cms_menu_visible`;

CREATE TABLE `front_cms_menu_visible` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) DEFAULT NULL,
  `menu_id` int(11) NOT NULL,
  `parent_id` varchar(11) DEFAULT NULL,
  `ordering` varchar(20) DEFAULT NULL,
  `invisible` tinyint(2) NOT NULL DEFAULT 1,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_menu_visible` (`id`, `name`, `menu_id`, `parent_id`, `ordering`, `invisible`, `branch_id`) VALUES (2, 'নোটিশ', 5, '0', '5', 0, 1);


#
# TABLE STRUCTURE FOR: front_cms_pages
#

DROP TABLE IF EXISTS `front_cms_pages`;

CREATE TABLE `front_cms_pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) NOT NULL,
  `content` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `menu_id` int(11) NOT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: front_cms_services
#

DROP TABLE IF EXISTS `front_cms_services`;

CREATE TABLE `front_cms_services` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `parallax_image` varchar(255) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_services` (`id`, `title`, `subtitle`, `parallax_image`, `branch_id`) VALUES (1, 'Get Well Soon', 'Our Best <span>Services</span>', 'service_parallax1.jpg', 1);


#
# TABLE STRUCTURE FOR: front_cms_services_list
#

DROP TABLE IF EXISTS `front_cms_services_list`;

CREATE TABLE `front_cms_services_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (1, 'Online Course Facilities', 'Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text.', 'fas fa-headphones', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (2, 'Modern Book Library', 'Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover.', 'fas fa-book-open', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (3, 'Be Industrial Leader', 'Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model.', 'fas fa-industry', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (4, 'Programming Courses', 'Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will.', 'fas fa-code', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (5, 'Foreign Languages', 'Making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover.', 'fas fa-language', 1);
INSERT INTO `front_cms_services_list` (`id`, `title`, `description`, `icon`, `branch_id`) VALUES (6, 'Alumni Directory', 'Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a for \'lorem ipsum\' will uncover.', 'fas fa-user-graduate', 1);


#
# TABLE STRUCTURE FOR: front_cms_setting
#

DROP TABLE IF EXISTS `front_cms_setting`;

CREATE TABLE `front_cms_setting` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `application_title` varchar(255) NOT NULL,
  `url_alias` varchar(255) DEFAULT NULL,
  `cms_active` tinyint(4) NOT NULL DEFAULT 0,
  `online_admission` tinyint(4) NOT NULL DEFAULT 0,
  `theme` varchar(255) NOT NULL,
  `captcha_status` varchar(20) NOT NULL,
  `recaptcha_site_key` varchar(255) NOT NULL,
  `recaptcha_secret_key` varchar(255) NOT NULL,
  `address` varchar(350) NOT NULL,
  `mobile_no` varchar(60) NOT NULL,
  `fax` varchar(60) NOT NULL,
  `receive_contact_email` varchar(255) NOT NULL,
  `email` varchar(60) NOT NULL,
  `copyright_text` varchar(255) NOT NULL,
  `fav_icon` varchar(255) NOT NULL,
  `logo` varchar(255) NOT NULL,
  `footer_about_text` varchar(300) NOT NULL,
  `working_hours` varchar(300) NOT NULL,
  `google_analytics` text DEFAULT NULL,
  `primary_color` varchar(100) NOT NULL DEFAULT '#ff685c',
  `menu_color` varchar(100) NOT NULL DEFAULT '#fff',
  `hover_color` varchar(100) NOT NULL DEFAULT '#f04133',
  `text_color` varchar(100) NOT NULL DEFAULT '#232323',
  `text_secondary_color` varchar(100) NOT NULL DEFAULT '#383838',
  `footer_background_color` varchar(100) NOT NULL DEFAULT '#383838',
  `footer_text_color` varchar(100) NOT NULL DEFAULT '#8d8d8d',
  `copyright_bg_color` varchar(100) NOT NULL DEFAULT '#262626',
  `copyright_text_color` varchar(100) NOT NULL DEFAULT '#8d8d8d',
  `border_radius` varchar(100) NOT NULL DEFAULT '0',
  `facebook_url` varchar(100) NOT NULL,
  `twitter_url` varchar(100) NOT NULL,
  `youtube_url` varchar(100) NOT NULL,
  `google_plus` varchar(100) NOT NULL,
  `linkedin_url` varchar(100) NOT NULL,
  `pinterest_url` varchar(100) NOT NULL,
  `instagram_url` varchar(100) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_setting` (`id`, `application_title`, `url_alias`, `cms_active`, `online_admission`, `theme`, `captcha_status`, `recaptcha_site_key`, `recaptcha_secret_key`, `address`, `mobile_no`, `fax`, `receive_contact_email`, `email`, `copyright_text`, `fav_icon`, `logo`, `footer_about_text`, `working_hours`, `google_analytics`, `primary_color`, `menu_color`, `hover_color`, `text_color`, `text_secondary_color`, `footer_background_color`, `footer_text_color`, `copyright_bg_color`, `copyright_text_color`, `border_radius`, `facebook_url`, `twitter_url`, `youtube_url`, `google_plus`, `linkedin_url`, `pinterest_url`, `instagram_url`, `branch_id`) VALUES (1, 'রূপনগর আবাসিক হাই স্কুল', 'roupnagar', 1, 1, 'red', 'disable', '', '', 'House: Munshi Bari, Beside Nayar Hat High School, Borobari, Lalmonir Hat', '+8801775457008', '017554570008', 'info@elitedesig.com.bd', 'info@elitedesign.com.bd', 'কপিরাইট © ২,০২৩ সর্বস্বত্ব সংরক্ষিত, রুপ নগর আবাসিক হাই স্কুল', 'fav_icon1.png', 'logo1.png', 'If you are going to use a passage LorIsum, you anythirassing hidden in the middle of text. Lators on the Internet tend to.', '<span>Hours : </span>  শনি   থেকে  ব্রিস্প্রতিবার - সকাল ০৮  থেকে  বিকাল ৪ পযন্ত,  শুক্রবার সাপ্তাহিক ছুটির দিন', '', '#2d8400', '#fff', '#288303', '#232323', '#8d8d8d', '#383838', '#8d8d8d', '#262626', '#8d8d8d', '0', 'https://facebook.com', 'https://twitter.com', 'https://youtube.com', 'https://google.com', 'https://linkedin.com', 'https://pinterest.com', 'https://instagram.com', 1);


#
# TABLE STRUCTURE FOR: front_cms_teachers
#

DROP TABLE IF EXISTS `front_cms_teachers`;

CREATE TABLE `front_cms_teachers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `page_title` varchar(255) DEFAULT NULL,
  `banner_image` varchar(255) DEFAULT NULL,
  `meta_description` text NOT NULL,
  `meta_keyword` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_teachers` (`id`, `page_title`, `banner_image`, `meta_description`, `meta_keyword`, `branch_id`) VALUES (1, 'শিক্ষকবৃন্দ', 'teachers1.png', 'শিক্ষকবৃন্দ', 'শিক্ষকবৃন্দ', 1);


#
# TABLE STRUCTURE FOR: front_cms_testimonial
#

DROP TABLE IF EXISTS `front_cms_testimonial`;

CREATE TABLE `front_cms_testimonial` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `surname` varchar(355) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `rank` int(5) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (1, 'Gartrell Wright', 'Los Angeles', 'defualt.png', 'Intexure have done an excellent job presenting the analysis & insights. I am confident in saying  have helped encounter  is to be welcomed and every pain avoided”.', 1, 1, 1, '2019-08-23 08:26:42');
INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (2, 'Clifton Hyde', 'Newyork City', 'defualt.png', '“Owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted always holds”.', 4, 1, 1, '2019-08-23 08:26:42');
INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (3, 'Emily Lemus', 'Los Angeles', 'defualt.png', '“Intexure have done an excellent job presenting the analysis & insights. I am confident in saying  have helped encounter  is to be welcomed and every pain avoided”.', 5, 1, 1, '2019-08-23 08:26:42');
INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (4, 'Michel Jhon', 'CEO', 'defualt.png', '“Owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted always holds”.', 3, 2, 1, '2019-08-23 08:26:42');
INSERT INTO `front_cms_testimonial` (`id`, `name`, `surname`, `image`, `description`, `rank`, `branch_id`, `created_by`, `created_at`) VALUES (5, 'Hilda Howard', 'Chicago City', 'defualt.png', '“Owing to the claims of duty or the obligations of business it will frequently occur that pleasures have to be repudiated and annoyances accepted always holds”.', 4, 2, 1, '2019-08-23 08:26:42');


#
# TABLE STRUCTURE FOR: global_settings
#

DROP TABLE IF EXISTS `global_settings`;

CREATE TABLE `global_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `institute_name` varchar(255) NOT NULL,
  `institution_code` varchar(255) NOT NULL,
  `reg_prefix` varchar(255) NOT NULL,
  `institute_email` varchar(100) NOT NULL,
  `address` text NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `currency` varchar(100) NOT NULL,
  `currency_symbol` varchar(100) NOT NULL,
  `sms_service_provider` varchar(100) NOT NULL,
  `session_id` int(11) NOT NULL,
  `translation` varchar(100) NOT NULL,
  `footer_text` varchar(255) NOT NULL,
  `animations` varchar(100) NOT NULL,
  `timezone` varchar(100) NOT NULL,
  `date_format` varchar(100) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `facebook_url` varchar(255) NOT NULL,
  `twitter_url` varchar(255) NOT NULL,
  `linkedin_url` varchar(255) NOT NULL,
  `youtube_url` varchar(255) NOT NULL,
  `cron_secret_key` varchar(255) DEFAULT NULL,
  `preloader_backend` tinyint(1) NOT NULL DEFAULT 1,
  `footer_branch_switcher` tinyint(1) NOT NULL DEFAULT 1,
  `cms_default_branch` int(11) NOT NULL,
  `image_extension` text DEFAULT NULL,
  `image_size` float NOT NULL DEFAULT 1024,
  `file_extension` text DEFAULT NULL,
  `pid` varchar(255) DEFAULT NULL,
  `file_size` float DEFAULT 1024,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `global_settings` (`id`, `institute_name`, `institution_code`, `reg_prefix`, `institute_email`, `address`, `mobileno`, `currency`, `currency_symbol`, `sms_service_provider`, `session_id`, `translation`, `footer_text`, `animations`, `timezone`, `date_format`, `facebook_url`, `twitter_url`, `linkedin_url`, `youtube_url`, `cron_secret_key`, `preloader_backend`, `footer_branch_switcher`, `cms_default_branch`, `image_extension`, `image_size`, `file_extension`, `pid`, `file_size`, `created_at`, `updated_at`) VALUES (1, 'Roup Nagar Abasik High School', 'RAHS-89852224', 'on', 'info@elitedesign.com.bd', 'House: Munshi Bari, Beside nayar hat High School,Boro Bari, lalmonir hat', '01775457008', 'BDT', 'TK', 'disabled', 6, 'english', 'কপিরাইট © ২,০২৩ সর্বস্বত্ব সংরক্ষিত, রুপ নগর আবাসিক হাই স্কুল', 'fadeInUp', 'Asia/Dhaka', 'd.M.Y', 'https://facebook.com/elitedesignbd', 'https://facebook.com/elitedesignbd', 'https://facebook.com/elitedesignbd', 'https://facebook.com/elitedesignbd', 'e26887217890d195423c73fdfdb5735b', 2, 1, 1, 'jpeg, jpg, bmp, png', '2048', 'txt, pdf, doc, xls, docx, xlsx, jpg, jpeg, png, gif, bmp, zip, mp4, 7z, wmv, rar', 'ZDk2MTZhM2EtYTI3Ny00NmMwLWEzNWQtNzMwMDYzYWFkYjgx', '10000', '2023-09-22 04:05:28', '0000-00-00 00:00:00');


#
# TABLE STRUCTURE FOR: grade
#

DROP TABLE IF EXISTS `grade`;

CREATE TABLE `grade` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `grade_point` varchar(255) NOT NULL,
  `lower_mark` int(11) NOT NULL,
  `upper_mark` int(11) NOT NULL,
  `remark` text NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `grade` (`id`, `name`, `grade_point`, `lower_mark`, `upper_mark`, `remark`, `branch_id`) VALUES (1, 'A+', '5.0', 80, 100, 'Excellent! ', 1);
INSERT INTO `grade` (`id`, `name`, `grade_point`, `lower_mark`, `upper_mark`, `remark`, `branch_id`) VALUES (2, 'A', '4', 70, 79, 'Very Good ', 1);
INSERT INTO `grade` (`id`, `name`, `grade_point`, `lower_mark`, `upper_mark`, `remark`, `branch_id`) VALUES (3, 'A-', '3.5', 60, 65, 'Good', 1);
INSERT INTO `grade` (`id`, `name`, `grade_point`, `lower_mark`, `upper_mark`, `remark`, `branch_id`) VALUES (4, 'B', '3', 50, 59, 'Average ', 1);
INSERT INTO `grade` (`id`, `name`, `grade_point`, `lower_mark`, `upper_mark`, `remark`, `branch_id`) VALUES (5, 'C', '2.5', 40, 49, 'Adequate', 1);
INSERT INTO `grade` (`id`, `name`, `grade_point`, `lower_mark`, `upper_mark`, `remark`, `branch_id`) VALUES (6, 'D', '2', 33, 39, 'Poor', 1);
INSERT INTO `grade` (`id`, `name`, `grade_point`, `lower_mark`, `upper_mark`, `remark`, `branch_id`) VALUES (7, 'F', '0', 0, 32, 'Fail', 1);


#
# TABLE STRUCTURE FOR: hall_allocation
#

DROP TABLE IF EXISTS `hall_allocation`;

CREATE TABLE `hall_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `hall_no` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: homework
#

DROP TABLE IF EXISTS `homework`;

CREATE TABLE `homework` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `date_of_homework` date NOT NULL,
  `date_of_submission` date NOT NULL,
  `description` text NOT NULL,
  `created_by` int(11) NOT NULL,
  `create_date` date NOT NULL,
  `status` varchar(10) NOT NULL,
  `sms_notification` tinyint(2) NOT NULL,
  `schedule_date` date DEFAULT NULL,
  `document` varchar(255) NOT NULL,
  `evaluation_date` date DEFAULT NULL,
  `evaluated_by` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `homework` (`id`, `class_id`, `section_id`, `session_id`, `subject_id`, `date_of_homework`, `date_of_submission`, `description`, `created_by`, `create_date`, `status`, `sms_notification`, `schedule_date`, `document`, `evaluation_date`, `evaluated_by`, `branch_id`) VALUES (1, 1, 1, 6, 1, '2023-09-26', '2023-09-26', '<p>Make Home Work</p>', 1, '2023-09-25', '0', 1, NULL, 'Screenshot_1.png', NULL, 0, 1);


#
# TABLE STRUCTURE FOR: homework_evaluation
#

DROP TABLE IF EXISTS `homework_evaluation`;

CREATE TABLE `homework_evaluation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `homework_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `remark` text NOT NULL,
  `rank` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: homework_submit
#

DROP TABLE IF EXISTS `homework_submit`;

CREATE TABLE `homework_submit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `homework_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `message` varchar(355) NOT NULL,
  `enc_name` varchar(355) DEFAULT NULL,
  `file_name` varchar(355) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: hostel
#

DROP TABLE IF EXISTS `hostel`;

CREATE TABLE `hostel` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `category_id` int(11) NOT NULL,
  `address` longtext NOT NULL,
  `watchman` longtext NOT NULL,
  `remarks` longtext DEFAULT NULL,
  `branch_id` int(11) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: hostel_category
#

DROP TABLE IF EXISTS `hostel_category`;

CREATE TABLE `hostel_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `description` longtext DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `type` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: hostel_room
#

DROP TABLE IF EXISTS `hostel_room`;

CREATE TABLE `hostel_room` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `hostel_id` int(11) NOT NULL,
  `no_beds` int(11) NOT NULL,
  `category_id` int(11) DEFAULT NULL,
  `bed_fee` decimal(18,2) NOT NULL,
  `remarks` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: language_list
#

DROP TABLE IF EXISTS `language_list`;

CREATE TABLE `language_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(600) NOT NULL,
  `lang_field` varchar(600) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (1, 'English', 'english', 1, '2018-11-15 06:36:31', '2020-04-18 20:05:12');
INSERT INTO `language_list` (`id`, `name`, `lang_field`, `status`, `created_at`, `updated_at`) VALUES (2, 'Bengali', 'bengali', 1, '2018-11-15 06:36:31', '2018-12-04 15:41:50');


#
# TABLE STRUCTURE FOR: languages
#

DROP TABLE IF EXISTS `languages`;

CREATE TABLE `languages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `word` varchar(255) NOT NULL,
  `english` varchar(255) NOT NULL,
  `bengali` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1286 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1, 'language', 'Language', 'ভাষা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (2, 'attendance_overview', 'Attendance Overview', 'উপস্থিতি পরিদর্শন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (3, 'annual_fee_summary', 'Annual Fee Summary', 'বার্ষিক ফি সংক্ষিপ্ত বিবরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (4, 'my_annual_attendance_overview', 'My Annual Attendance Overview', 'আমার বার্ষিক উপস্থিতি পরিদর্শন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (5, 'schedule', 'Schedule', 'সময়সূচী');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (6, 'student_admission', 'Student Admission', 'ছাত্র ভর্তি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (7, 'returned', 'Returned', 'ফেরৎ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (8, 'user_name', 'User Name', 'ব্যবহারকারীর নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (9, 'rejected', 'Rejected', 'প্রত্যাখ্যাত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (10, 'route_name', 'Route Name', 'রুট নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (11, 'route_fare', 'Route Fare', 'রুট ভাড়া');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (12, 'edit_route', 'Edit Route', 'সম্পাদন করা রুট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (13, 'this_value_is_required', 'This value is required.', 'এই মান প্রয়োজন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (14, 'vehicle_no', 'Vehicle No', 'যানবাহন নং');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (15, 'insurance_renewal_date', 'Insurance Renewal Date', 'বীমা নবায়ন তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (16, 'driver_name', 'Driver Name', 'ড্রাইভারের নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (17, 'driver_license', 'Driver License', 'চালকের অনুমোদন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (18, 'select_route', 'Select Route', 'রুট নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (19, 'edit_vehicle', 'Edit Vehicle', 'যানবাহন সম্পাদনা করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (20, 'add_students', 'Add Students', 'ছাত্রদের যোগ করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (21, 'vehicle_number', 'Vehicle Number', 'যানবাহন সংখ্যা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (22, 'select_route_first', 'Select Route First', 'রুট প্রথম নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (23, 'transport_fee', 'Transport Fee', 'পরিবহন ফি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (24, 'control', 'Control', 'নিয়ন্ত্রণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (25, 'set_students', 'Set Students', 'ছাত্রদের সেট করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (26, 'hostel_list', 'Hostel List', 'হোস্টেল তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (27, 'watchman_name', 'Watchman Name', 'ওয়াচম্যান নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (28, 'hostel_address', 'Hostel Address', 'হোস্টেল ঠিকানা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (29, 'edit_hostel', 'Edit Hostel', 'হোস্টেল সম্পাদনা করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (30, 'room_name', 'Room Name', 'রুমের নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (31, 'no_of_beds', 'No Of Beds', 'শয্যা সংখ্যা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (32, 'select_hostel_first', 'Select Hostel First', 'হোস্টেল প্রথম নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (33, 'remaining', 'Remaining', 'অবশিষ্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (34, 'hostel_fee', 'Hostel Fee', 'হোস্টেল ফি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (35, 'accountant_list', 'Accountant List', 'অ্যাকাউন্টেন্ট তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (36, 'students_fees', 'Students Fees', 'ছাত্র ফি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (37, 'fees_status', 'Fees Status', 'ফি স্থিতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (38, 'books', 'Books', 'বই');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (39, 'home_page', 'Home Page', 'হোম পেজ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (40, 'collected', 'Collected', 'সংগৃহীত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (41, 'student_mark', 'Student Mark', 'ছাত্র মার্ক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (42, 'select_exam_first', 'Select Exam First', 'নির্বাচন প্রথম নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (43, 'transport_details', 'Transport Details', 'পরিবহন বিবরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (44, 'no_of_teacher', 'No of Teacher', 'শিক্ষকের সংখ্যা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (45, 'basic_details', 'Basic Details', 'মৌলিক বিবরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (46, 'fee_progress', 'Fee Progress', 'ফি অগ্রগতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (47, 'word', 'Word', 'শব্দ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (48, 'book_category', 'Book Category', 'বই বিভাগ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (49, 'driver_phone', 'Driver Phone', 'ড্রাইভার ফোন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (50, 'invalid_csv_file', 'Invalid / Corrupted CSV File', 'অবৈধ / দূষিত CSV ফাইল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (51, 'requested_book_list', 'Requested Book List', 'অনুরোধকৃত বইয়ের তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (52, 'request_status', 'Request Status', 'অনুরোধ স্থিতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (53, 'book_request', 'Book Request', 'বইয়ের অনুরোধ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (54, 'logout', 'Logout', 'প্রস্থান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (55, 'select_payment_method', 'Select Payment Method', 'পেমেন্ট পদ্ধতি নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (56, 'select_method', 'Select Method', 'পদ্ধতি নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (57, 'payment', 'Payment', 'প্রদান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (58, 'filter', 'Filter', 'ছাঁকনি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (59, 'status', 'Status', 'অবস্থা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (60, 'paid', 'Paid', 'অর্থ প্রদান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (61, 'unpaid', 'Unpaid', 'অবৈতনিক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (62, 'method', 'Method', 'পদ্ধতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (63, 'cash', 'Cash', 'নগদ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (64, 'check', 'Check', 'চেক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (65, 'card', 'Card', 'কার্ড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (66, 'payment_history', 'Payment History', 'অর্থ প্রদান ইতিহাস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (67, 'category', 'Category', 'বিভাগ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (68, 'book_list', 'Book List', 'পাঠ্যতালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (69, 'author', 'Author', 'লেখক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (70, 'price', 'Price', 'মূল্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (71, 'available', 'Available', 'সহজলভ্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (72, 'unavailable', 'Unavailable', 'অপ্রাপ্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (73, 'transport_list', 'Transport List', 'পরিবহন তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (74, 'edit_transport', 'Edit Transport', 'পরিবহন সম্পাদনা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (75, 'hostel_name', 'Hostel Name', 'হোস্টেল নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (76, 'number_of_room', 'Hostel Of Room', 'রুম নম্বর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (77, 'yes', 'Yes', 'হাঁ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (78, 'no', 'No', 'না');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (79, 'messages', 'Messages', 'বার্তা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (80, 'compose', 'Compose', 'নতুন বার্তা লিখতে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (81, 'recipient', 'Recipient', 'প্রাপক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (82, 'select_a_user', 'Select A User', 'নির্বাচন একটি ব্যবহারকারী');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (83, 'send', 'Send', 'পাঠান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (84, 'global_settings', 'Global Settings', 'সার্বজনীন নির্ধারণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (85, 'currency', 'Currency', 'মুদ্রা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (86, 'system_email', 'System Email', 'সিস্টেম ইমেইল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (87, 'create', 'Create', 'সৃষ্টি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (88, 'save', 'Save', 'সংরক্ষণ করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (89, 'file', 'File', 'ফাইল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (90, 'theme_settings', 'Theme Settings', 'থিম সেটিংস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (91, 'default', 'Default', 'ডিফল্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (92, 'select_theme', 'Select Theme', 'থিম নির্বাচন কর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (93, 'upload_logo', 'Upload Logo', 'লোগো আপলোড করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (94, 'upload', 'Upload', 'আপলোড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (95, 'remember', 'Remember', 'স্মরণ করা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (96, 'not_selected', 'Not Selected', 'অনির্বাচিত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (97, 'disabled', 'Disabled', 'অক্ষম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (98, 'inactive_account', 'Inactive Account', 'নিষ্ক্রিয় অ্যাকাউন্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (99, 'update_translations', 'Update Translations', 'আপডেট অনুবাদ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (100, 'language_list', 'Language List', 'নতুন ভাষাটি তালিকায় আগে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (101, 'option', 'Option', 'পছন্দ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (102, 'edit_word', 'Edit Word', 'শব্দ সম্পাদনা করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (103, 'update_profile', 'Update Profile', 'প্রফাইল হালনাগাদ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (104, 'current_password', 'Current Password', 'বর্তমান পাসওয়ার্ড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (105, 'new_password', 'New Password', 'নতুন পাসওয়ার্ড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (106, 'login', 'Login', 'লগইন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (107, 'reset_password', 'Reset Password', 'পাসওয়ার্ড রিসেট করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (108, 'present', 'Present', 'হাজির');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (109, 'absent', 'Absent', 'অনুপস্থিত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (110, 'update_attendance', 'Update Attendance', 'আপডেট এ্যাটেনডেন্স');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (111, 'undefined', 'Undefined', 'অনির্দিষ্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (112, 'back', 'Back', 'পিছনে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (113, 'save_changes', 'Save Changes', 'পরিবর্তনগুলোর সংরক্ষন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (114, 'uploader', 'Uploader', 'আপলোডার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (115, 'download', 'Download', 'ডাউনলোড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (116, 'remove', 'Remove', 'অপসারণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (117, 'print', 'Print', 'ছাপানো');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (118, 'select_file_type', 'Select File Type', 'নির্বাচন ফাইল টাইপ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (119, 'excel', 'Excel', 'সীমা অতিক্রম করা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (120, 'other', 'Other', 'অন্যান্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (121, 'students_of_class', 'Students Of Class', 'ক্লাস ছাত্রদের');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (122, 'marks_obtained', 'Marks Obtained', 'প্রাপ্ত নম্বর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (123, 'attendance_for_class', 'Attendance For Class', 'এ্যাটেনডেন্স বর্গ জন্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (124, 'receiver', 'Receiver', 'গ্রাহক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (125, 'please_select_receiver', 'Please Select Receiver', 'দয়া করে রিসিভার নির্বাচন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (126, 'session_changed', 'Session Changed', 'সেশন পরিবর্তিত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (127, 'exam_marks', 'Exam Marks', 'পরীক্ষার মার্কস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (128, 'total_mark', 'Total Mark', 'মোট মার্ক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (129, 'mark_obtained', 'Mark Obtained', 'মার্ক প্রাপ্ত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (130, 'invoice/payment_list', 'Invoice / Payment List', 'ইনভয়েস / পেমেন্ট তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (131, 'obtained_marks', 'Obtained Marks', 'প্রাপ্ত মার্কস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (132, 'highest_mark', 'Highest Mark', 'সর্বোচ্চ মার্ক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (133, 'grade', 'Grade (GPA)', 'শ্রেণী');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (134, 'dashboard', 'Dashboard', 'ড্যাশবোর্ড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (135, 'student', 'Student', 'ছাত্র');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (136, 'rename', 'Rename', 'নামান্তর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (137, 'class', 'Class', 'শ্রেণী');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (138, 'teacher', 'Teacher', 'শিক্ষক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (139, 'parents', 'Parents', 'মাতাপিতা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (140, 'subject', 'Subject', 'বিষয়');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (141, 'student_attendance', 'Student Attendance', 'ছাত্র উপস্থিতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (142, 'exam_list', 'Exam List', 'পরীক্ষার তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (143, 'grades_range', 'Grades Range', 'গ্রেড পরিসীমা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (144, 'loading', 'Loading', 'বোঝাই');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (145, 'library', 'Library', 'লাইব্রেরি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (146, 'hostel', 'Hostel', 'ছাত্রাবাস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (147, 'events', 'Events', 'সূচনাফলক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (148, 'message', 'Message', 'বার্তা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (149, 'translations', 'Translations', 'অনুবাদের');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (150, 'account', 'Account', 'হিসাব');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (151, 'selected_session', 'Selected Session', 'নির্বাচিত সেশন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (152, 'change_password', 'Change Password', 'পাসওয়ার্ড পরিবর্তন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (153, 'section', 'Section', 'অধ্যায়');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (154, 'edit', 'Edit', 'সম্পাদন করা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (155, 'delete', 'Delete', 'মুছে ফেলা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (156, 'cancel', 'Cancel', 'বাতিল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (157, 'parent', 'Parent', 'মাতা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (158, 'attendance', 'Attendance', 'উপস্থিতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (159, 'addmission_form', 'Admission Form', 'ভর্তির ফর্ম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (160, 'name', 'Name', 'নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (161, 'select', 'Select', 'নির্বাচন করা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (162, 'roll', 'Roll', 'রোল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (163, 'birthday', 'Date Of Birth', 'জন্ম তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (164, 'gender', 'Gender', 'লিঙ্গ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (165, 'male', 'Male', 'পুরুষ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (166, 'female', 'Female', 'মহিলা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (167, 'address', 'Address', 'ঠিকানা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (168, 'phone', 'Phone', 'ফোন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (169, 'email', 'Email', 'ই-মেইল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (170, 'password', 'Password', 'পাসওয়ার্ড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (171, 'transport_route', 'Transport Route', 'পরিবহন রুট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (172, 'photo', 'Photo', 'ছবি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (173, 'select_class', 'Select Class', 'ক্লাস নির্বাচন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (174, 'username_password_incorrect', 'Username Or Password Is Incorrect', 'ব্যাবহারকারীর নাম অথবা গোপন নাম্বারটি ভুল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (175, 'select_section', 'Select Section', 'অনুচ্ছেদ নির্বাচন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (176, 'options', 'Options', 'বিকল্প');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (177, 'mark_sheet', 'Mark Sheet', 'নাম্বার শিট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (178, 'profile', 'Profile', 'প্রোফাইলে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (179, 'select_all', 'Select All', 'সবগুলো নির্বাচন করা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (180, 'select_none', 'Select None', 'কিছুই না');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (181, 'average', 'Average', 'গড়');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (182, 'transfer', 'Transfer', 'হস্তান্তর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (183, 'edit_teacher', 'Edit Teacher', 'গুরু সম্পাদনা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (184, 'sex', 'Sex', 'লিঙ্গ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (185, 'marksheet_for', 'Marksheet For', 'মার্ক শীট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (186, 'total_marks', 'Total Marks', 'মোট মার্কস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (187, 'parent_phone', 'Parent Phone', 'পেরেন্ট ফোন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (188, 'subject_author', 'Subject Author', 'বিষয় লেখক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (189, 'update', 'Update', 'হালনাগাদ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (190, 'class_list', 'Class List', 'ক্লাস তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (191, 'class_name', 'Class Name', 'শ্রেণির নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (192, 'name_numeric', 'Name Numeric', 'নাম সংখ্যাসূচক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (193, 'select_teacher', 'Select Teacher', 'গুরু নির্বাচন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (194, 'edit_class', 'Edit Class', 'ক্লাস সম্পাদনা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (195, 'section_name', 'Section Name', 'অনুচ্ছেদ নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (196, 'add_section', 'Add Section', 'অনুচ্ছেদ যোগ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (197, 'subject_list', 'Subject List', 'বিষয় তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (198, 'subject_name', 'Subject Name', 'বিষয় নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (199, 'edit_subject', 'Edit Subject', 'বিষয় সম্পাদনা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (200, 'day', 'Day', 'দিন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (201, 'starting_time', 'Starting Time', 'সময় শুরু');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (202, 'hour', 'Hour', 'ঘন্টা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (203, 'minutes', 'Minutes', 'মিনিট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (204, 'ending_time', 'Ending Time', 'সময় শেষ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (205, 'select_subject', 'Select Subject', 'বিষয় নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (206, 'select_date', 'Select Date', 'তারিখ নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (207, 'select_month', 'Select Month', 'মাস নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (208, 'select_year', 'Select Year', 'নির্বাচন বছর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (209, 'add_language', 'Add Language', 'ভাষা যোগ করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (210, 'exam_name', 'Exam Name', 'পরীক্ষার নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (211, 'date', 'Date', 'তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (212, 'comment', 'Comment', 'মন্তব্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (213, 'edit_exam', 'Edit Exam', 'পরীক্ষার সম্পাদনা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (214, 'grade_list', 'Grade List', 'গ্রেড তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (215, 'grade_name', 'Grade Name', 'গ্রেড নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (216, 'grade_point', 'Grade Point', 'গ্রেড পয়েন্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (217, 'select_exam', 'Select Exam', 'পরীক্ষার নির্বাচন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (218, 'students', 'Students', 'শিক্ষার্থীরা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (219, 'subjects', 'Subjects', 'প্রজাদের');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (220, 'total', 'Total', 'মোট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (221, 'select_academic_session', 'Select Academic Session', 'একাডেমিক সেশন নির্বাচন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (222, 'invoice_informations', 'Invoice Informations', 'চালান ইনফরমেশন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (223, 'title', 'Title', 'খেতাব');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (224, 'description', 'Description', 'বিবরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (225, 'payment_informations', 'Payment Informations', 'পেমেন্ট তথ্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (226, 'view_invoice', 'View Invoice', 'দেখুন চালান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (227, 'payment_to', 'Payment To', 'পরিশোদ করা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (228, 'bill_to', 'Bill To', 'বিল করতে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (229, 'total_amount', 'Total Amount', 'সর্বমোট পরিমাণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (230, 'paid_amount', 'Paid Amount', 'দেওয়া পরিমাণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (231, 'due', 'Due', 'দরুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (232, 'amount_paid', 'Amount Paid', 'পরিমাণ অর্থ প্রদান করা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (233, 'payment_successfull', 'Payment has been successful', 'পেমেন্ট সফল হয়েছে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (234, 'add_invoice/payment', 'Add Invoice/payment', 'ইনভয়েস / পেমেন্ট যোগ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (235, 'invoices', 'Invoices', 'ইনভয়েস বা চালান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (236, 'action', 'Action', 'কর্ম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (237, 'required', 'Required', 'প্রয়োজনীয়');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (238, 'info', 'Info', 'তথ্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (239, 'month', 'Month', 'মাস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (240, 'details', 'Details', 'বিস্তারিত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (241, 'new', 'New', 'নতুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (242, 'reply_message', 'Reply Message', 'বার্তা উত্তর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (243, 'message_sent', 'Message Sent', 'বার্তা পাঠানো');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (244, 'search', 'Search', 'অনুসন্ধান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (245, 'religion', 'Religion', 'ধর্ম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (246, 'blood_group', 'Blood group', 'রক্তের গ্রুপ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (247, 'database_backup', 'Database Backup', 'ডাটাবেজ ব্যাকআপ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (248, 'search', 'Search', 'অনুসন্ধান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (249, 'payments_history', 'Fees Pay / Invoice', 'ফি পরিশোধ / চালান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (250, 'message_restore', 'Message Restore', 'বার্তা পুনরুদ্ধার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (251, 'write_new_message', 'Write New Message', 'নতুন বার্তা লিখতে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (252, 'attendance_sheet', 'Attendance Sheet', 'এ্যাটেনডেন্স শীট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (253, 'holiday', 'Holiday', 'ছুটির দিন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (254, 'exam', 'Exam', 'পরীক্ষা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (255, 'successfully', 'Successfully', 'সফলভাবে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (256, 'admin', 'Admin', 'অ্যাডমিন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (257, 'inbox', 'Inbox', 'ইনবক্স');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (258, 'sent', 'Sent', 'প্রেরিত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (259, 'important', 'Important', 'গুরুত্বপূর্ণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (260, 'trash', 'Trash', 'আবর্জনা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (261, 'error', 'Unsuccessful', 'ব্যার্থ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (262, 'sessions_list', 'Sessions List', 'সেশন তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (263, 'session_settings', 'Session Settings', 'সেশন সেটিংস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (264, 'add_designation', 'Add Designation', 'পদবী যোগ করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (265, 'users', 'Users', 'ব্যবহারকারীরা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (266, 'librarian', 'Librarian', 'গ্রন্থাগারিক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (267, 'accountant', 'Accountant', 'হিসাবরক্ষক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (268, 'academics', 'Academics', 'বিদ্যালয় সংক্রান্ত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (269, 'employees_attendance', 'Employees Attendance', 'কর্মচারী উপস্থিতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (270, 'set_exam_term', 'Set Exam Term', 'টার্ম সেট করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (271, 'set_attendance', 'Set Attendance', 'উপস্থিতি সেট করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (272, 'marks', 'Marks', 'মার্কস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (273, 'books_category', 'Books Category', 'বই বিভাগ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (274, 'transport', 'Transport', 'পরিবহন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (275, 'fees', 'Fees', 'ফি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (276, 'fees_allocation', 'Fees Allocation', 'ফি বরাদ্দকরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (277, 'fee_category', 'Fee Category', 'ফি বিভাগ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (278, 'report', 'Report', 'প্রতিবেদন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (279, 'employee', 'Employee', 'কর্মচারী');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (280, 'invoice', 'Invoice', 'চালান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (281, 'event_catalogue', 'Event Catalogue', 'ইভেন্ট ক্যাটালগ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (282, 'total_paid', 'Total Paid', 'মোট দেওয়া');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (283, 'total_due', 'Total Due', 'মোট বাকি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (284, 'fees_collect', 'Fees Collect', 'ফি সংগ্রহ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (285, 'total_school_students_attendance', 'Total School Students Attendance', 'মোট স্কুলের ছাত্র উপস্থিতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (286, 'overview', 'Overview', 'সংক্ষিপ্ত বিবরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (287, 'currency_symbol', 'Currency Symbol', 'মুদ্রা প্রতীক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (288, 'enable', 'Enable', 'সক্ষম করা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (289, 'disable', 'Disable', 'অক্ষম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (290, 'payment_settings', 'Payment Settings', 'পেমেন্ট সেটিংস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (291, 'student_attendance_report', 'Student Attendance Report', 'ছাত্র উপস্থিতি রিপোর্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (292, 'attendance_type', 'Attendance Type', 'উপস্থিতি প্রকার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (293, 'late', 'Late', 'বিলম্বে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (294, 'employees_attendance_report', 'Employees Attendance Report', 'কর্মচারী উপস্থিতি রিপোর্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (295, 'attendance_report_of', 'Attendance Report Of', 'উপস্থিতি রিপোর্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (296, 'fee_paid_report', 'Fee Paid Report', 'ফি প্রদান প্রতিবেদন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (297, 'invoice_no', 'Invoice No', 'চালান নং');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (298, 'payment_mode', 'Payment Mode', 'পরিশোধের মাধ্যম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (299, 'payment_type', 'Payment Type', 'পেমেন্ট টাইপ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (300, 'done', 'Done', 'সম্পন্ন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (301, 'select_fee_category', 'Select Fee Category', 'ফি বিভাগ নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (302, 'discount', 'Discount', 'ডিসকাউন্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (303, 'enter_discount_amount', 'Enter Discount Amount', 'ছাড়ের পরিমাণ লিখুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (304, 'online_payment', 'Online Payment', 'দূরবর্তী অর্থ প্রদান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (305, 'student_name', 'Student Name', 'শিক্ষার্থীর নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (306, 'invoice_history', 'Invoice History', 'চালান ইতিহাস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (307, 'discount_amount', 'Discount Amount', 'হ্রাসকৃত মুল্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (308, 'invoice_list', 'Invoice List', 'চালান তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (309, 'partly_paid', 'Partly Paid', 'আংশিক পরিশোধিত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (310, 'fees_list', 'Fees List', 'ফি তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (311, 'voucher_id', 'Voucher ID', 'ভউচার আইডি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (312, 'transaction_date', 'Transaction Date', 'লেনদেন তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (313, 'admission_date', 'Admission Date', 'ভর্তির তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (314, 'user_status', 'User Status', 'ব্যবহারকারীর স্থিতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (315, 'nationality', 'Nationality', 'জাতীয়তা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (316, 'register_no', 'Register No', 'রেজিস্টার নং');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (317, 'first_name', 'First Name', 'প্রথম নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (318, 'last_name', 'Last Name', 'নামের শেষাংশ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (319, 'state', 'State', 'রাষ্ট্র');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (320, 'transport_vehicle_no', 'Transport Vehicle No', 'পরিবহন যানবাহন নং');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (321, 'percent', 'Percent', 'শতাংশ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (322, 'average_result', 'Average Result', 'গড় ফলাফল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (323, 'student_category', 'Student Category', 'ছাত্র বিভাগ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (324, 'category_name', 'Category Name', 'বিভাগ নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (325, 'category_list', 'Category List', 'বিভাগ তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (326, 'please_select_student_first', 'Please Select Students First', 'প্রথমে ছাত্রদের দয়া করে নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (327, 'designation', 'Designation', 'উপাধি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (328, 'qualification', 'Qualification', 'যোগ্যতা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (329, 'account_deactivated', 'Account Deactivated', 'অ্যাকাউন্ট নিষ্ক্রিয়');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (330, 'account_activated', 'Account Activated', 'অ্যাকাউন্ট সক্রিয়');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (331, 'designation_list', 'Designation List', 'পদবী তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (332, 'joining_date', 'Joining Date', 'যোগদান তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (333, 'relation', 'Relation', 'সম্পর্ক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (334, 'father_name', 'Father Name', 'বাবার নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (335, 'librarian_list', 'Librarian List', 'গ্রন্থাগারিক তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (336, 'class_numeric', 'Class Numeric', 'ক্লাস সাংখ্যিক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (337, 'maximum_students', 'Maximum Students', 'সর্বোচ্চ ছাত্র');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (338, 'class_room', 'Class Room', 'ক্লাস রুমে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (339, 'pass_mark', 'Pass Mark', 'পাশ নম্বর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (340, 'exam_time', 'Exam Time (Min)', 'পরীক্ষার সময় (মিনিট)');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (341, 'time', 'Time', 'সময়');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (342, 'subject_code', 'Subject Code', 'বিষয় কোড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (343, 'full_mark', 'Full Mark', 'পুরো নম্বর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (344, 'subject_type', 'Subject Type', 'বিষয় প্রকার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (345, 'date_of_publish', 'Date Of Publish', 'প্রকাশের তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (346, 'file_name', 'File Name', 'ফাইলের নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (347, 'students_list', 'Students List', 'ছাত্র তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (348, 'start_date', 'Start Date', 'শুরুর তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (349, 'end_date', 'End Date', 'শেষ তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (350, 'term_name', 'Term Name', 'টার্ম নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (351, 'grand_total', 'Grand Total', 'সর্বমোট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (352, 'result', 'Result', 'ফল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (353, 'books_list', 'Books List', 'বই তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (354, 'book_isbn_no', 'Book ISBN No', 'বই ISBN নং');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (355, 'total_stock', 'Total Stock', 'মোট স্টক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (356, 'issued_copies', 'Issued Copies', 'ইস্যু করা কপি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (357, 'publisher', 'Publisher', 'প্রকাশক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (358, 'books_issue', 'Books Issue', 'বই ইস্যু');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (359, 'user', 'User', 'ব্যবহারকারী');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (360, 'fine', 'Fine', 'জরিমানা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (361, 'pending', 'Pending', 'অনিষ্পন্ন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (362, 'return_date', 'Return Date', 'প্রত্যাবর্তন তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (363, 'accept', 'Accept', 'গ্রহণ করা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (364, 'reject', 'Reject', 'প্রত্যাখ্যান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (365, 'issued', 'Issued', 'ইস্যু করা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (366, 'return', 'Return', 'প্রত্যাবর্তন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (367, 'renewal', 'Renewal', 'পুনরারম্ভ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (368, 'fine_amount', 'Fine Amount', 'জরিমানা পরিমাণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (369, 'password_mismatch', 'Password Mismatch', 'পাসওয়ার্ড মেলেনি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (370, 'settings_updated', 'Settings Update', 'সেটিংস আপডেট করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (371, 'pass', 'Pass', 'পাস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (372, 'event_to', 'Event To', 'ইভেন্টের জন্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (373, 'all_users', 'All Users', 'সকল ব্যবহারকারী');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (374, 'employees_list', 'Employees List', 'কর্মচারী তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (375, 'on', 'On', 'উপর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (376, 'timezone', 'Timezone', 'সময় অঞ্চল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (377, 'get_result', 'Get Result', 'ফলাফল পেতে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (378, 'apply', 'Apply', 'প্রয়োগ করা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (379, 'hrm', 'Human Resource', 'মানব সম্পদ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (380, 'payroll', 'Payroll', 'বেতনের');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (381, 'salary_assign', 'Salary Assign', 'বেতন বরাদ্দ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (382, 'employee_salary', 'Payment Salary', 'পেমেন্ট বেতন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (383, 'application', 'Application', 'আবেদন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (384, 'award', 'Award', 'পুরস্কার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (385, 'basic_salary', 'Basic Salary', 'মূল বেতন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (386, 'employee_name', 'Employee Name', 'কর্মকর্তার নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (387, 'name_of_allowance', 'Name Of Allowance', 'ভাতা নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (388, 'name_of_deductions', 'Name Of Deductions', 'কর্তনের নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (389, 'all_employees', 'All Employees', 'সমস্ত কর্মচারী');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (390, 'total_allowance', 'Total Allowance', 'মোট ভাতা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (391, 'total_deduction', 'Total Deductions', 'মোট কর্তন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (392, 'net_salary', 'Net Salary', 'মোট বেতন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (393, 'payslip', 'Payslip', 'স্লিপে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (394, 'days', 'Days', 'দিন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (395, 'category_name_already_used', 'Category Name Already Used', 'বিভাগের নাম ইতিমধ্যে ব্যবহৃত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (396, 'leave_list', 'Leave List', 'তালিকা ছেড়ে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (397, 'leave_category', 'Leave Category', 'বিভাগ ছেড়ে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (398, 'applied_on', 'Applied On', 'প্রয়োগ করা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (399, 'accepted', 'Accepted', 'গৃহীত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (400, 'leave_statistics', 'Leave Statistics', 'ছুটি পরিসংখ্যান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (401, 'leave_type', 'Leave Type', 'ছুটি টাইপ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (402, 'reason', 'Reason', 'কারণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (403, 'close', 'Close', 'বন্ধ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (404, 'give_award', 'Give Award', 'পুরস্কার দাও');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (405, 'list', 'List', 'তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (406, 'award_name', 'Award Name', 'পুরস্কারের নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (407, 'gift_item', 'Gift Item', 'উপহার আইটেম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (408, 'cash_price', 'Cash Price', 'নগদ মূল্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (409, 'award_reason', 'Award Reason', 'পুরস্কার কারণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (410, 'given_date', 'Given Date', 'প্রদত্ত তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (411, 'apply_leave', 'Apply Leave', 'ছুটি প্রয়োগ করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (412, 'leave_application', 'Leave Application', 'ছুটি আবেদন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (413, 'allowances', 'Allowances', 'তৃপ্তি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (414, 'add_more', 'Add More', 'আরো যোগ করো');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (415, 'deductions', 'Deductions', 'কর্তন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (416, 'salary_details', 'Salary Details', 'বেতন বিবরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (417, 'salary_month', 'Salary Month', 'বেতন মাস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (418, 'leave_data_update_successfully', 'Leave Data Updated Successfully', 'ছুটি ডেটা সফলভাবে আপডেট করা হয়েছে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (419, 'fees_history', 'Fees History', 'ফি ইতিহাস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (420, 'bank_name', 'Bank Name', 'ব্যাংকের নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (421, 'branch', 'Branch', 'শাখা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (422, 'bank_address', 'Bank Address', 'ব্যাংকের ঠিকানা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (423, 'ifsc_code', 'IFSC Code', 'আইএফসিসি কোড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (424, 'account_no', 'Account No', 'হিসাব নাম্বার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (425, 'add_bank', 'Add Bank', 'ব্যাংক জুড়ুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (426, 'account_name', 'Account Holder', 'হিসাবের নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (427, 'database_backup_completed', 'Database Backup Completed', 'ডাটাবেস ব্যাকআপ সম্পন্ন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (428, 'restore_database', 'Restore Database', 'ডাটাবেস পুনঃস্থাপন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (429, 'template', 'Template', 'টেমপ্লেট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (430, 'time_and_date', 'Time And Date', 'সময় এবং তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (431, 'everyone', 'Everyone', 'সবাই');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (432, 'invalid_amount', 'Invalid Amount', 'অকার্যকর পরিমাণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (433, 'leaving_date_is_not_available_for_you', 'Leaving Date Is Not Available For You', 'তারিখ রেখে আপনার জন্য উপলব্ধ নয়');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (434, 'animations', 'Animations', 'অ্যানিমেশন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (435, 'email_settings', 'Email Settings', 'ইমেল সেটিংস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (436, 'deduct_month', 'Deduct Month', 'কেটে মাস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (437, 'no_employee_available', 'No Employee Available', 'কোন কর্মচারী প্রাপ্তিসাধ্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (438, 'advance_salary_application_submitted', 'Advance Salary Application Submitted', 'অগ্রিম বেতন আবেদন জমা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (439, 'date_format', 'Date Format', 'তারিখ বিন্যাস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (440, 'id_card_generate', 'ID Card Generate', 'আইডি কার্ড তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (441, 'issue_salary', 'Issue Salary', 'বেতন ইস্যু');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (442, 'advance_salary', 'Advance Salary', 'বেতন অগ্রিম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (443, 'logo', 'Logo', 'লোগো');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (444, 'book_request', 'Book Request', 'বই অনুরোধ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (445, 'reporting', 'Reporting', 'প্রতিবেদন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (446, 'paid_salary', 'Paid Salary', 'বেতন দেওয়া');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (447, 'due_salary', 'Due Salary', 'বাকি বেতন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (448, 'route', 'Route', 'রুট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (449, 'academic_details', 'Academic Details', 'একাডেমিক বিবরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (450, 'guardian_details', 'Guardian Details', 'অভিভাবক বিস্তারিত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (451, 'due_amount', 'Due Amount', 'বাকি টাকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (452, 'fee_due_report', 'Fee Due Report', 'ফি প্রতিবেদনের রিপোর্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (453, 'other_details', 'Other Details', 'অন্যান্য বিস্তারিত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (454, 'last_exam_report', 'Last Exam Report', 'শেষ পরীক্ষার রিপোর্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (455, 'book_issued', 'Book Issued', 'বই ইস্যু করা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (456, 'interval_month', 'Interval 30 Days', 'অন্তর 30 দিন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (457, 'attachments', 'Attachments', 'সংযুক্তিসমূহ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (458, 'fees_payment', 'Fees Payment', 'ফি প্রদান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (459, 'fees_summary', 'Fees Summary', 'ফি সংক্ষিপ্ত বিবরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (460, 'total_fees', 'Total Fees', 'মোট ফি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (461, 'weekend_attendance_inspection', 'Weekend Attendance Inspection', 'সপ্তাহান্তে উপস্থিতি পরিদর্শন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (462, 'book_issued_list', 'Book Issued List', 'বুক ইস্যু তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (463, 'lose_your_password', 'Lose Your Password?', 'আপনার পাসওয়ার্ড হারান?');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (464, 'all_branch_dashboard', 'All Branch Dashboard', 'সমস্ত শাখা ড্যাশবোর্ড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (465, 'academic_session', 'Academic Session', 'একাডেমিক সেশন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (466, 'all_branches', 'All Branches', 'সমস্ত শাখা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (467, 'admission', 'Admission', 'ভর্তি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (468, 'create_admission', 'Create Admission', 'ভর্তি তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (469, 'multiple_import', 'Multiple Import', 'একাধিক আমদানি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (470, 'student_details', 'Student Details', 'ছাত্র বিস্তারিত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (471, 'student_list', 'Student List', 'ছাত্র তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (472, 'login_deactivate', 'Login Deactivate', 'লগইন নিষ্ক্রিয় করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (473, 'parents_list', 'Parents List', 'পিতামাতার তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (474, 'add_parent', 'Add Parent', 'মূল যোগ করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (475, 'employee_list', 'Employee List', 'কর্মচারী তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (476, 'add_department', 'Add Department', 'বিভাগ যোগ করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (477, 'add_employee', 'Add Employee', 'কর্মচারী যোগ করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (478, 'salary_template', 'Salary Template', 'বেতন টেমপ্লেট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (479, 'salary_payment', 'Salary Payment', 'বেতন পেমেন্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (480, 'payroll_summary', 'Payroll Summary', 'বেতন সারসংক্ষেপ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (481, 'academic', 'Academic', 'বিদ্যালয় সংক্রান্ত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (482, 'control_classes', 'Control Classes', 'নিয়ন্ত্রণ ক্লাস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (483, 'assign_class_teacher', 'Assign Class Teacher', 'ক্লাস শিক্ষক নিয়োগ\n\n');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (484, 'class_assign', 'Class Assign', 'ক্লাস বরাদ্দ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (485, 'assign', 'Assign', 'দায়িত্ব অর্পণ করা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (486, 'promotion', 'Promotion', 'পদোন্নতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (487, 'attachments_book', 'Attachments Book', 'সংযুক্তি বই');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (488, 'upload_content', 'Upload Content', 'আপলোড কন্টেন্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (489, 'attachment_type', 'Attachment Type', 'সংযুক্তি প্রকার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (490, 'exam_master', 'Exam Master', 'পরীক্ষা মাস্টার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (491, 'exam_hall', 'Exam Hall', 'পরীক্ষা হল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (492, 'mark_entries', 'Mark Entries', 'মার্ক এন্ট্রি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (493, 'tabulation_sheet', 'Tabulation Sheet', 'ট্যাবলেট শীট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (494, 'supervision', 'Supervision', 'রক্ষণাবেক্ষণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (495, 'hostel_master', 'Hostel Master', 'হোস্টেল মাস্টার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (496, 'hostel_room', 'Hostel Room', 'হোস্টেল রুম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (497, 'allocation_report', 'Allocation Report', 'বরাদ্দ রিপোর্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (498, 'route_master', 'Route Master', 'রুট মাস্টার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (499, 'vehicle_master', 'Vehicle Master', 'যানবাহন মাস্টার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (500, 'stoppage', 'Stoppage', 'বিরতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (501, 'assign_vehicle', 'Assign Vehicle', 'যানবাহন বরাদ্দ করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (502, 'reports', 'Reports', 'প্রতিবেদন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (503, 'books_entry', 'Books Entry', 'বই এন্ট্রি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (504, 'event_type', 'Event Type', 'ইভেন্টের ধরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (505, 'add_events', 'Add Events', 'ইভেন্ট যোগ করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (506, 'student_accounting', 'Student Accounting', 'ছাত্র অ্যাকাউন্টিং');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (507, 'create_single_invoice', 'Create Single Invoice', 'একক চালান মোট রুট তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (508, 'create_multi_invoice', 'Create Multi Invoice', 'মাল্টি চালান তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (509, 'summary_report', 'Summary Report', 'সারসংক্ষেপ প্রতিবেদন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (510, 'office_accounting', 'Office Accounting', 'অফিস একাউন্টিং');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (511, 'under_group', 'Under Group', 'দলের অধীনে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (512, 'bank_account', 'Bank Account', 'ব্যাংক হিসাব');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (513, 'ledger_account', 'Ledger Account', 'লেজার অ্যাকাউন্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (514, 'create_voucher', 'Create Voucher', 'ভাউচার তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (515, 'day_book', 'Day Book', 'জাবেদা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (516, 'cash_book', 'Cash Book', 'নগদ বই');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (517, 'bank_book', 'Bank Book', 'ব্যাংক বই');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (518, 'ledger_book', 'Ledger Book', 'খতিয়ান বই');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (519, 'trial_balance', 'Trial Balance', 'ট্রায়াল ব্যালেন্স');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (520, 'settings', 'Settings', 'স্থাপন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (521, 'sms_settings', 'Sms Settings', 'এসএমএস সেটিংস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (522, 'cash_book_of', 'Cash Book Of', 'ক্যাশ বুক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (523, 'by_cash', 'By Cash', 'নগদে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (524, 'by_bank', 'By Bank', 'ব্যাংক দ্বারা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (525, 'total_strength', 'Total Strength', 'মোট শক্তি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (526, 'teachers', 'Teachers', 'শিক্ষক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (527, 'student_quantity', 'Student Quantity', 'ছাত্র পরিমাণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (528, 'voucher', 'Voucher', 'রসিদ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (529, 'total_number', 'Total Number', 'মোট সংখ্যা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (530, 'total_route', 'Total Route', 'মোট রুট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (531, 'total_room', 'Total Room', 'মোট কক্ষ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (532, 'amount', 'Amount', 'পরিমাণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (533, 'branch_dashboard', 'Branch Dashboard', 'শাখা ড্যাশবোর্ড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (534, 'branch_list', 'Branch List', 'শাখা তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (535, 'create_branch', 'Create Branch', 'শাখা তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (536, 'branch_name', 'Branch Name', 'শাখার নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (537, 'school_name', 'School Name', 'স্কুল নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (538, 'mobile_no', 'Mobile No', 'মোবাইল নাম্বার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (539, 'symbol', 'Symbol', 'পরিমাণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (540, 'city', 'City', 'শহর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (541, 'academic_year', 'Academic Year', 'একাডেমিক বছর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (542, 'select_branch_first', 'First Select The Branch', 'প্রথমে শাখা নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (543, 'select_class_first', 'Select Class First', 'ক্লাস প্রথম নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (544, 'select_country', 'Select Country', 'দেশ নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (545, 'mother_tongue', 'Mother Tongue', 'মাতৃভাষা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (546, 'caste', 'Caste', 'বর্ণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (547, 'present_address', 'Present Address', 'বর্তমান ঠিকানা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (548, 'permanent_address', 'Permanent Address', 'স্থায়ী ঠিকানা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (549, 'profile_picture', 'Profile Picture', 'প্রোফাইল ছবি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (550, 'login_details', 'Login Details', 'লগ ইন তথ্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (551, 'retype_password', 'Retype Password', 'পাসওয়ার্ড আবার টাইপ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (552, 'occupation', 'Occupation', 'পেশা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (553, 'income', 'Income', 'আয়');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (554, 'education', 'Education', 'শিক্ষা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (555, 'first_select_the_route', 'First Select The Route', 'প্রথম রুট নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (556, 'hostel_details', 'Hostel Details', 'হোটেল বিবরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (557, 'first_select_the_hostel', 'First Select The Hostel', 'প্রথম ছাত্রাবাস নির্বাচন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (558, 'previous_school_details', 'Previous School Details', 'পূর্ববর্তী স্কুল বিবরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (559, 'book_name', 'Book Name', 'বইয়ের নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (560, 'select_ground', 'Select Ground', 'গ্রাউন্ড নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (561, 'import', 'Import', 'আমদানি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (562, 'add_student_category', 'Add Student Category', 'ছাত্র বিভাগ যোগ করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (563, 'id', 'Id', 'আইডি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (564, 'edit_category', 'Edit Category', 'বিভাগ সম্পাদনা করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (565, 'deactivate_account', 'Deactivate Account', 'অ্যাকাউন্ট নিষ্ক্রিয় করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (566, 'all_sections', 'All Sections', 'সব বিভাগ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (567, 'authentication_activate', 'Authentication Activate', 'প্রমাণীকরণ সক্রিয় করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (568, 'department', 'Department', 'বিভাগ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (569, 'salary_grades', 'Salary Grades', 'বেতন গ্রেড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (570, 'overtime', 'Overtime Rate (Per Hour)', 'ওভারটাইম হার (প্রতি ঘন্টা)');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (571, 'salary_grade', 'Salary Grade', 'বেতন গ্রেড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (572, 'payable_type', 'Payable Type', 'প্রদেয় প্রকার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (573, 'edit_type', 'Edit Type', 'টাইপ সম্পাদনা করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (574, 'role', 'Role', 'ভূমিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (575, 'remuneration_info_for', 'Remuneration Info For', 'বেতন জন্য তথ্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (576, 'salary_paid', 'Salary Paid', 'বেতন দেওয়া');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (577, 'salary_unpaid', 'Salary Unpaid', 'বেতন পরিশোধ না');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (578, 'pay_now', 'Pay Now', 'এখন পরিশোধ করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (579, 'employee_role', 'Employee Role', 'কর্মচারী ভূমিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (580, 'create_at', 'Create At', 'এ তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (581, 'select_employee', 'Select Employee', 'কর্মচারী নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (582, 'review', 'Review', 'পর্যালোচনা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (583, 'reviewed_by', 'Reviewed By', 'দ্বারা পর্যালোচনা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (584, 'submitted_by', 'Submitted By', 'দ্বারা জমা দেওয়া');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (585, 'employee_type', 'Employee Type', 'কর্মচারী টাইপ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (586, 'approved', 'Approved', 'অনুমোদিত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (587, 'unreviewed', 'Unreviewed', 'পর্যালোচনা না করা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (588, 'creation_date', 'Creation Date', 'তৈরির তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (589, 'no_information_available', 'No Information Available', 'কোন তথ্য নেই');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (590, 'continue_to_payment', 'Continue To Payment', 'পেমেন্ট অবিরত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (591, 'overtime_total_hour', 'Overtime Total Hour', 'ওভারটাইম মোট ঘন্টা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (592, 'overtime_amount', 'Overtime Amount', 'ওভারটাইম পরিমাণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (593, 'remarks', 'Remarks', 'মন্তব্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (594, 'view', 'View', 'দৃশ্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (595, 'leave_appeal', 'Leave Appeal', 'আবেদন ছেড়ে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (596, 'create_leave', 'Create Leave', 'ছুটি তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (597, 'user_role', 'User Role', 'ব্যবহারকারী ভূমিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (598, 'date_of_start', 'Date Of Start', 'শুরু তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (599, 'date_of_end', 'Date Of End', 'শেষ তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (600, 'winner', 'Winner', 'বিজয়ী');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (601, 'select_user', 'Select User', 'ব্যবহারকারী নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (602, 'create_class', 'Create Class', 'ক্লাস তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (603, 'class_teacher_allocation', 'Class Teacher Allocation', 'ক্লাস শিক্ষক বরাদ্দ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (604, 'class_teacher', 'Class Teacher', 'শ্রেণী শিক্ষক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (605, 'create_subject', 'Create Subject', 'সাবজেক্ট তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (606, 'select_multiple_subject', 'Select Multiple Subject', 'একাধিক বিষয় নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (607, 'teacher_assign', 'Teacher Assign', 'শিক্ষক নিয়োগ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (608, 'teacher_assign_list', 'Teacher Assign List', 'শিক্ষক নিয়োগ তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (609, 'select_department_first', 'Select Department First', 'প্রথম বিভাগ নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (610, 'create_book', 'Create Book', 'বই তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (611, 'book_title', 'Book Title', 'বইয়ের শিরোনাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (612, 'cover', 'Cover', 'আবরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (613, 'edition', 'Edition', 'সংস্করণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (614, 'isbn_no', 'ISBN No', 'আইএসবিএন নং');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (615, 'purchase_date', 'Purchase Date', 'ক্রয় তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (616, 'cover_image', 'Cover Image', 'চিত্র কভার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (617, 'book_issue', 'Book Issue', 'বই ইস্যু');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (618, 'date_of_issue', 'Date Of Issue', 'প্রদান এর তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (619, 'date_of_expiry', 'Date Of Expiry', 'মেয়াদ শেষ হওয়ার তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (620, 'select_category_first', 'Select Category First', 'প্রথম বিভাগ নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (621, 'type_name', 'Type Name', 'নাম টাইপ করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (622, 'type_list', 'Type List', 'প্রকারের তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (623, 'icon', 'Icon', 'আইকন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (624, 'event_list', 'Event List', 'ইভেন্ট তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (625, 'create_event', 'Create Event', 'ইভেন্ট তৈরি করা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (626, 'type', 'Type', 'আদর্শ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (627, 'audience', 'Audience', 'শ্রোতা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (628, 'created_by', 'Created By', 'দ্বারা সৃষ্টি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (629, 'publish', 'Publish', 'প্রকাশ করা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (630, 'everybody', 'Everybody', 'সবাই');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (631, 'selected_class', 'Selected Class', 'নির্বাচিত ক্লাস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (632, 'selected_section', 'Selected Section', 'নির্বাচিত বিভাগ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (633, 'information_has_been_updated_successfully', 'Information Has Been Updated Successfully', 'তথ্য সফলভাবে আপডেট হয়েছে Updated');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (634, 'create_invoice', 'Create Invoice', 'চালান তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (635, 'invoice_entry', 'Invoice Entry', 'চালানের এন্ট্রি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (636, 'quick_payment', 'Quick Payment', 'দ্রুত অর্থ প্রদান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (637, 'write_your_remarks', 'Write Your Remarks', 'আপনার মন্তব্য লিখুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (638, 'reset', 'Reset', 'রিসেট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (639, 'fees_payment_history', 'Fees Payment History', 'ফি প্রদানের ইতিহাস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (640, 'fees_summary_report', 'Fees Summary Report', 'ফি সংক্ষিপ্তসার প্রতিবেদন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (641, 'add_account_group', 'Add Account Group', 'অ্যাকাউন্ট গ্রুপ যুক্ত করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (642, 'account_group', 'Account Group', 'অ্যাকাউন্ট গ্রুপ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (643, 'account_group_list', 'Account Group List', 'অ্যাকাউন্ট গ্রুপ তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (644, 'mailbox', 'Mailbox', 'ডাকবাক্স');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (645, 'refresh_mail', 'Refresh Mail', 'রিফ্রেশ মেল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (646, 'sender', 'Sender', 'প্রেরকের');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (647, 'general_settings', 'General Settings', 'সাধারণ সেটিংস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (648, 'institute_name', 'Institute Name', 'প্রতিষ্ঠানের নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (649, 'institution_code', 'Institution Code', 'প্রতিষ্ঠান কোড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (650, 'sms_service_provider', 'Sms Service Provider', 'এসএমএস পরিষেবা সরবরাহকারী');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (651, 'footer_text', 'Footer Text', 'পাদচরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (652, 'payment_control', 'Payment Control', 'পেমেন্ট কন্ট্রোল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (653, 'sms_config', 'Sms Config', 'এসএমএস কনফিগার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (654, 'sms_triggers', 'Sms Triggers', 'এসএমএস ট্রিগার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (655, 'authentication_token', 'Authentication Token', 'প্রমাণীকরণ টোকেন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (656, 'sender_number', 'Sender Number', 'প্রেরকের নম্বর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (657, 'username', 'Username', 'ব্যবহারকারীর নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (658, 'api_key', 'Api Key', 'এপি কি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (659, 'authkey', 'Authkey', 'Authkey');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (660, 'sender_id', 'Sender Id', 'প্রেরকের আইডি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (661, 'sender_name', 'Sender Name', 'প্রেরক নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (662, 'hash_key', 'Hash Key', 'হ্যাশ কী');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (663, 'notify_enable', 'Notify Enable', 'সক্ষমকে অবহিত করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (664, 'exam_attendance', 'Exam Attendance', 'পরীক্ষার উপস্থিতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (665, 'exam_results', 'Exam Results', 'পরীক্ষার ফলাফল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (666, 'email_config', 'Email Config', 'ইমেল কনফিগারেশন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (667, 'email_triggers', 'Email Triggers', 'ইমেল ট্রিগার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (668, 'account_registered', 'Account Registered', 'অ্যাকাউন্ট নিবন্ধিত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (669, 'forgot_password', 'Forgot Password', 'পাসওয়ার্ড ভুলে গেছেন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (670, 'new_message_received', 'New Message Received', 'নতুন বার্তা গৃহীত হয়েছে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (671, 'payslip_generated', 'Payslip Generated', 'পেইলিপ জেনারেটেড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (672, 'leave_approve', 'Leave Approve', 'ছাড়ুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (673, 'leave_reject', 'Leave Reject', 'প্রত্যাখ্যান ছেড়ে দিন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (674, 'advance_salary_approve', 'Leave Reject', 'প্রত্যাখ্যান ছেড়ে দিন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (675, 'advance_salary_reject', 'Advance Salary Reject', 'অগ্রিম বেতন প্রত্যাখ্যান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (676, 'add_session', 'Add Session', 'সেশন যোগ করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (677, 'session', 'Session', 'সেশন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (678, 'created_at', 'Created At', 'এ নির্মিত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (679, 'sessions', 'Sessions', 'দায়রা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (680, 'flag', 'Flag', 'পতাকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (681, 'stats', 'Stats', 'পরিসংখ্যান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (682, 'updated_at', 'Updated At', 'এ আপডেট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (683, 'flag_icon', 'Flag Icon', 'পতাকা আইকন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (684, 'password_restoration', 'Password Restoration', 'পাসওয়ার্ড পুনরুদ্ধার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (685, 'forgot', 'Forgot', 'ভুলে গেছেন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (686, 'back_to_login', 'Back To Login', 'প্রবেশ করতে পেছান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (687, 'database_list', 'Database List', 'ডাটাবেস তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (688, 'create_backup', 'Create Backup', 'ব্যাকআপ তৈরি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (689, 'backup', 'Backup', 'ব্যাকআপ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (690, 'backup_size', 'Backup Size', 'ব্যাকআপ আকার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (691, 'file_upload', 'File Upload', 'ফাইল আপলোড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (692, 'parents_details', 'Parents Details', 'পিতামাতার বিশদ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (693, 'social_links', 'Social Links', 'সামাজিক বন্ধন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (694, 'create_hostel', 'Create Hostel', 'হোস্টেল তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (695, 'allocation_list', 'Allocation List', 'বরাদ্দ তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (696, 'payslip_history', 'Payslip History', 'পেইলিপ ইতিহাস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (697, 'my_attendance_overview', 'My Attendance Overview', 'আমার উপস্থিতি ওভারভিউ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (698, 'total_present', 'Total Present', 'মোট উপস্থিত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (699, 'total_absent', 'Total Absent', 'মোট অনুপস্থিত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (700, 'total_late', 'Total Late', 'মোট লেট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (701, 'class_teacher_list', 'Class Teacher List', 'শ্রেণি শিক্ষকের তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (702, 'section_control', 'Section Control', 'বিভাগ নিয়ন্ত্রণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (703, 'capacity ', 'Capacity', 'ধারণক্ষমতা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (704, 'request', 'Request', 'অনুরোধ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (705, 'salary_year', 'Salary Year', 'বেতন বছর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (706, 'create_attachments', 'Create Attachments', 'সংযুক্তি তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (707, 'publish_date', 'Publish Date', 'প্রকাশের তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (708, 'attachment_file', 'Attachment File', 'উচ্চ স্বরে পড়া');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (709, 'age', 'Age', 'Age');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (710, 'student_profile', 'Student Profile', 'ছাত্র প্রোফাইল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (711, 'authentication', 'Authentication', 'প্রমাণীকরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (712, 'parent_information', 'Parent Information', 'মূল তথ্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (713, 'full_marks', 'Full Marks', 'পুরোপুরি লক্ষ্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (714, 'passing_marks', 'Passing Marks', 'পাসিং মার্কস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (715, 'highest_marks', 'Highest Marks', 'সর্বোচ্চ নম্বর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (716, 'unknown', 'Unknown', 'অজানা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (717, 'unpublish', 'Unpublish', 'অপ্রকাশিত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (718, 'login_authentication_deactivate', 'Login Authentication Deactivate', 'লগইন প্রমাণীকরণ নিষ্ক্রিয় করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (719, 'employee_profile', 'Employee Profile', 'কর্মচারী প্রোফাইল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (720, 'employee_details', 'Employee Details', 'কর্মচারীর বিবরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (721, 'salary_transaction', 'Salary Transaction', 'বেতন লেনদেন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (722, 'documents', 'Documents', 'কাগজপত্র');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (723, 'actions', 'Actions', 'ক্রিয়াকলাপ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (724, 'activity', 'Activity', 'কার্যকলাপ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (725, 'department_list', 'Department List', 'বিভাগ তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (726, 'manage_employee_salary', 'Manage Employee Salary', 'কর্মচারীদের বেতন পরিচালনা করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (727, 'the_configuration_has_been_updated', 'The Configuration Has Been Updated', 'কনফিগারেশন আপডেট হয়েছে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (728, 'add', 'Add', 'যোগ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (729, 'create_exam', 'Create Exam', 'পরীক্ষা তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (730, 'term', 'Term', 'শব্দ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (731, 'add_term', 'Add Term', 'টার্ম যুক্ত করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (732, 'create_grade', 'Create Grade', 'গ্রেড তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (733, 'mark_starting', 'Mark Starting', 'শুরুর চিহ্ন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (734, 'mark_until', 'Mark Until', 'অবধি চিহ্নিত করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (735, 'room_list', 'Room List', 'রুম তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (736, 'room', 'Room', 'ঘর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (737, 'route_list', 'Route List', 'রুটের তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (738, 'create_route', 'Create Route', 'রুট তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (739, 'vehicle_list', 'Vehicle List', 'যানবাহনের তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (740, 'create_vehicle', 'Create Vehicle', 'যানবাহন তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (741, 'stoppage_list', 'Stoppage List', 'স্টপেজ তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (742, 'create_stoppage', 'Create Stoppage', 'স্টপেজ তৈরি করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (743, 'stop_time', 'Stop Time', 'সময় বন্ধ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (744, 'employee_attendance', 'Employee Attendance', 'কর্মচারী উপস্থিতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (745, 'attendance_report', 'Attendance Report', 'উপস্থিতি রিপোর্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (746, 'opening_balance', 'Opening Balance', 'খোলার ভারসাম্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (747, 'add_opening_balance', 'Add Opening Balance', 'উদ্বোধনী ব্যালেন্স যুক্ত করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (748, 'credit', 'Credit', 'ধার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (749, 'debit', 'Debit', 'খরচ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (750, 'opening_balance_list', 'Opening Balance List', 'খোলার ভারসাম্য তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (751, 'voucher_list', 'Voucher List', 'ভাউচার তালিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (752, 'voucher_head', 'Voucher Head', 'ভাউচার হেড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (753, 'payment_method', 'Payment Method', 'মূল্যপরিশোধ পদ্ধতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (754, 'credit_ledger_account', 'Credit Ledger Account', 'ক্রেডিট লেজার অ্যাকাউন্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (755, 'debit_ledger_account', 'Debit Ledger Account', 'ডেবিট লেজার অ্যাকাউন্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (756, 'voucher_no', 'Voucher No', 'ভাউচার নং');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (757, 'balance', 'Balance', 'ভারসাম্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (758, 'event_details', 'Event Details', 'অনুষ্ঠানের বিবরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (759, 'welcome_to', 'Welcome To', 'স্বাগতম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (760, 'report_card', 'Report Card', 'রিপোর্ট কার্ড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (761, 'online_pay', 'Online Pay', 'অনলাইন পে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (762, 'annual_fees_summary', 'Annual Fees Summary', 'বার্ষিক ফি সংক্ষিপ্তসার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (763, 'my_children', 'My Children', 'আমার শিশু');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (764, 'assigned', 'Assigned', 'বরাদ্দ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (765, 'confirm_password', 'Confirm Password', 'পাসওয়ার্ড নিশ্চিত করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (766, 'searching_results', 'Searching Results', 'অনুসন্ধান ফলাফল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (767, 'information_has_been_saved_successfully', 'Information Has Been Saved Successfully', 'তথ্য সাফল্যের সাথে সংরক্ষণ করা হয়েছে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (768, 'information_deleted', 'The information has been successfully deleted', 'তথ্য সফলভাবে মুছে ফেলা হয়েছে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (769, 'deleted_note', '*Note : This data will be permanently deleted', '* দ্রষ্টব্য: এই তথ্য স্থায়ীভাবে মুছে ফেলা হবে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (770, 'are_you_sure', 'Are You Sure?', 'তুমি কি নিশ্চিত?');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (771, 'delete_this_information', 'Do You Want To Delete This Information?', 'আপনি এই তথ্য মুছে ফেলতে চান?');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (772, 'yes_continue', 'Yes, Continue', 'হ্যাঁ, চালিয়ে যান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (773, 'deleted', 'Deleted', 'মুছে ফেলা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (774, 'collect', 'Collect', 'সংগ্রহ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (775, 'school_setting', 'School Setting', 'স্কুল সেটিং');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (776, 'set', 'Set', 'সেট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (777, 'quick_view', 'Quick View', 'তারাতারি দেখা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (778, 'due_fees_invoice', 'Due Fees Invoice', 'পারিশ্রমিক ফি চালান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (779, 'my_application', 'My Application', 'আমার আবেদন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (780, 'manage_application', 'Manage Application', 'অ্যাপ্লিকেশন পরিচালনা করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (781, 'leave', 'Leave', 'ছুটি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (782, 'live_class_rooms', 'Live Class Rooms', 'লাইভ ক্লাস রুম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (783, 'homework', 'Homework', 'বাড়ির কাজ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (784, 'evaluation_report', 'Evaluation Report', 'মূল্যায়ন প্রতিবেদন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (785, 'exam_term', 'Exam Term', 'পরীক্ষার মেয়াদ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (786, 'distribution', 'Distribution', 'বিতরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (787, 'exam_setup', 'Exam Setup', 'পরীক্ষা সেটআপ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (788, 'sms', 'Sms', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (789, 'fees_type', 'Fees Type', 'ফি প্রকার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (790, 'fees_group', 'Fees Group', 'ফি গ্রুপ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (791, 'fine_setup', 'Fine Setup', 'ফাইন সেটআপ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (792, 'fees_reminder', 'Fees Reminder', 'ফি অনুস্মারক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (793, 'new_deposit', 'New Deposit', 'নতুন আমানত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (794, 'new_expense', 'New Expense', 'নতুন ব্যয়');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (795, 'all_transactions', 'All Transactions', 'সমস্ত লেনদেন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (796, 'head', 'Head', 'মাথা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (797, 'fees_reports', 'Fees Reports', 'ফি প্রতিবেদন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (798, 'fees_report', 'Fees Report', 'ফি রিপোর্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (799, 'receipts_report', 'Receipts Report', 'প্রাপ্তি রিপোর্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (800, 'due_fees_report', 'Due Fees Report', 'বকেয়া ফি রিপোর্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (801, 'fine_report', 'Fine Report', 'ফাইন রিপোর্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (802, 'financial_reports', 'Financial Reports', 'আর্থিক প্রতিবেদন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (803, 'statement', 'Statement', 'বিবৃতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (804, 'repots', 'Repots', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (805, 'expense', 'Expense', 'ব্যয়');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (806, 'transitions', 'Transitions', 'স্থানান্তর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (807, 'sheet', 'Sheet', 'চাদর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (808, 'income_vs_expense', 'Income Vs Expense', 'আয় বনাম ব্যয়');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (809, 'attendance_reports', 'Attendance Reports', 'উপস্থিতি রিপোর্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (810, 'examination', 'Examination', 'পরীক্ষা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (811, 'school_settings', 'School Settings', 'স্কুল সেটিংস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (812, 'role_permission', 'Role Permission', 'ভূমিকা অনুমতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (813, 'cron_job', 'Cron Job', 'ক্রোন জব');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (814, 'custom_field', 'Custom Field', 'কাস্টম ক্ষেত্র');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (815, 'enter_valid_email', 'Enter Valid Email', 'সঠিক ইমেইল এড্রেস প্রদান করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (816, 'lessons', 'Lessons', 'পাঠ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (817, 'live_class', 'Live Class', 'লাইভ ক্লাস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (818, 'sl', 'Sl', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (819, 'meeting_id', 'Meeting ID', 'লাইভ ক্লাস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (820, 'start_time', 'Start Time', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (821, 'end_time', 'End Time', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (822, 'zoom_meeting_id', 'Zoom Meeting Id', 'জুম মিটিং আইডি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (823, 'zoom_meeting_password', 'Zoom Meeting Password', 'জুম মিটিংয়ের পাসওয়ার্ড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (824, 'time_slot', 'Time Slot', 'সময় স্লট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (825, 'send_notification_sms', 'Send Notification Sms', 'বিজ্ঞপ্তি এসএমএস প্রেরণ করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (826, 'host', 'Host', 'নিমন্ত্রণকর্তা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (827, 'school', 'School', 'বিদ্যালয়');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (828, 'accounting_links', 'Accounting Links', 'অ্যাকাউন্টিং লিংক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (829, 'applicant', 'Applicant', 'প্রার্থী');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (830, 'apply_date', 'Apply Date', 'আবেদন করুন তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (831, 'add_leave', 'Add Leave', 'ছুটি যুক্ত করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (832, 'leave_date', 'Leave Date', 'ছেড়ে দিন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (833, 'attachment', 'Attachment', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (834, 'comments', 'Comments', 'মন্তব্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (835, 'staff_id', 'Staff Id', 'স্টাফ আইডি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (836, 'income_vs_expense_of', 'Income Vs Expense Of', 'আয় বনাম ব্যয়');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (837, 'designation_name', 'Designation Name', 'পদবি নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (838, 'already_taken', 'This %s already exists.', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (839, 'department_name', 'Department Name', 'বিভাগ নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (840, 'date_of_birth', 'Date Of Birth', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (841, 'bulk_delete', 'Bulk Delete', 'বাল্ক মুছুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (842, 'guardian_name', 'Guardian Name', 'অভিভাবকের নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (843, 'fees_progress', 'Fees Progress', 'ফি অগ্রগতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (844, 'evaluate', 'Evaluate', 'মূল্যনির্ধারণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (845, 'date_of_homework', 'Date Of Homework', 'হোম ওয়ার্কের তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (846, 'date_of_submission', 'Date Of Submission', 'জমা তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (847, 'student_fees_report', 'Student Fees Report', 'শিক্ষার্থী ফি রিপোর্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (848, 'student_fees_reports', 'Student Fees Reports', 'ছাত্র ফি প্রতিবেদন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (849, 'due_date', 'Due Date', 'নির্দিষ্ট তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (850, 'payment_date', 'Payment Date', 'টাকা প্রদানের তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (851, 'payment_via', 'Payment Via', 'অর্থ প্রদানের মাধ্যমে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (852, 'generate', 'Generate', 'জেনারেট করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (853, 'print_date', 'Print Date', 'মুদ্রণ তারিখ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (854, 'bulk_sms_and_email', 'Bulk Sms And Email', 'বাল্ক এসএমএস এবং ইমেল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (855, 'campaign_type', 'Campaign Type', 'প্রচারের ধরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (856, 'both', 'Both', 'উভয়');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (857, 'regular', 'Regular', 'নিয়মিত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (858, 'Scheduled', 'Scheduled', 'তালিকাভুক্ত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (859, 'campaign', 'Campaign', 'ক্যাম্পেইন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (860, 'campaign_name', 'Campaign Name', 'প্রচারাভিযান নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (861, 'sms_gateway', 'Sms Gateway', 'এসএমএস গেটওয়ে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (862, 'recipients_type', 'Recipients Type', 'প্রাপক প্রকার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (863, 'recipients_count', 'Recipients Count', 'প্রাপকগণ গণনা করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (864, 'body', 'Body', 'শরীর');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (865, 'guardian_already_exist', 'Guardian Already Exist', 'অভিভাবক ইতিমধ্যে বিদ্যমান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (866, 'guardian', 'Guardian', 'অভিভাবক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (867, 'mother_name', 'Mother Name', 'মা নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (868, 'bank_details', 'Bank Details', 'ব্যাংক বিবরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (869, 'skipped_bank_details', 'Skipped Bank Details', 'বাদ দেওয়া ব্যাঙ্কের বিশদ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (870, 'bank', 'Bank', 'ব্যাংক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (871, 'holder_name', 'Holder Name', 'ধারক নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (872, 'bank_branch', 'Bank Branch', 'ব্যাংকের শাখা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (873, 'custom_field_for', 'Custom Field For', 'কাস্টম ফিল্ড জন্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (874, 'label', 'Label', 'লেবেল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (875, 'order', 'Order', 'ক্রম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (876, 'online_admission', 'Online Admission', 'অনলাইন ভর্তি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (877, 'field_label', 'Field Label', 'ফিল্ড লেবেল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (878, 'field_type', 'Field Label', 'ফিল্ড লেবেল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (879, 'default_value', 'Default Value', 'ডিফল্ট মান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (880, 'checked', 'Checked', 'সংযত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (881, 'unchecked', 'Unchecked', 'অবারিত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (882, 'roll_number', 'Roll Number', 'রোল নাম্বার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (883, 'add_rows', 'Add Rows', 'সারি যুক্ত করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (884, 'salary', 'Salary', 'বেতন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (885, 'basic', 'Basic', 'মৌলিক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (886, 'allowance', 'Allowance', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (887, 'deduction', 'Deduction', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (888, 'net', 'Net', 'নেট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (889, 'activated_sms_gateway', 'Activated Sms Gateway', 'সক্রিয় এসএমএস গেটওয়ে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (890, 'account_sid', 'Account Sid', 'অ্যাকাউন্ট সিড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (891, 'roles', 'Roles', 'ভূমিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (892, 'system_role', 'System Role', 'সিস্টেমের ভূমিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (893, 'permission', 'Permission', 'অনুমতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (894, 'edit_session', 'Edit Session', 'সেশন সম্পাদনা করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (895, 'transactions', 'Transactions', 'লেনদেন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (896, 'default_account', 'Default Account', 'ডিফল্ট অ্যাকাউন্ট');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (897, 'deposit', 'Deposit', 'আমানত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (898, 'acccount', 'Acccount', 'অ্যাকাউন্টে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (899, 'role_permission_for', 'Role Permission For', 'ভূমিকা জন্য অনুমতি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (900, 'feature', 'Feature', 'বৈশিষ্ট্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (901, 'access_denied', 'Access Denied', 'অ্যাক্সেস অস্বীকৃত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (902, 'time_start', 'Time Start', 'সময় শুরু');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (903, 'time_end', 'Time End', 'সময় শেষ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (904, 'month_of_salary', 'Month Of Salary', 'বেতন মাস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (905, 'add_documents', 'Add Documents', 'নথি যুক্ত করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (906, 'document_type', 'Document Type', 'নথিপত্র ধরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (907, 'document', 'Document', 'দলিল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (908, 'document_title', 'Document Title', 'নথির শিরোনাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (909, 'document_category', 'Document Category', 'নথি বিভাগ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (910, 'exam_result', 'Exam Result', 'পরীক্ষার ফলাফল');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (911, 'my_annual_fee_summary', 'My Annual Fee Summary', 'আমার বার্ষিক ফি সংক্ষিপ্তসার');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (912, 'book_manage', 'Book Manage', 'বই পরিচালনা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (913, 'add_leave_category', 'Add Leave Category', 'ছাড়ার বিভাগ যুক্ত করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (914, 'edit_leave_category', 'Edit Leave Category', 'বিভাগ ছেড়ে যান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (915, 'staff_role', 'Staff Role', 'স্টাফ ভূমিকা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (916, 'edit_assign', 'Edit Assign', 'সম্পাদনা করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (917, 'view_report', 'View Report', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (918, 'rank_out_of_5', 'Rank Out Of 5', 'র‌্যাঙ্ক আউট 5');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (919, 'hall_no', 'Hall No', 'হল নং');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (920, 'no_of_seats', 'No Of Seats', 'নং আসন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (921, 'mark_distribution', 'Mark Distribution', 'চিহ্ন বিতরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (922, 'exam_type', 'Exam Type', 'পরীক্ষার ধরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (923, 'marks_and_grade', 'Marks And Grade', 'চিহ্ন এবং গ্রেড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (924, 'min_percentage', 'Min Percentage', 'ন্যূনতম শতাংশ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (925, 'max_percentage', 'Max Percentage', 'সর্বোচ্চ শতাংশ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (926, 'cost_per_bed', 'Cost Per Bed', 'প্রতি বিছানা খরচ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (927, 'add_category', 'Add Category', 'বিভাগ যুক্ত করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (928, 'category_for', 'Category For', 'বিভাগের জন্য');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (929, 'start_place', 'Start Place', 'স্টার্ট প্লেস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (930, 'stop_place', 'Stop Place', 'স্টপ প্লেস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (931, 'vehicle', 'Vehicle', 'বাহন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (932, 'select_multiple_vehicle', 'Select Multiple Vehicle', 'একাধিক যান নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (933, 'book_details', 'Book Details', 'বইয়ের বিবরণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (934, 'issued_by', 'Issued By', 'প্রদান করেছেন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (935, 'return_by', 'Return By', 'ফিরে আসুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (936, 'group', 'Group', 'গ্রুপ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (937, 'individual', 'Individual', 'স্বতন্ত্র');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (938, 'recipients', 'Recipients', 'প্রাপক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (939, 'group_name', 'Group Name', 'দলের নাম');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (940, 'fee_code', 'Fee Code', 'ফি কোড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (941, 'fine_type', 'Fine Type', 'ফাইন টাইপ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (942, 'fine_value', 'Fine Value', 'সূক্ষ্ম মান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (943, 'late_fee_frequency', 'Late Fee Frequency', 'দেরিতে ফি ফ্রিকোয়েন্সি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (944, 'fixed_amount', 'Fixed Amount', 'নির্দিষ্ট পরিমাণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (945, 'fixed', 'Fixed', 'ফিক্সড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (946, 'daily', 'Daily', 'দৈনন্দিন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (947, 'weekly', 'Weekly', 'সাপ্তাহিক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (948, 'monthly', 'Monthly', 'মাসিক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (949, 'annually', 'Annually', 'সালিয়ানা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (950, 'first_select_the_group', 'First Select The Group', 'প্রথমে গ্রুপটি নির্বাচন করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (951, 'percentage', 'Percentage', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (952, 'value', 'Value', 'মান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (953, 'fee_group', 'Fee Group', 'ফি গ্রুপ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (954, 'due_invoice', 'Due Invoice', 'ইনভয়েস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (955, 'reminder', 'Reminder', 'অনুস্মারক');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (956, 'frequency', 'Frequency', 'ফ্রিকোয়েন্সি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (957, 'notify', 'Notify', 'অবহিত');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (958, 'before', 'Before', 'আগে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (959, 'after', 'After', 'পরে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (960, 'number', 'Number', 'সংখ্যা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (961, 'ref_no', 'Ref No', 'সুত্র নেই');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (962, 'pay_via', 'Pay Via', 'ভায়া দিয়ে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (963, 'ref', 'Ref', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (964, 'dr', 'Dr', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (965, 'cr', 'Cr', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (966, 'edit_book', 'Edit Book', 'সম্পাদনা বই');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (967, 'leaves', 'Leaves', 'পত্রাদি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (968, 'leave_request', 'Leave Request', 'অনুরোধ ত্যাগ করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (969, 'this_file_type_is_not_allowed', 'This File Type Is Not Allowed', 'এই ফাইল টাইপ অনুমোদিত নয়');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (970, 'error_reading_the_file', 'Error Reading The File', 'ফাইলটি পড়ার সময় ত্রুটি');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (971, 'staff', 'Staff', 'কর্মী');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (972, 'waiting', 'Waiting', 'অপেক্ষা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (973, 'live', 'Live', 'লাইভ দেখান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (974, 'by', 'By', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (975, 'host_live_class', 'Host Live Class', 'হোস্ট লাইভ ক্লাস');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (976, 'join_live_class', 'Join Live Class', 'লাইভ ক্লাসে যোগদান করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (977, 'system_logo', 'System Logo', 'সিস্টেম লোগো');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (978, 'text_logo', 'Text Logo', 'পাঠ্য লোগো');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (979, 'printing_logo', 'Printing Logo', 'মুদ্রণ লোগো');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (980, 'expired', 'Expired', 'মেয়াদোত্তীর্ণ');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (981, 'collect_fees', 'Collect Fees', 'ফি সংগ্রহ করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (982, 'fees_code', 'Fees Code', 'ফি কোড');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (983, 'collect_by', 'Collect By', 'সংগ্রহ করুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (984, 'fee_payment', 'Fee Payment', 'ফি জমাদান');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (985, 'write_message', 'Write Message', 'বার্তা লিখুন');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (986, 'discard', 'Discard', 'বাতিল করা');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (987, 'message_sent_successfully', 'Message Sent Successfully', 'বার্তা সফলভাবে পাঠানো হয়েছে');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (988, 'visit_home_page', 'Visit Home Page', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (989, 'frontend', 'Frontend', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (990, 'setting', 'Setting', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (991, 'menu', 'Menu', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (992, 'page', 'Page', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (993, 'manage', 'Manage', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (994, 'slider', 'Slider', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (995, 'features', 'Features', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (996, 'testimonial', 'Testimonial', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (997, 'service', 'Service', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (998, 'faq', 'Faq', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (999, 'card_management', 'Card Management', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1000, 'id_card', 'Id Card', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1001, 'templete', 'Templete', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1002, 'admit_card', 'Admit Card', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1003, 'certificate', 'Certificate', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1004, 'system_update', 'System Update', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1005, 'url', 'Url', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1006, 'content', 'Content', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1007, 'banner_photo', 'Banner Photo', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1008, 'meta', 'Meta', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1009, 'keyword', 'Keyword', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1010, 'applicable_user', 'Applicable User', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1011, 'page_layout', 'Page Layout', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1012, 'background', 'Background', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1013, 'image', 'Image', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1014, 'width', 'Width', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1015, 'height', 'Height', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1016, 'signature', 'Signature', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1017, 'website', 'Website', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1018, 'cms', 'Cms', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1019, 'url_alias', 'Url Alias', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1020, 'cms_frontend', 'Cms Frontend', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1021, 'enabled', 'Enabled', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1022, 'receive_email_to', 'Receive Email To', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1023, 'captcha_status', 'Captcha Status', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1024, 'recaptcha_site_key', 'Recaptcha Site Key', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1025, 'recaptcha_secret_key', 'Recaptcha Secret Key', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1026, 'working_hours', 'Working Hours', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1027, 'fav_icon', 'Fav Icon', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1028, 'theme', 'Theme', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1029, 'fax', 'Fax', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1030, 'footer_about_text', 'Footer About Text', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1031, 'copyright_text', 'Copyright Text', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1032, 'facebook_url', 'Facebook Url', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1033, 'twitter_url', 'Twitter Url', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1034, 'youtube_url', 'Youtube Url', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1035, 'google_plus', 'Google Plus', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1036, 'linkedin_url', 'Linkedin Url', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1037, 'pinterest_url', 'Pinterest Url', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1038, 'instagram_url', 'Instagram Url', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1039, 'play', 'Play', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1040, 'video', 'Video', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1041, 'usename', 'Usename', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1042, 'experience_details', 'Experience Details', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1043, 'total_experience', 'Total Experience', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1044, 'class_schedule', 'Class Schedule', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1045, 'cms_default_branch', 'Cms Default Branch', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1046, 'website_page', 'Website Page', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1047, 'welcome', 'Welcome', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1048, 'services', 'Services', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1049, 'call_to_action_section', 'Call To Action Section', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1050, 'subtitle', 'Subtitle', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1051, 'cta', 'Cta', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1052, 'button_text', 'Button Text', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1053, 'button_url', 'Button Url', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1054, '_title', ' Title', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1055, 'contact', 'Contact', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1056, 'box_title', 'Box Title', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1057, 'box_description', 'Box Description', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1058, 'box_photo', 'Box Photo', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1059, 'form_title', 'Form Title', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1060, 'submit_button_text', 'Submit Button Text', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1061, 'map_iframe', 'Map Iframe', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1062, 'email_subject', 'Email Subject', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1063, 'prefix', 'Prefix', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1064, 'surname', 'Surname', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1065, 'rank', 'Rank', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1066, 'submit', 'Submit', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1067, 'certificate_name', 'Certificate Name', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1068, 'layout_width', 'Layout Width', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1069, 'layout_height', 'Layout Height', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1070, 'expiry_date', 'Expiry Date', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1071, 'position', 'Position', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1072, 'target_new_window', 'Target New Window', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1073, 'external_url', 'External Url', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1074, 'external_link', 'External Link', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1075, 'sms_notification', 'Sms Notification', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1076, 'scheduled_at', 'Scheduled At', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1077, 'published', 'Published', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1078, 'unpublished_on_website', 'Unpublished On Website', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1079, 'published_on_website', 'Published On Website', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1080, 'no_selection_available', 'No Selection Available', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1081, 'select_for_everyone', 'Select For Everyone', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1082, 'teacher_restricted', 'Teacher Restricted', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1083, 'guardian_relation', 'Guardian Relation', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1084, 'username_prefix', 'Username Prefix', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1085, 'default_password', 'Default Password', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1086, 'parents_profile', 'Parents Profile', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1087, 'childs', 'Childs', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1088, 'page_title', 'Page Title', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1089, 'select_menu', 'Select Menu', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1090, 'meta_keyword', 'Meta Keyword', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1091, 'meta_description', 'Meta Description', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1092, 'evaluation_date', 'Evaluation Date', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1093, 'evaluated_by', 'Evaluated By', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1094, 'complete', 'Complete', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1095, 'incomplete', 'Incomplete', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1096, 'payment_details', 'Payment Details', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1097, 'edit_attachments', 'Edit Attachments', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1098, 'live_classes', 'Live Classes', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1099, 'duration', 'Duration', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1100, 'metting_id', 'Metting Id', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1101, 'set_record', 'Set Record', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1102, 'set_mute_on_start', 'Set Mute On Start', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1103, 'button_text_1', 'Button Text 1', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1104, 'button_url_1', 'Button Url 1', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1105, 'button_text_2', 'Button Text 2', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1106, 'button_url_2', 'Button Url 2', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1107, 'left', 'Left', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1108, 'center', 'Center', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1109, 'right', 'Right', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1110, 'about', 'About', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1111, 'about_photo', 'About Photo', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1112, 'parallax_photo', 'Parallax Photo', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1113, 'decline', 'Decline', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1114, 'edit_grade', 'Edit Grade', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1115, 'mark', 'Mark', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1116, 'hall_room', 'Hall Room', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1117, 'student_promotion', 'Student Promotion', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1118, 'username_has_already_been_used', 'Username Has Already Been Used', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1119, 'fee_collection', 'Fee Collection', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1120, 'not_found_anything', 'Not Found Anything', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1121, 'preloader_backend', 'Preloader Backend', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1122, 'ive_class_method', 'Ive Class Method', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1123, 'live_class_method', 'Live Class Method', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1124, 'api_credential', 'Api Credential', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1125, 'translation_update', 'Translation Update', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1126, ' live_class_reports', ' Live Class Reports', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1127, 'live_class_reports', 'Live Class Reports', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1128, 'all', 'All', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1129, 'student_participation_report', 'Student Participation Report', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1130, 'joining_time', 'Joining Time', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1131, 'inventory', 'Inventory', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1132, 'product', 'Product', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1133, 'store', 'Store', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1134, 'supplier', 'Supplier', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1135, 'unit', 'Unit', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1136, 'purchase', 'Purchase', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1137, 'sales', 'Sales', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1138, 'issue', 'Issue', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1139, 'gallery', 'Gallery', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1140, 'reception', 'Reception', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1141, 'admission_enquiry', 'Admission Enquiry', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1142, 'postal_record', 'Postal Record', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1143, 'call_log', 'Call Log', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1144, 'visitor_log', 'Visitor Log', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1145, 'complaint', 'Complaint', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1146, 'deactivate_reason', 'Deactivate Reason', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1147, 'online_exam', 'Online Exam', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1148, 'question_bank', 'Question Bank', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1149, 'question_group', 'Question Group', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1150, 'my_issued_book', 'My Issued Book', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1151, 'book_issue/return', 'Book Issue/return', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1152, 'offline_payments', 'Offline Payments', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1153, 'payments', 'Payments', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1154, ' offline_payments', ' Offline Payments', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1155, 'login_credential', 'Login Credential', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1156, 'admission_report', 'Admission Report', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1157, 'class_&_section_report', 'Class & Section Report', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1158, 'daily_reports', 'Daily Reports', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1159, 'progress', 'Progress', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1160, 'stock', 'Stock', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1161, 'issues', 'Issues', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1162, 'modules', 'Modules', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1163, 'system_student_field', 'System Student Field', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1164, 'september', 'September', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1165, 'today_birthday', 'Today Birthday', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1166, 'google_analytics', 'Google Analytics', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1167, 'parent_menu', 'Parent Menu', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1168, 'statistics', 'Statistics', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1169, 'employees', 'Employees', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1170, 'classes', 'Classes', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1171, 'fields_setting', 'Fields Setting', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1172, 'terms_conditions', 'Terms Conditions', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1173, 'online_addmission', 'Online Addmission', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1174, 'fee', 'Fee', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1175, 'fields', 'Fields', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1176, 'active', 'Active', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1177, 'file_size_shoud_be_less_than', 'File Size Shoud Be Less Than', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1178, 'default_template', 'Default Template', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1179, 'certificates', 'Certificates', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1180, 'thumb_image', 'Thumb Image', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1181, 'uploaded', 'Uploaded', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1182, 'show_website', 'Show Website', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1183, 'image_extension', 'Image Extension', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1184, 'image_size', 'Image Size', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1185, 'file_extension', 'File Extension', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1186, 'file_size', 'File Size', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1187, 'code', 'Code', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1188, 'purchase_unit', 'Purchase Unit', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1189, 'sale_unit', 'Sale Unit', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1190, 'unit_ratio', 'Unit Ratio', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1191, 'purchase_price', 'Purchase Price', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1192, 'sales_price', 'Sales Price', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1193, 'sales_unit', 'Sales Unit', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1194, 'language_unpublished', 'Language Unpublished', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1195, 'language_published', 'Language Published', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1196, 'whatsapp_settings', 'Whatsapp Settings', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1197, 'general_setting', 'General Setting', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1198, 'weekends', 'Weekends', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1199, 'sunday', 'Sunday', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1200, 'monday', 'Monday', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1201, 'tuesday', 'Tuesday', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1202, 'wednesday', 'Wednesday', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1203, 'thursday', 'Thursday', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1204, 'friday', 'Friday', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1205, 'saturday', 'Saturday', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1206, 'select_weekends', 'Select Weekends', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1207, 'unique_roll', 'Unique Roll', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1208, 'classes_wise', 'Classes Wise', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1209, 'section_wise', 'Section Wise', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1210, 'start_from', 'Start From', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1211, 'digit', 'Digit', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1212, 'fees_carry_forward_setting', 'Fees Carry Forward Setting', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1213, 'due_days', 'Due Days', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1214, 'due_fees_calculation_with_fine_', 'Due Fees Calculation With Fine ', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1215, 'header_title', 'Header Title', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1216, 'frontend_enable_chat', 'Frontend Enable Chat', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1217, 'backend_enable_chat', 'Backend Enable Chat', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1218, 'whatsapp_agent', 'Whatsapp Agent', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1219, 'agent', 'Agent', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1220, 'whataspp_number', 'Whataspp Number', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1221, 'weekend', 'Weekend', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1222, 'instructions', 'Instructions', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1223, 'suspended', 'Suspended', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1224, 'trx_id', 'Trx Id', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1225, 'submit_date', 'Submit Date', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1226, 'note', 'Note', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1227, 'create_section', 'Create Section', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1228, 'section_list', 'Section List', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1229, 'this_class_teacher_already_assigned', 'This Class Teacher Already Assigned', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1230, 'payment_status', 'Payment Status', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1231, 'guardian_picture', 'Guardian Picture', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1232, 'class_teachers_are_already_allocated_for_this_class', 'Class Teachers Are Already Allocated For This Class', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1233, 'promotion_history', 'Promotion History', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1234, 'from_class', 'From Class', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1235, 'from_session', 'From Session', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1236, 'promoted_class', 'Promoted Class', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1237, 'promoted_session', 'Promoted Session', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1238, 'promoted_date', 'Promoted Date', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1239, 'disable_reason', 'Disable Reason', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1240, 'the_next_session_was_transferred_to_the_students', 'The Next Session Was Transferred To The Students', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1241, 'promote_to_session', 'Promote To Session', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1242, 'promote_to_class', 'Promote To Class', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1243, 'promote_to_section', 'Promote To Section', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1244, 'mark_summary', 'Mark Summary', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1245, 'current_due_amount', 'Current Due Amount', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1246, 'enquiry', 'Enquiry', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1247, 'reference', 'Reference', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1248, 'next', 'Next', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1249, 'follow_up', 'Follow Up', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1250, 'previous_school', 'Previous School', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1251, 'no_of_child', 'No Of Child', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1252, 'response', 'Response', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1253, 'class_applying_for', 'Class Applying For', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1254, 'selected_revert', 'Selected Revert', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1255, 'sub_total', 'Sub Total', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1256, 'with_fine', 'With Fine', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1257, 'apply_online_admission', 'Apply Online Admission', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1258, 'no_sms_gateway_available', 'No Sms Gateway Available', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1259, 'all_days', 'All Days', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1260, 'mark_from', 'Mark From', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1261, 'mark_upto', 'Mark Upto', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1262, 'free', 'Free', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1263, 'pay', 'Pay', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1264, 'post_code', 'Post Code', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1265, 'questions_qty', 'Questions Qty', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1266, 'exam_status', 'Exam Status', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1267, 'limits_of_participation', 'Limits Of Participation', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1268, 'passing_mark', 'Passing Mark', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1269, 'instruction', 'Instruction', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1270, 'question', 'Question', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1271, 'random', 'Random', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1272, 'result_publish', 'Result Publish', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1273, 'negative_mark', 'Negative Mark', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1274, 'applicable', 'Applicable', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1275, 'marks_display', 'Marks Display', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1276, 'make', 'Make', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1277, 'level', 'Level', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1278, 'single_choice', 'Single Choice', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1279, 'multiple_choice', 'Multiple Choice', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1280, 'true/false', 'True/false', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1281, 'descriptive', 'Descriptive', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1282, 'easy', 'Easy', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1283, 'medium', 'Medium', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1284, 'hard', 'Hard', '');
INSERT INTO `languages` (`id`, `word`, `english`, `bengali`) VALUES (1285, 'october', 'October', '');


#
# TABLE STRUCTURE FOR: leave_application
#

DROP TABLE IF EXISTS `leave_application`;

CREATE TABLE `leave_application` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `category_id` int(2) NOT NULL,
  `reason` longtext CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `leave_days` varchar(20) NOT NULL DEFAULT '0',
  `status` int(2) NOT NULL DEFAULT 1 COMMENT '1=pending,2=accepted 3=rejected',
  `apply_date` date DEFAULT NULL,
  `approved_by` int(11) NOT NULL,
  `orig_file_name` varchar(255) NOT NULL,
  `enc_file_name` varchar(255) NOT NULL,
  `comments` varchar(255) NOT NULL,
  `session_id` int(11) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: leave_category
#

DROP TABLE IF EXISTS `leave_category`;

CREATE TABLE `leave_category` (
  `id` int(2) NOT NULL AUTO_INCREMENT,
  `name` longtext CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `role_id` tinyint(1) NOT NULL,
  `days` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: live_class
#

DROP TABLE IF EXISTS `live_class`;

CREATE TABLE `live_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `live_class_method` tinyint(1) NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL,
  `meeting_id` varchar(255) NOT NULL,
  `meeting_password` varchar(255) NOT NULL,
  `own_api_key` tinyint(1) NOT NULL DEFAULT 0,
  `duration` int(11) NOT NULL,
  `bbb` longtext NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` text NOT NULL,
  `remarks` text NOT NULL,
  `date` date NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `created_by` int(11) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: live_class_config
#

DROP TABLE IF EXISTS `live_class_config`;

CREATE TABLE `live_class_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `zoom_api_key` varchar(255) DEFAULT NULL,
  `zoom_api_secret` varchar(255) DEFAULT NULL,
  `bbb_salt_key` varchar(355) DEFAULT NULL,
  `bbb_server_base_url` varchar(355) DEFAULT NULL,
  `staff_api_credential` tinyint(1) NOT NULL DEFAULT 0,
  `student_api_credential` tinyint(1) NOT NULL DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `live_class_config` (`id`, `zoom_api_key`, `zoom_api_secret`, `bbb_salt_key`, `bbb_server_base_url`, `staff_api_credential`, `student_api_credential`, `branch_id`) VALUES (1, 'dddd', 'dd', 'ddd', 'dddd/', 1, 1, 1);


#
# TABLE STRUCTURE FOR: live_class_reports
#

DROP TABLE IF EXISTS `live_class_reports`;

CREATE TABLE `live_class_reports` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `live_class_id` int(11) NOT NULL,
  `student_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: login_credential
#

DROP TABLE IF EXISTS `login_credential`;

CREATE TABLE `login_credential` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(250) NOT NULL,
  `role` tinyint(2) NOT NULL,
  `active` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1(active) 0(deactivate)',
  `last_login` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (1, 1, 'info@elitedesign.com.bd', '$2y$10$pGXYtWjOyvxkLXe.EbpgD.5m.yIwHcO/cBMKHBR5c/osIC8K1LkDC', 1, 1, '2023-10-01 22:13:19', '2023-09-22 04:05:33', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (2, 2, 'shamim', '$2y$10$rxrkIhptb6J1Pe.uyxI/z.eb7IcxqPaYedTYnRJdVeVpaY65zgccW', 3, 1, NULL, '2023-09-23 17:23:43', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (3, 3, 'jahanara', '$2y$10$0M.SxELrkkE5BEEUq3CKCuzYV46Q1//Ai9yvJWylWx/W13IJGGFna', 3, 1, NULL, '2023-09-23 17:26:18', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (4, 4, 'nayeem', '$2y$10$oxydHpa7Q8JfgWlbo4ZAN.GlE8dFRXCNXH0xqPtJpnAfoDBOLA/lW', 3, 1, NULL, '2023-09-23 17:29:36', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (5, 5, 'kokhon', '$2y$10$kg3hxvN05TIvZ/bU8cOjMe91bLxzlbaJyQrwuvVVwZvvNVDzUlRSa', 3, 1, NULL, '2023-09-23 17:32:01', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (6, 6, 'shahida', '$2y$10$oGjkXa9DNCRAft9U3XlflO2XYioo1IxScTz64CUIOkY2TL1zBhoRq', 8, 1, NULL, '2023-09-23 17:36:16', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (7, 1, '31', '$2y$10$MV.o/T8GbCA4SmaZC9eFHOGoLBieKOndQZcHBEnpIJVI3yh3uTTdC', 6, 1, NULL, '2023-09-24 06:47:00', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (8, 1, '31', '$2y$10$wS0JFqJv025uqsJp13O0xOjPx/hOzWWfkpAE0jmBI1qyOiKU11E2K', 7, 1, NULL, '2023-09-24 06:47:00', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (9, 2, '32', '$2y$10$9ABkHZsCRN7AFOj5L5aMe.lMrAUNCzM1/1d8weGnByaUaMiN1fLBu', 7, 1, NULL, '2023-09-25 13:47:31', NULL);
INSERT INTO `login_credential` (`id`, `user_id`, `username`, `password`, `role`, `active`, `last_login`, `created_at`, `updated_at`) VALUES (10, 3, '33', '$2y$10$KXbPcycmOAd6dcTXEqJYUeO/nkpXzvrWTQRGLdrAxxfjCTV802nre', 7, 1, NULL, '2023-09-25 13:52:13', NULL);


#
# TABLE STRUCTURE FOR: mark
#

DROP TABLE IF EXISTS `mark`;

CREATE TABLE `mark` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `mark` text DEFAULT NULL,
  `absent` varchar(4) DEFAULT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `mark` (`id`, `student_id`, `subject_id`, `class_id`, `section_id`, `exam_id`, `mark`, `absent`, `session_id`, `branch_id`) VALUES (1, 1, 1, 1, 1, 1, '{\"1\":\"22\",\"2\":\"65\"}', '', 6, 1);
INSERT INTO `mark` (`id`, `student_id`, `subject_id`, `class_id`, `section_id`, `exam_id`, `mark`, `absent`, `session_id`, `branch_id`) VALUES (2, 2, 1, 1, 1, 1, '{\"1\":\"30\",\"2\":\"69\"}', '', 6, 1);
INSERT INTO `mark` (`id`, `student_id`, `subject_id`, `class_id`, `section_id`, `exam_id`, `mark`, `absent`, `session_id`, `branch_id`) VALUES (3, 3, 1, 1, 1, 1, '{\"1\":\"20\",\"2\":\"32\"}', '', 6, 1);
INSERT INTO `mark` (`id`, `student_id`, `subject_id`, `class_id`, `section_id`, `exam_id`, `mark`, `absent`, `session_id`, `branch_id`) VALUES (4, 1, 2, 1, 1, 1, '{\"1\":\"25\",\"2\":\"70\"}', '', 6, 1);
INSERT INTO `mark` (`id`, `student_id`, `subject_id`, `class_id`, `section_id`, `exam_id`, `mark`, `absent`, `session_id`, `branch_id`) VALUES (5, 2, 2, 1, 1, 1, '{\"1\":\"20\",\"2\":\"70\"}', '', 6, 1);
INSERT INTO `mark` (`id`, `student_id`, `subject_id`, `class_id`, `section_id`, `exam_id`, `mark`, `absent`, `session_id`, `branch_id`) VALUES (6, 3, 2, 1, 1, 1, '{\"1\":\"15\",\"2\":\"70\"}', '', 6, 1);
INSERT INTO `mark` (`id`, `student_id`, `subject_id`, `class_id`, `section_id`, `exam_id`, `mark`, `absent`, `session_id`, `branch_id`) VALUES (7, 1, 3, 1, 1, 1, '{\"1\":\"30\",\"2\":\"70\"}', '', 6, 1);
INSERT INTO `mark` (`id`, `student_id`, `subject_id`, `class_id`, `section_id`, `exam_id`, `mark`, `absent`, `session_id`, `branch_id`) VALUES (8, 2, 3, 1, 1, 1, '{\"1\":\"30\",\"2\":\"68\"}', '', 6, 1);
INSERT INTO `mark` (`id`, `student_id`, `subject_id`, `class_id`, `section_id`, `exam_id`, `mark`, `absent`, `session_id`, `branch_id`) VALUES (9, 3, 3, 1, 1, 1, '{\"1\":\"30\",\"2\":\"50\"}', '', 6, 1);


#
# TABLE STRUCTURE FOR: message
#

DROP TABLE IF EXISTS `message`;

CREATE TABLE `message` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `subject` varchar(255) NOT NULL,
  `file_name` text DEFAULT NULL,
  `enc_name` text DEFAULT NULL,
  `trash_sent` tinyint(1) NOT NULL,
  `trash_inbox` int(11) NOT NULL,
  `fav_inbox` tinyint(1) NOT NULL,
  `fav_sent` tinyint(1) NOT NULL,
  `reciever` varchar(100) NOT NULL,
  `sender` varchar(100) NOT NULL,
  `read_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 unread 1 read',
  `reply_status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0 unread 1 read',
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: message_reply
#

DROP TABLE IF EXISTS `message_reply`;

CREATE TABLE `message_reply` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `message_id` int(11) NOT NULL,
  `body` text NOT NULL,
  `file_name` text NOT NULL,
  `enc_name` text NOT NULL,
  `identity` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: migrations
#

DROP TABLE IF EXISTS `migrations`;

CREATE TABLE `migrations` (
  `version` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `migrations` (`version`) VALUES ('600');


#
# TABLE STRUCTURE FOR: modules_manage
#

DROP TABLE IF EXISTS `modules_manage`;

CREATE TABLE `modules_manage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `modules_id` int(11) NOT NULL,
  `isEnabled` tinyint(1) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: offline_fees_payments
#

DROP TABLE IF EXISTS `offline_fees_payments`;

CREATE TABLE `offline_fees_payments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_method` int(11) NOT NULL,
  `invoice_no` varchar(50) DEFAULT NULL,
  `student_enroll_id` int(11) DEFAULT NULL,
  `fees_allocation_id` int(11) DEFAULT NULL,
  `fees_type_id` int(11) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `reference` varchar(200) DEFAULT NULL,
  `amount` float(10,2) DEFAULT NULL,
  `submit_date` datetime DEFAULT NULL,
  `approve_date` datetime DEFAULT NULL,
  `orig_file_name` varchar(255) DEFAULT NULL,
  `enc_file_name` text DEFAULT NULL,
  `note` varchar(255) DEFAULT NULL,
  `comments` text DEFAULT NULL,
  `approved_by` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `student_fees_master_id` (`fees_allocation_id`),
  KEY `fee_groups_feetype_id` (`fees_type_id`),
  KEY `offline_fees_payments_ibfk_4` (`approved_by`),
  KEY `student_session_id` (`student_enroll_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: offline_payment_types
#

DROP TABLE IF EXISTS `offline_payment_types`;

CREATE TABLE `offline_payment_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `note` varchar(500) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `offline_payment_types` (`id`, `name`, `note`, `branch_id`) VALUES (1, 'বিকাশ', '<p><span xss=removed>*167# ডায়াল করে আপনার NAGAD মোবাইল মেনুতে যান অথবা NAGAD অ্যাপে যান।</span><br></p><ul class=\"mt-5 text-slate-200\" xss=removed><hr class=\"brand-hr my-3\" xss=removed><li class=\"flex text-sm\" xss=removed><div xss=removed><span class=\"inline-block w-1.5 h-1.5 mr-2 bg-white rounded-full mb-0.5\" xss=removed></span></div><p class=\"font-bangla\" xss=removed><span class=\"text-yellow-300 font-semibold ml-1\" xss=removed>\"Send Money\" </span>-এ ক্লিক করুন।</p></li><hr class=\"brand-hr my', 1);
INSERT INTO `offline_payment_types` (`id`, `name`, `note`, `branch_id`) VALUES (2, 'রকেট', '<p><br></p><ul class=\"mt-5 text-slate-200\" xss=removed><li class=\"flex text-sm\" xss=removed><p class=\"font-bangla\" xss=removed>*167# ডায়াল করে আপনার NAGAD মোবাইল মেনুতে যান অথবা NAGAD অ্যাপে যান।</p></li><hr class=\"brand-hr my-3\" xss=removed><li class=\"flex text-sm\" xss=removed><div xss=removed><span class=\"inline-block w-1.5 h-1.5 mr-2 bg-white rounded-full mb-0.5\" xss=removed></span></div><p class=\"font-bangla\" xss=removed><span class=\"text-yellow-300 font-semibold ml-1\" xss=removed>\"Send Mon', 1);
INSERT INTO `offline_payment_types` (`id`, `name`, `note`, `branch_id`) VALUES (3, 'নগদ', '<p><br></p><ul class=\"mt-5 text-slate-200\" xss=removed><li class=\"flex text-sm\" xss=removed><p class=\"font-bangla\" xss=removed>*167# ডায়াল করে আপনার NAGAD মোবাইল মেনুতে যান অথবা NAGAD অ্যাপে যান।</p></li><hr class=\"brand-hr my-3\" xss=removed><li class=\"flex text-sm\" xss=removed><div xss=removed><span class=\"inline-block w-1.5 h-1.5 mr-2 bg-white rounded-full mb-0.5\" xss=removed></span></div><p class=\"font-bangla\" xss=removed><span class=\"text-yellow-300 font-semibold ml-1\" xss=removed>\"Send Mon', 1);


#
# TABLE STRUCTURE FOR: online_admission
#

DROP TABLE IF EXISTS `online_admission`;

CREATE TABLE `online_admission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `gender` varchar(25) DEFAULT NULL,
  `birthday` varchar(100) DEFAULT NULL,
  `religion` varchar(100) DEFAULT NULL,
  `caste` varchar(100) DEFAULT NULL,
  `blood_group` varchar(100) DEFAULT NULL,
  `mobile_no` varchar(50) DEFAULT NULL,
  `mother_tongue` varchar(100) DEFAULT NULL,
  `present_address` text DEFAULT NULL,
  `permanent_address` text DEFAULT NULL,
  `admission_date` varchar(100) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `student_photo` varchar(255) DEFAULT NULL,
  `category_id` varchar(11) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `previous_school_details` text DEFAULT NULL,
  `guardian_name` varchar(255) DEFAULT NULL,
  `guardian_relation` varchar(50) DEFAULT NULL,
  `father_name` varchar(255) DEFAULT NULL,
  `mother_name` varchar(255) DEFAULT NULL,
  `grd_occupation` varchar(255) DEFAULT NULL,
  `grd_income` varchar(25) DEFAULT NULL,
  `grd_education` varchar(255) DEFAULT NULL,
  `grd_email` varchar(255) DEFAULT NULL,
  `grd_mobile_no` varchar(50) DEFAULT NULL,
  `grd_address` text DEFAULT NULL,
  `grd_city` varchar(255) DEFAULT NULL,
  `grd_state` varchar(255) DEFAULT NULL,
  `grd_photo` varchar(255) DEFAULT NULL,
  `status` tinyint(3) NOT NULL DEFAULT 1,
  `payment_status` tinyint(1) NOT NULL DEFAULT 0,
  `payment_amount` decimal(18,2) NOT NULL,
  `payment_details` longtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` varchar(11) DEFAULT NULL,
  `apply_date` datetime NOT NULL,
  `doc` varchar(255) DEFAULT NULL,
  `created_date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `online_admission` (`id`, `first_name`, `last_name`, `gender`, `birthday`, `religion`, `caste`, `blood_group`, `mobile_no`, `mother_tongue`, `present_address`, `permanent_address`, `admission_date`, `city`, `state`, `student_photo`, `category_id`, `email`, `previous_school_details`, `guardian_name`, `guardian_relation`, `father_name`, `mother_name`, `grd_occupation`, `grd_income`, `grd_education`, `grd_email`, `grd_mobile_no`, `grd_address`, `grd_city`, `grd_state`, `grd_photo`, `status`, `payment_status`, `payment_amount`, `payment_details`, `branch_id`, `class_id`, `section_id`, `apply_date`, `doc`, `created_date`) VALUES (1, 'Md', 'Abdul', 'male', '', 'Islam', 'vvv', 'O+', '01775457008', 'Bengali', '35/3/1-B', 'vdsdssvv', '2023-09-26', 'Dhaka', 'kf', 'cc92d03e71e7397dfb43b8480fb31b31.png', NULL, 'shadhinhostbd@gmail.com', '{\"school_name\":\"Roup Nagar Abasik High School\",\"qualification\":\"KG\",\"remarks\":\"444\"}', 'Md Abu Sayed', 'Father', 'Mst Nurunahar', 'Mst Nurunahar', 'Business', '3000', 'ssc', 'info.elitedesignsbd@gmail.com', '01775457008', '35/3/1-B', 'Dhaka', 'kf', 'b650d68529d4fdfe4b8f3447d25c2251.jpg', 1, 0, '0.00', '', 1, 1, NULL, '2023-09-26 01:33:55', '9295d18593c9502d30dd0a2205b611a3.png', '2023-09-26 01:33:55');
INSERT INTO `online_admission` (`id`, `first_name`, `last_name`, `gender`, `birthday`, `religion`, `caste`, `blood_group`, `mobile_no`, `mother_tongue`, `present_address`, `permanent_address`, `admission_date`, `city`, `state`, `student_photo`, `category_id`, `email`, `previous_school_details`, `guardian_name`, `guardian_relation`, `father_name`, `mother_name`, `grd_occupation`, `grd_income`, `grd_education`, `grd_email`, `grd_mobile_no`, `grd_address`, `grd_city`, `grd_state`, `grd_photo`, `status`, `payment_status`, `payment_amount`, `payment_details`, `branch_id`, `class_id`, `section_id`, `apply_date`, `doc`, `created_date`) VALUES (2, 'Md', 'mamunur Rashid', 'male', '', 'Islam', NULL, '', '01775457008', NULL, '35/3/1-B', '', '2023-09-26', NULL, NULL, '1da5ac3ce07dc6333fb170b99d87ed87.png', NULL, 'shadhinhostbd@gmail.com', '{\"school_name\":\"Roup Nagar Abasik High School\",\"qualification\":\"KG\",\"remarks\":\"fghgfg\"}', 'mgfff', 'faasas', 'vcvcxvx', 'cvvxc', 'cxvx', NULL, 'cxvxvx', 'info.elitedesignsbd@gmail.com', '01775457008', '35/3/1-B', NULL, NULL, '70935dcd005cfe7b85d9cb026366d40f.jpg', 1, 0, '0.00', '', 1, 1, NULL, '2023-09-26 01:44:20', '', '2023-09-26 01:44:20');


#
# TABLE STRUCTURE FOR: online_admission_fields
#

DROP TABLE IF EXISTS `online_admission_fields`;

CREATE TABLE `online_admission_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fields_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `required` tinyint(4) NOT NULL DEFAULT 0,
  `system` tinyint(1) NOT NULL DEFAULT 1,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (1, 2, 1, 1, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (2, 3, 1, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (3, 4, 0, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (4, 5, 1, 1, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (5, 6, 0, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (6, 7, 0, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (7, 8, 1, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (8, 9, 0, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (9, 10, 1, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (10, 11, 0, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (11, 12, 1, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (12, 13, 1, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (13, 14, 0, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (14, 15, 0, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (15, 16, 1, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (16, 17, 1, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (17, 18, 1, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (18, 19, 1, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (19, 20, 1, 1, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (20, 21, 1, 1, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (21, 22, 1, 1, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (22, 23, 1, 1, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (23, 24, 1, 1, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (24, 25, 0, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (25, 26, 1, 1, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (26, 27, 1, 1, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (27, 28, 1, 1, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (28, 29, 1, 1, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (29, 30, 1, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (30, 31, 0, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (31, 32, 0, 0, 1, 1);
INSERT INTO `online_admission_fields` (`id`, `fields_id`, `status`, `required`, `system`, `branch_id`) VALUES (32, 33, 0, 0, 1, 1);


#
# TABLE STRUCTURE FOR: online_exam
#

DROP TABLE IF EXISTS `online_exam`;

CREATE TABLE `online_exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) DEFAULT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` text NOT NULL,
  `subject_id` text NOT NULL,
  `limits_participation` int(11) NOT NULL,
  `exam_start` datetime DEFAULT NULL,
  `exam_end` datetime DEFAULT NULL,
  `duration` time NOT NULL,
  `mark_type` tinyint(1) NOT NULL DEFAULT 1,
  `passing_mark` float NOT NULL DEFAULT 0,
  `instruction` text DEFAULT NULL,
  `session_id` int(11) DEFAULT NULL,
  `publish_result` tinyint(1) NOT NULL DEFAULT 0,
  `marks_display` tinyint(1) NOT NULL DEFAULT 1,
  `neg_mark` tinyint(1) NOT NULL DEFAULT 0,
  `question_type` tinyint(1) NOT NULL DEFAULT 0,
  `publish_status` tinyint(1) NOT NULL DEFAULT 0,
  `exam_type` tinyint(1) NOT NULL DEFAULT 0,
  `fee` float NOT NULL DEFAULT 0,
  `created_by` int(11) NOT NULL,
  `position_generated` tinyint(1) NOT NULL DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `session_id` (`session_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: online_exam_answer
#

DROP TABLE IF EXISTS `online_exam_answer`;

CREATE TABLE `online_exam_answer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `online_exam_id` int(11) NOT NULL,
  `question_id` int(11) NOT NULL,
  `answer` longtext DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: online_exam_attempts
#

DROP TABLE IF EXISTS `online_exam_attempts`;

CREATE TABLE `online_exam_attempts` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `online_exam_id` int(11) NOT NULL,
  `count` float NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: online_exam_payment
#

DROP TABLE IF EXISTS `online_exam_payment`;

CREATE TABLE `online_exam_payment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `exam_id` int(11) NOT NULL,
  `payment_method` tinyint(4) NOT NULL,
  `amount` float NOT NULL DEFAULT 0,
  `transaction_id` varchar(500) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: online_exam_submitted
#

DROP TABLE IF EXISTS `online_exam_submitted`;

CREATE TABLE `online_exam_submitted` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `online_exam_id` int(11) NOT NULL,
  `remark` text CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `position` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: parent
#

DROP TABLE IF EXISTS `parent`;

CREATE TABLE `parent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `relation` varchar(255) DEFAULT NULL,
  `father_name` varchar(255) DEFAULT NULL,
  `mother_name` varchar(255) DEFAULT NULL,
  `occupation` varchar(100) DEFAULT NULL,
  `income` varchar(100) DEFAULT NULL,
  `education` varchar(255) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `mobileno` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `facebook_url` varchar(255) DEFAULT NULL,
  `linkedin_url` varchar(255) DEFAULT NULL,
  `twitter_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  `active` tinyint(2) NOT NULL DEFAULT 0 COMMENT '0(active) 1(deactivate)',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `parent` (`id`, `name`, `relation`, `father_name`, `mother_name`, `occupation`, `income`, `education`, `email`, `mobileno`, `address`, `city`, `state`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`, `active`) VALUES (1, 'Md Abdul Rashid', 'Father', 'Md Abdul Rashi', 'Nurunnahar', 'Business', '100000', 'SSC', 'rashid@gmail.com', '01775457008', 'lalmonir Hat', 'Lalmonir Hat', 'LH', 1, '5a1c1a6fcf8f552866d7959f110a1074.jpg', NULL, NULL, NULL, '2023-09-24 06:47:00', NULL, 0);


#
# TABLE STRUCTURE FOR: payment_config
#

DROP TABLE IF EXISTS `payment_config`;

CREATE TABLE `payment_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `paypal_username` varchar(255) DEFAULT NULL,
  `paypal_password` varchar(255) DEFAULT NULL,
  `paypal_signature` varchar(255) DEFAULT NULL,
  `paypal_email` varchar(255) DEFAULT NULL,
  `paypal_sandbox` tinyint(4) DEFAULT NULL,
  `paypal_status` tinyint(4) DEFAULT NULL,
  `stripe_secret` varchar(255) DEFAULT NULL,
  `stripe_publishiable` varchar(255) NOT NULL,
  `stripe_demo` varchar(255) DEFAULT NULL,
  `stripe_status` tinyint(4) DEFAULT NULL,
  `payumoney_key` varchar(255) DEFAULT NULL,
  `payumoney_salt` varchar(255) DEFAULT NULL,
  `payumoney_demo` tinyint(4) DEFAULT NULL,
  `payumoney_status` tinyint(4) DEFAULT NULL,
  `paystack_secret_key` varchar(255) NOT NULL,
  `paystack_status` tinyint(4) NOT NULL,
  `razorpay_key_id` varchar(255) NOT NULL,
  `razorpay_key_secret` varchar(255) NOT NULL,
  `razorpay_demo` tinyint(4) NOT NULL,
  `razorpay_status` tinyint(4) NOT NULL,
  `sslcz_store_id` varchar(255) NOT NULL,
  `sslcz_store_passwd` varchar(255) NOT NULL,
  `sslcommerz_sandbox` tinyint(1) NOT NULL,
  `sslcommerz_status` tinyint(1) NOT NULL,
  `jazzcash_merchant_id` varchar(255) NOT NULL,
  `jazzcash_passwd` varchar(255) NOT NULL,
  `jazzcash_integerity_salt` varchar(255) NOT NULL,
  `jazzcash_sandbox` tinyint(1) NOT NULL,
  `jazzcash_status` tinyint(1) NOT NULL,
  `midtrans_client_key` varchar(255) NOT NULL,
  `midtrans_server_key` varchar(255) NOT NULL,
  `midtrans_sandbox` tinyint(1) NOT NULL,
  `midtrans_status` tinyint(1) NOT NULL,
  `flutterwave_public_key` varchar(255) DEFAULT NULL,
  `flutterwave_secret_key` varchar(255) DEFAULT NULL,
  `flutterwave_sandbox` tinyint(4) NOT NULL DEFAULT 0,
  `flutterwave_status` tinyint(4) NOT NULL DEFAULT 0,
  `paytm_merchantmid` varchar(255) DEFAULT NULL,
  `paytm_merchantkey` varchar(255) DEFAULT NULL,
  `paytm_merchant_website` varchar(255) DEFAULT NULL,
  `paytm_industry_type` varchar(255) DEFAULT NULL,
  `paytm_status` tinyint(1) NOT NULL DEFAULT 0,
  `toyyibpay_secretkey` varchar(255) DEFAULT NULL,
  `toyyibpay_categorycode` varchar(255) DEFAULT NULL,
  `toyyibpay_status` tinyint(1) NOT NULL DEFAULT 0,
  `payhere_merchant_id` varchar(255) DEFAULT NULL,
  `payhere_merchant_secret` varchar(255) DEFAULT NULL,
  `payhere_status` tinyint(1) NOT NULL DEFAULT 0,
  `nepalste_public_key` varchar(255) DEFAULT NULL,
  `nepalste_secret_key` varchar(255) DEFAULT NULL,
  `nepalste_status` tinyint(1) NOT NULL DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `payment_config` (`id`, `paypal_username`, `paypal_password`, `paypal_signature`, `paypal_email`, `paypal_sandbox`, `paypal_status`, `stripe_secret`, `stripe_publishiable`, `stripe_demo`, `stripe_status`, `payumoney_key`, `payumoney_salt`, `payumoney_demo`, `payumoney_status`, `paystack_secret_key`, `paystack_status`, `razorpay_key_id`, `razorpay_key_secret`, `razorpay_demo`, `razorpay_status`, `sslcz_store_id`, `sslcz_store_passwd`, `sslcommerz_sandbox`, `sslcommerz_status`, `jazzcash_merchant_id`, `jazzcash_passwd`, `jazzcash_integerity_salt`, `jazzcash_sandbox`, `jazzcash_status`, `midtrans_client_key`, `midtrans_server_key`, `midtrans_sandbox`, `midtrans_status`, `flutterwave_public_key`, `flutterwave_secret_key`, `flutterwave_sandbox`, `flutterwave_status`, `paytm_merchantmid`, `paytm_merchantkey`, `paytm_merchant_website`, `paytm_industry_type`, `paytm_status`, `toyyibpay_secretkey`, `toyyibpay_categorycode`, `toyyibpay_status`, `payhere_merchant_id`, `payhere_merchant_secret`, `payhere_status`, `nepalste_public_key`, `nepalste_secret_key`, `nepalste_status`, `branch_id`, `created_at`, `updated_at`) VALUES (1, NULL, NULL, NULL, NULL, NULL, 0, NULL, '', NULL, 0, NULL, NULL, NULL, 0, '', 0, '', '', 0, 0, 'fff', 'fff', 1, 1, '', '', '', 0, 0, '', '', 0, 0, NULL, NULL, 0, 0, NULL, NULL, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, NULL, NULL, 0, 1, '2023-09-25 15:35:21', NULL);


#
# TABLE STRUCTURE FOR: payment_salary_stipend
#

DROP TABLE IF EXISTS `payment_salary_stipend`;

CREATE TABLE `payment_salary_stipend` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `name` longtext NOT NULL,
  `amount` int(11) NOT NULL,
  `type` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: payment_types
#

DROP TABLE IF EXISTS `payment_types`;

CREATE TABLE `payment_types` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL DEFAULT 0,
  `timestamp` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (1, 'Cash', 0, '2019-07-27 18:12:21');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (2, 'Card', 0, '2019-07-27 18:12:31');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (3, 'Cheque', 0, '2019-12-21 10:07:59');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (4, 'Bank Transfer', 0, '2019-12-21 10:08:36');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (5, 'Other', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (6, 'Paypal', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (7, 'Stripe', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (8, 'PayUmoney', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (9, 'Paystack', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (10, 'Razorpay', 0, '2019-12-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (11, 'SSLcommerz', 0, '2022-05-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (12, 'Jazzcash', 0, '2022-05-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (13, 'Midtrans', 0, '2022-05-21 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (14, 'Flutter Wave', 0, '2022-05-15 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (15, 'Offline Payments', 0, '2022-05-15 10:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (16, 'Paytm', 0, '2023-05-12 12:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (17, 'toyyibPay', 0, '2023-05-12 12:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (18, 'Payhere', 0, '2023-05-12 12:08:45');
INSERT INTO `payment_types` (`id`, `name`, `branch_id`, `timestamp`) VALUES (19, 'Nepalste', 0, '2023-05-12 12:08:45');


#
# TABLE STRUCTURE FOR: payslip
#

DROP TABLE IF EXISTS `payslip`;

CREATE TABLE `payslip` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `month` varchar(200) DEFAULT NULL,
  `year` varchar(20) NOT NULL,
  `basic_salary` decimal(18,2) NOT NULL,
  `total_allowance` decimal(18,2) NOT NULL,
  `total_deduction` decimal(18,2) NOT NULL,
  `net_salary` decimal(18,2) NOT NULL,
  `bill_no` varchar(25) NOT NULL,
  `remarks` text NOT NULL,
  `pay_via` tinyint(1) NOT NULL,
  `hash` varchar(200) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `paid_by` varchar(200) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: payslip_details
#

DROP TABLE IF EXISTS `payslip_details`;

CREATE TABLE `payslip_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payslip_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `amount` decimal(18,2) NOT NULL,
  `type` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: permission
#

DROP TABLE IF EXISTS `permission`;

CREATE TABLE `permission` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module_id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `prefix` varchar(100) NOT NULL,
  `show_view` tinyint(1) DEFAULT 1,
  `show_add` tinyint(1) DEFAULT 1,
  `show_edit` tinyint(1) DEFAULT 1,
  `show_delete` tinyint(1) DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=168 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (1, 2, 'Student', 'student', 1, 1, 1, 1, '2020-01-22 06:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (2, 2, 'Multiple Import', 'multiple_import', 0, 1, 0, 0, '2020-01-22 06:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (3, 2, 'Student Category', 'student_category', 1, 1, 1, 1, '2020-01-22 06:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (4, 2, 'Student Id Card', 'student_id_card', 1, 0, 0, 0, '2020-01-22 06:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (5, 2, 'Disable Authentication', 'student_disable_authentication', 1, 1, 0, 0, '2020-01-22 06:45:47');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (6, 4, 'Employee', 'employee', 1, 1, 1, 1, '2020-01-22 06:55:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (7, 3, 'Parent', 'parent', 1, 1, 1, 1, '2020-01-22 08:24:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (8, 3, 'Disable Authentication', 'parent_disable_authentication', 1, 1, 0, 0, '2020-01-22 09:22:21');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (9, 4, 'Department', 'department', 1, 1, 1, 1, '2020-01-22 12:41:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (10, 4, 'Designation', 'designation', 1, 1, 1, 1, '2020-01-22 12:41:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (11, 4, 'Disable Authentication', 'employee_disable_authentication', 1, 1, 0, 0, '2020-01-22 12:41:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (12, 5, 'Salary Template', 'salary_template', 1, 1, 1, 1, '2020-01-23 00:13:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (13, 5, 'Salary Assign', 'salary_assign', 1, 1, 0, 0, '2020-01-23 00:14:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (14, 5, 'Salary Payment', 'salary_payment', 1, 1, 0, 0, '2020-01-24 01:45:40');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (15, 5, 'Salary Summary Report', 'salary_summary_report', 1, 0, 0, 0, '2020-03-14 13:09:17');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (16, 5, 'Advance Salary', 'advance_salary', 1, 1, 1, 1, '2020-01-28 13:23:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (17, 5, 'Advance Salary Manage', 'advance_salary_manage', 1, 1, 1, 1, '2020-01-24 23:57:12');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (18, 5, 'Advance Salary Request', 'advance_salary_request', 1, 1, 0, 1, '2020-01-28 12:49:58');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (19, 5, 'Leave Category', 'leave_category', 1, 1, 1, 1, '2020-01-28 21:46:23');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (20, 5, 'Leave Request', 'leave_request', 1, 1, 1, 1, '2020-01-30 07:06:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (21, 5, 'Leave Manage', 'leave_manage', 1, 1, 1, 1, '2020-01-29 02:27:15');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (22, 5, 'Award', 'award', 1, 1, 1, 1, '2020-01-31 13:49:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (23, 6, 'Classes', 'classes', 1, 1, 1, 1, '2020-02-01 13:10:00');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (24, 6, 'Section', 'section', 1, 1, 1, 1, '2020-02-01 16:06:44');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (25, 6, 'Assign Class Teacher', 'assign_class_teacher', 1, 1, 1, 1, '2020-02-02 02:09:22');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (26, 6, 'Subject', 'subject', 1, 1, 1, 1, '2020-02-02 23:32:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (27, 6, 'Subject Class Assign ', 'subject_class_assign', 1, 1, 1, 1, '2020-02-03 12:43:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (28, 6, 'Subject Teacher Assign', 'subject_teacher_assign', 1, 1, 0, 1, '2020-02-03 14:05:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (29, 6, 'Class Timetable', 'class_timetable', 1, 1, 1, 1, '2020-02-04 00:50:37');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (30, 2, 'Student Promotion', 'student_promotion', 1, 1, 0, 0, '2020-02-05 13:20:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (31, 8, 'Attachments', 'attachments', 1, 1, 1, 1, '2020-02-06 12:59:43');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (32, 7, 'Homework', 'homework', 1, 1, 1, 1, '2020-02-07 00:40:08');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (33, 8, 'Attachment Type', 'attachment_type', 1, 1, 1, 1, '2020-02-07 02:16:28');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (34, 9, 'Exam', 'exam', 1, 1, 1, 1, '2020-02-07 04:59:29');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (35, 9, 'Exam Term', 'exam_term', 1, 1, 1, 1, '2020-02-07 07:09:28');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (36, 9, 'Exam Hall', 'exam_hall', 1, 1, 1, 1, '2020-02-07 09:31:04');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (37, 9, 'Exam Timetable', 'exam_timetable', 1, 1, 0, 1, '2020-02-08 12:04:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (38, 9, 'Exam Mark', 'exam_mark', 1, 1, 1, 1, '2020-02-10 07:53:41');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (39, 9, 'Exam Grade', 'exam_grade', 1, 1, 1, 1, '2020-02-10 12:29:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (40, 10, 'Hostel', 'hostel', 1, 1, 1, 1, '2020-02-10 23:41:36');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (41, 10, 'Hostel Category', 'hostel_category', 1, 1, 1, 1, '2020-02-11 02:52:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (42, 10, 'Hostel Room', 'hostel_room', 1, 1, 1, 1, '2020-02-11 06:50:09');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (43, 10, 'Hostel Allocation', 'hostel_allocation', 1, 0, 0, 1, '2020-02-11 08:06:15');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (44, 11, 'Transport Route', 'transport_route', 1, 1, 1, 1, '2020-02-12 00:26:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (45, 11, 'Transport Vehicle', 'transport_vehicle', 1, 1, 1, 1, '2020-02-12 00:57:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (46, 11, 'Transport Stoppage', 'transport_stoppage', 1, 1, 1, 1, '2020-02-12 01:49:20');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (47, 11, 'Transport Assign', 'transport_assign', 1, 1, 1, 1, '2020-02-12 04:55:21');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (48, 11, 'Transport Allocation', 'transport_allocation', 1, 0, 0, 1, '2020-02-12 14:33:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (49, 12, 'Student Attendance', 'student_attendance', 0, 1, 0, 0, '2020-02-13 00:25:53');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (50, 12, 'Employee Attendance', 'employee_attendance', 0, 1, 0, 0, '2020-02-13 05:04:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (51, 12, 'Exam Attendance', 'exam_attendance', 0, 1, 0, 0, '2020-02-13 06:08:14');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (52, 12, 'Student Attendance Report', 'student_attendance_report', 1, 0, 0, 0, '2020-02-13 14:20:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (53, 12, 'Employee Attendance Report', 'employee_attendance_report', 1, 0, 0, 0, '2020-02-14 01:08:53');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (54, 12, 'Exam Attendance Report', 'exam_attendance_report', 1, 0, 0, 0, '2020-02-14 01:21:40');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (55, 13, 'Book', 'book', 1, 1, 1, 1, '2020-02-14 01:40:42');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (56, 13, 'Book Category', 'book_category', 1, 1, 1, 1, '2020-02-14 23:11:41');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (57, 13, 'Book Manage', 'book_manage', 1, 1, 0, 1, '2020-02-15 06:13:24');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (58, 13, 'Book Request', 'book_request', 1, 1, 0, 1, '2020-02-17 01:45:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (59, 14, 'Event', 'event', 1, 1, 1, 1, '2020-02-17 13:02:15');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (60, 14, 'Event Type', 'event_type', 1, 1, 1, 1, '2020-02-17 23:40:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (61, 15, 'Sendsmsmail', 'sendsmsmail', 1, 1, 0, 1, '2020-02-22 02:19:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (62, 15, 'Sendsmsmail Template', 'sendsmsmail_template', 1, 1, 1, 1, '2020-02-22 05:14:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (63, 17, 'Account', 'account', 1, 1, 1, 1, '2020-02-25 04:34:43');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (64, 17, 'Deposit', 'deposit', 1, 1, 1, 1, '2020-02-25 07:56:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (65, 17, 'Expense', 'expense', 1, 1, 1, 1, '2020-02-26 01:35:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (66, 17, 'All Transactions', 'all_transactions', 1, 0, 0, 0, '2020-02-26 08:35:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (67, 17, 'Voucher Head', 'voucher_head', 1, 1, 1, 1, '2020-02-25 05:50:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (68, 17, 'Accounting Reports', 'accounting_reports', 1, 1, 1, 1, '2020-02-25 08:36:24');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (69, 16, 'Fees Type', 'fees_type', 1, 1, 1, 1, '2020-02-27 05:11:03');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (70, 16, 'Fees Group', 'fees_group', 1, 1, 1, 1, '2020-02-26 00:49:09');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (71, 16, 'Fees Fine Setup', 'fees_fine_setup', 1, 1, 1, 1, '2020-03-04 21:59:27');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (72, 16, 'Fees Allocation', 'fees_allocation', 1, 1, 1, 1, '2020-03-01 08:47:43');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (73, 16, 'Collect Fees', 'collect_fees', 0, 1, 0, 0, '2020-03-15 00:23:58');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (74, 16, 'Fees Reminder', 'fees_reminder', 1, 1, 1, 1, '2020-03-15 00:29:58');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (75, 16, 'Due Invoice', 'due_invoice', 1, 0, 0, 0, '2020-03-15 00:33:36');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (76, 16, 'Invoice', 'invoice', 1, 0, 0, 1, '2020-03-15 00:38:06');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (77, 9, 'Mark Distribution', 'mark_distribution', 1, 1, 1, 1, '2020-03-19 09:02:54');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (78, 9, 'Report Card', 'report_card', 1, 0, 0, 0, '2020-03-20 08:20:28');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (79, 9, 'Tabulation Sheet', 'tabulation_sheet', 1, 0, 0, 0, '2020-03-21 03:12:38');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (80, 15, 'Sendsmsmail Reports', 'sendsmsmail_reports', 1, 0, 0, 0, '2020-03-21 13:02:02');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (81, 18, 'Global Settings', 'global_settings', 1, 0, 1, 0, '2020-03-22 01:05:41');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (82, 18, 'Payment Settings', 'payment_settings', 1, 1, 0, 0, '2020-03-22 01:08:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (83, 18, 'Sms Settings', 'sms_settings', 1, 1, 1, 1, '2020-03-22 01:08:57');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (84, 18, 'Email Settings', 'email_settings', 1, 1, 1, 1, '2020-03-22 01:10:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (85, 18, 'Translations', 'translations', 1, 1, 1, 1, '2020-03-22 01:18:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (86, 18, 'Backup', 'backup', 1, 1, 1, 1, '2020-03-22 03:09:33');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (87, 18, 'Backup Restore', 'backup_restore', 0, 1, 0, 0, '2020-03-22 03:09:34');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (88, 7, 'Homework Evaluate', 'homework_evaluate', 1, 1, 0, 0, '2020-03-28 00:20:29');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (89, 7, 'Evaluation Report', 'evaluation_report', 1, 0, 0, 0, '2020-03-28 05:56:04');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (90, 18, 'School Settings', 'school_settings', 1, 0, 1, 0, '2020-03-30 13:36:37');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (91, 1, 'Monthly Income Vs Expense Pie Chart', 'monthly_income_vs_expense_chart', 1, 0, 0, 0, '2020-03-31 02:15:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (92, 1, 'Annual Student Fees Summary Chart', 'annual_student_fees_summary_chart', 1, 0, 0, 0, '2020-03-31 02:15:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (93, 1, 'Employee Count Widget', 'employee_count_widget', 1, 0, 0, 0, '2020-03-31 02:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (94, 1, 'Student Count Widget', 'student_count_widget', 1, 0, 0, 0, '2020-03-31 02:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (95, 1, 'Parent Count Widget', 'parent_count_widget', 1, 0, 0, 0, '2020-03-31 02:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (96, 1, 'Teacher Count Widget', 'teacher_count_widget', 1, 0, 0, 0, '2020-03-31 02:31:56');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (97, 1, 'Student Quantity Pie Chart', 'student_quantity_pie_chart', 1, 0, 0, 0, '2020-03-31 03:14:07');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (98, 1, 'Weekend Attendance Inspection Chart', 'weekend_attendance_inspection_chart', 1, 0, 0, 0, '2020-03-31 03:14:07');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (99, 1, 'Admission Count Widget', 'admission_count_widget', 1, 0, 0, 0, '2020-03-31 03:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (100, 1, 'Voucher Count Widget', 'voucher_count_widget', 1, 0, 0, 0, '2020-03-31 03:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (101, 1, 'Transport Count Widget', 'transport_count_widget', 1, 0, 0, 0, '2020-03-31 03:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (102, 1, 'Hostel Count Widget', 'hostel_count_widget', 1, 0, 0, 0, '2020-03-31 03:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (103, 18, 'Accounting Links', 'accounting_links', 1, 0, 1, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (104, 16, 'Fees Reports', 'fees_reports', 1, 0, 0, 0, '2020-04-01 11:52:19');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (105, 18, 'Cron Job', 'cron_job', 1, 0, 1, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (106, 18, 'Custom Field', 'custom_field', 1, 1, 1, 1, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (107, 5, 'Leave Reports', 'leave_reports', 1, 0, 0, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (108, 18, 'Live Class Config', 'live_class_config', 1, 0, 1, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (109, 19, 'Live Class', 'live_class', 1, 1, 1, 1, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (110, 20, 'Certificate Templete', 'certificate_templete', 1, 1, 1, 1, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (111, 20, 'Generate Student Certificate', 'generate_student_certificate', 1, 0, 0, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (112, 20, 'Generate Employee Certificate', 'generate_employee_certificate', 1, 0, 0, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (113, 21, 'ID Card Templete', 'id_card_templete', 1, 1, 1, 1, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (114, 21, 'Generate Student ID Card', 'generate_student_idcard', 1, 0, 0, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (115, 21, 'Generate Employee ID Card', 'generate_employee_idcard', 1, 0, 0, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (116, 21, 'Admit Card Templete', 'admit_card_templete', 1, 1, 1, 1, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (117, 21, 'Generate Admit card', 'generate_admit_card', 1, 0, 0, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (118, 22, 'Frontend Setting', 'frontend_setting', 1, 1, 0, 0, '2019-09-10 23:24:07');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (119, 22, 'Frontend Menu', 'frontend_menu', 1, 1, 1, 1, '2019-09-11 00:03:39');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (120, 22, 'Frontend Section', 'frontend_section', 1, 1, 0, 0, '2019-09-11 00:26:11');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (121, 22, 'Manage Page', 'manage_page', 1, 1, 1, 1, '2019-09-11 01:54:08');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (122, 22, 'Frontend Slider', 'frontend_slider', 1, 1, 1, 1, '2019-09-11 02:12:31');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (123, 22, 'Frontend Features', 'frontend_features', 1, 1, 1, 1, '2019-09-11 02:47:51');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (124, 22, 'Frontend Testimonial', 'frontend_testimonial', 1, 1, 1, 1, '2019-09-11 02:54:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (125, 22, 'Frontend Services', 'frontend_services', 1, 1, 1, 1, '2019-09-11 03:01:44');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (126, 22, 'Frontend Faq', 'frontend_faq', 1, 1, 1, 1, '2019-09-11 03:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (127, 2, 'Online Admission', 'online_admission', 1, 1, 0, 1, '2019-09-11 03:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (128, 18, 'System Update', 'system_update', 0, 1, 0, 0, '2019-09-11 03:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (129, 19, 'Live Class Reports', 'live_class_reports', 1, 0, 0, 0, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (130, 16, 'Fees Revert', 'fees_revert', 0, 0, 0, 1, '2020-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (131, 22, 'Frontend Gallery', 'frontend_gallery', 1, 1, 1, 1, '2019-09-11 03:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (132, 22, 'Frontend Gallery Category', 'frontend_gallery_category', 1, 1, 1, 1, '2019-09-11 03:06:16');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (133, 6, 'Teacher Timetable', 'teacher_timetable', 1, 0, 0, 0, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (134, 18, 'Whatsapp Config', 'whatsapp_config', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (135, 18, 'System Student Field', 'system_student_field', 1, 0, 1, 0, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (136, 23, 'Online Exam', 'online_exam', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (137, 23, 'Question Bank', 'question_bank', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (138, 23, 'Add Questions', 'add_questions', 0, 1, 0, 0, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (139, 23, 'Question Group', 'question_group', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (140, 23, 'Exam Result', 'exam_result', 1, 0, 0, 0, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (141, 23, 'Position Generate', 'position_generate', 1, 1, 0, 0, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (142, 24, 'Postal Record', 'postal_record', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (143, 24, 'Call Log', 'call_log', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (144, 24, 'Visitor Log', 'visitor_log', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (145, 24, 'Complaint', 'complaint', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (146, 24, 'Enquiry', 'enquiry', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (147, 24, 'Follow Up', 'follow_up', 1, 1, 0, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (148, 24, 'Config Reception', 'config_reception', 1, 1, 1, 1, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (149, 15, 'Student Birthday Wishes', 'student_birthday_wishes', 1, 0, 0, 0, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (150, 15, 'Staff Birthday Wishes', 'staff_birthday_wishes', 1, 0, 0, 0, '2021-03-31 05:46:30');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (151, 1, 'Student Birthday Wishes Widget', 'student_birthday_widget', 1, 0, 0, 0, '2021-03-31 03:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (152, 1, 'Staff Birthday Wishes Widget', 'staff_birthday_widget', 1, 0, 0, 0, '2021-03-31 03:22:05');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (153, 9, 'Progress Reports', 'progress_reports', 1, 0, 0, 0, '2021-03-21 03:12:38');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (154, 2, 'Disable Reason', 'disable_reason', 1, 1, 1, 1, '2021-03-21 03:12:38');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (155, 16, 'Offline Payments', 'offline_payments', 1, 0, 0, 0, '2023-03-23 03:12:38');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (156, 16, 'Offline Payments Type', 'offline_payments_type', 1, 1, 1, 1, '2023-03-23 03:12:38');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (157, 25, 'Product', 'product', 1, 1, 1, 1, '2023-06-13 15:21:42');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (158, 25, 'Product Category', 'product_category', 1, 1, 1, 1, '2023-06-13 15:21:42');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (159, 25, 'Product Supplier', 'product_supplier', 1, 1, 1, 1, '2023-06-13 15:21:42');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (160, 25, 'Product Unit', 'product_unit', 1, 1, 1, 1, '2023-06-13 15:21:42');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (161, 25, 'Product Purchase', 'product_purchase', 1, 1, 1, 1, '2023-06-13 15:21:42');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (162, 25, 'Purchase Payment', 'purchase_payment', 1, 0, 0, 0, '2023-06-13 15:21:42');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (163, 25, 'Product Store', 'product_store', 1, 1, 1, 1, '2023-06-13 15:21:42');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (164, 25, 'Product Sales', 'product_sales', 1, 1, 0, 1, '2023-06-13 15:21:42');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (165, 25, 'Sales Payment', 'sales_payment', 1, 0, 0, 0, '2023-06-21 03:05:10');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (166, 25, 'Product Issue', 'product_issue', 1, 1, 0, 1, '2023-06-13 15:21:42');
INSERT INTO `permission` (`id`, `module_id`, `name`, `prefix`, `show_view`, `show_add`, `show_edit`, `show_delete`, `created_at`) VALUES (167, 25, 'Inventory Report', 'inventory_report', 1, 0, 0, 0, '2023-06-26 23:56:45');


#
# TABLE STRUCTURE FOR: permission_modules
#

DROP TABLE IF EXISTS `permission_modules`;

CREATE TABLE `permission_modules` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `prefix` varchar(50) NOT NULL,
  `system` tinyint(1) NOT NULL,
  `sorted` tinyint(10) NOT NULL,
  `in_module` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (1, 'Dashboard', 'dashboard', 1, 1, 0, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (2, 'Student', 'student', 1, 4, 0, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (3, 'Parents', 'parents', 1, 5, 0, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (4, 'Employee', 'employee', 1, 6, 0, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (5, 'Human Resource', 'human_resource', 1, 9, 1, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (6, 'Academic', 'academic', 1, 10, 0, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (7, 'Homework', 'homework', 1, 13, 1, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (8, 'Attachments Book', 'attachments_book', 1, 12, 1, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (9, 'Exam Master', 'exam_master', 1, 14, 0, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (10, 'Hostel', 'hostel', 1, 16, 1, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (11, 'Transport', 'transport', 1, 17, 1, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (12, 'Attendance', 'attendance', 1, 18, 1, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (13, 'Library', 'library', 1, 19, 1, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (14, 'Events', 'events', 1, 20, 1, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (15, 'Bulk Sms And Email', 'bulk_sms_and_email', 1, 21, 1, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (16, 'Student Accounting', 'student_accounting', 1, 22, 1, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (17, 'Office Accounting', 'office_accounting', 1, 23, 1, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (18, 'Settings', 'settings', 1, 24, 0, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (19, 'Live Class', 'live_class', 1, 11, 1, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (20, 'Certificate', 'certificate', 1, 8, 1, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (21, 'Card Management', 'card_management', 1, 7, 1, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (22, 'Website', 'website', 1, 2, 1, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (23, 'Online Exam', 'online_exam', 1, 15, 1, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (24, 'Reception', 'reception', 1, 3, 1, '2019-05-26 18:23:00');
INSERT INTO `permission_modules` (`id`, `name`, `prefix`, `system`, `sorted`, `in_module`, `created_at`) VALUES (25, 'Inventory', 'inventory', 1, 3, 1, '2023-06-13 15:16:49');


#
# TABLE STRUCTURE FOR: postal_record
#

DROP TABLE IF EXISTS `postal_record`;

CREATE TABLE `postal_record` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sender_title` varchar(255) DEFAULT NULL,
  `receiver_title` varchar(255) DEFAULT NULL,
  `reference_no` varchar(255) DEFAULT NULL,
  `address` text NOT NULL,
  `date` date NOT NULL,
  `note` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `file` varchar(250) NOT NULL,
  `confidential` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(11) NOT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 1,
  `branch_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: product
#

DROP TABLE IF EXISTS `product`;

CREATE TABLE `product` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `code` varchar(50) NOT NULL,
  `category_id` int(11) NOT NULL,
  `purchase_unit_id` int(11) NOT NULL,
  `sales_unit_id` int(11) NOT NULL,
  `unit_ratio` varchar(20) DEFAULT '1',
  `purchase_price` decimal(18,2) NOT NULL DEFAULT 0.00,
  `sales_price` decimal(18,2) NOT NULL DEFAULT 0.00,
  `available_stock` varchar(11) NOT NULL DEFAULT '0',
  `photo` varchar(100) DEFAULT NULL,
  `remarks` text NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: product_category
#

DROP TABLE IF EXISTS `product_category`;

CREATE TABLE `product_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: product_issues
#

DROP TABLE IF EXISTS `product_issues`;

CREATE TABLE `product_issues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date_of_issue` date NOT NULL,
  `due_date` date NOT NULL,
  `return_date` date DEFAULT NULL,
  `remarks` text NOT NULL,
  `prepared_by` int(11) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: product_issues_details
#

DROP TABLE IF EXISTS `product_issues_details`;

CREATE TABLE `product_issues_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `issues_id` int(11) NOT NULL,
  `product_id` varchar(20) NOT NULL,
  `quantity` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: product_store
#

DROP TABLE IF EXISTS `product_store`;

CREATE TABLE `product_store` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) NOT NULL,
  `mobileno` varchar(255) DEFAULT NULL,
  `address` varchar(300) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: product_supplier
#

DROP TABLE IF EXISTS `product_supplier`;

CREATE TABLE `product_supplier` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(200) NOT NULL,
  `address` text NOT NULL,
  `mobileno` varchar(30) NOT NULL,
  `email` varchar(100) NOT NULL,
  `company_name` varchar(200) NOT NULL,
  `product_list` mediumtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: product_unit
#

DROP TABLE IF EXISTS `product_unit`;

CREATE TABLE `product_unit` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: promotion_history
#

DROP TABLE IF EXISTS `promotion_history`;

CREATE TABLE `promotion_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `pre_class` int(11) NOT NULL,
  `pre_section` int(11) NOT NULL,
  `pre_session` int(11) NOT NULL,
  `pro_class` int(11) NOT NULL,
  `pro_section` int(11) NOT NULL,
  `pro_session` int(11) NOT NULL,
  `prev_due` float NOT NULL DEFAULT 0,
  `date` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: purchase_bill
#

DROP TABLE IF EXISTS `purchase_bill`;

CREATE TABLE `purchase_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_no` varchar(200) NOT NULL,
  `supplier_id` int(11) NOT NULL,
  `store_id` int(11) NOT NULL,
  `remarks` text NOT NULL,
  `total` decimal(18,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `paid` decimal(18,2) NOT NULL DEFAULT 0.00,
  `due` decimal(18,2) NOT NULL DEFAULT 0.00,
  `payment_status` int(11) NOT NULL,
  `purchase_status` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `prepared_by` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: purchase_bill_details
#

DROP TABLE IF EXISTS `purchase_bill_details`;

CREATE TABLE `purchase_bill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_bill_id` int(11) NOT NULL,
  `product_id` varchar(20) NOT NULL,
  `unit_price` decimal(18,2) NOT NULL DEFAULT 0.00,
  `quantity` varchar(20) NOT NULL,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `sub_total` decimal(18,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: purchase_payment_history
#

DROP TABLE IF EXISTS `purchase_payment_history`;

CREATE TABLE `purchase_payment_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `purchase_bill_id` varchar(11) NOT NULL,
  `payment_by` int(11) DEFAULT NULL,
  `amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `pay_via` varchar(25) NOT NULL,
  `remarks` text NOT NULL,
  `attach_orig_name` varchar(255) DEFAULT NULL,
  `attach_file_name` varchar(255) DEFAULT NULL,
  `paid_on` date DEFAULT NULL,
  `coll_type` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: question_group
#

DROP TABLE IF EXISTS `question_group`;

CREATE TABLE `question_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: questions
#

DROP TABLE IF EXISTS `questions`;

CREATE TABLE `questions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `type` tinyint(1) NOT NULL,
  `level` tinyint(1) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) DEFAULT 0,
  `subject_id` int(11) NOT NULL DEFAULT 0,
  `group_id` int(11) NOT NULL,
  `question` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `opt_1` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `opt_2` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `opt_3` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `opt_4` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `answer` text CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `mark` float(10,2) NOT NULL DEFAULT 0.00,
  `branch_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: questions_manage
#

DROP TABLE IF EXISTS `questions_manage`;

CREATE TABLE `questions_manage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question_id` int(11) DEFAULT NULL,
  `onlineexam_id` int(11) DEFAULT NULL,
  `marks` float(10,2) NOT NULL DEFAULT 0.00,
  `neg_marks` float(10,2) DEFAULT 0.00,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `updated_at` date DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `onlineexam_id` (`onlineexam_id`),
  KEY `question_id` (`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: reset_password
#

DROP TABLE IF EXISTS `reset_password`;

CREATE TABLE `reset_password` (
  `key` longtext NOT NULL,
  `username` varchar(100) NOT NULL,
  `login_credential_id` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `reset_password` (`key`, `username`, `login_credential_id`, `created_at`) VALUES ('5ee561a7080434cd86e275246e0d30a45a39fcb1e52bcfdf19bc9af53adf114668dd5810130ce3efde5aea4028be4bfd22145b8e51fa45e377b8456be1c52d97', 'info@elitedesign.com.bd', '1', '2023-09-25 13:53:29');


#
# TABLE STRUCTURE FOR: rm_sessions
#

DROP TABLE IF EXISTS `rm_sessions`;

CREATE TABLE `rm_sessions` (
  `id` varchar(40) NOT NULL,
  `ip_address` varchar(45) NOT NULL,
  `timestamp` int(10) unsigned NOT NULL DEFAULT 0,
  `data` blob NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ci_sessions_timestamp` (`timestamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('0a9b86h350kottsp2odm949g3b0e3anj', '::1', 1695666988, '__ci_last_regenerate|i:1695666988;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('10u8vuct04efgngvge17tjqq7t477b8i', '188.166.95.90', 1695875463, '__ci_last_regenerate|i:1695875463;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1392oju7tk6iiihu2b6r3iucbtl0s8ci', '42.0.7.237', 1696164075, '__ci_last_regenerate|i:1696164075;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1buqbf8dgfmr95esa3ejeabm34dr3cvr', '103.131.145.159', 1696159701, '__ci_last_regenerate|i:1696159670;alert-message-error|s:33:\"Username Or Password Is Incorrect\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('1srb0n13atpjmhv79v6kq5vatoqo733u', '103.107.79.147', 1695730029, '__ci_last_regenerate|i:1695730029;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2fd62kg4vqavtovclm2rvdulasubc1oe', '69.4.87.74', 1695713630, '__ci_last_regenerate|i:1695713630;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('2m9tb9mikm1qvjgg2u9khi287linbomh', '::1', 1695669122, '__ci_last_regenerate|i:1695669122;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('30infddcsivgjphdt30us2tf8s1lubml', '144.48.84.43', 1696164535, '__ci_last_regenerate|i:1696164456;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('46uqpnc78g8uq34osiir1so5pdd6cs8m', '::1', 1695672066, '__ci_last_regenerate|i:1695672066;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;params|a:17:{s:10:\"student_id\";s:1:\"1\";s:9:\"branch_id\";s:1:\"1\";s:14:\"student_mobile\";s:11:\"01775457008\";s:13:\"student_email\";s:23:\"shadhinhostbd@gmail.com\";s:10:\"class_name\";s:7:\"Class 1\";s:12:\"section_name\";N;s:12:\"student_name\";s:8:\"Md Abdul\";s:6:\"amount\";s:3:\"300\";s:8:\"currency\";s:3:\"BDT\";s:4:\"name\";s:17:\"Md mamunur Rashid\";s:5:\"email\";s:29:\"info.elitedesignsbd@gmail.com\";s:9:\"mobile_no\";s:11:\"01775457008\";s:9:\"post_code\";s:4:\"1216\";s:5:\"state\";s:2:\"kf\";s:7:\"address\";s:8:\"35/3/1-B\";s:14:\"payment_method\";s:10:\"sslcommerz\";s:7:\"tran_id\";s:17:\"SSLC6511e120c29cf\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('48frneuhf94eihnea6un2ptgjj9jsa6s', '159.203.3.151', 1695759064, '__ci_last_regenerate|i:1695759064;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('48mnufi8mdquhjbpev1nm7402b8vrta9', '::1', 1695666374, '__ci_last_regenerate|i:1695666374;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4bq3ebna9gbsdov426sohjk0p1sf2lli', '103.4.66.13', 1695797750, '__ci_last_regenerate|i:1695797745;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4oaucsoj5u3j1ag167ks8bptibe66012', '171.244.43.14', 1695729470, '__ci_last_regenerate|i:1695729470;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('4vf8b7vk6n6gaesnpvta47tlht6o3318', '103.131.145.159', 1696009312, '__ci_last_regenerate|i:1696009308;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('586gpm0a1mb0olgeuf7omglilv33jgmc', '103.161.70.71', 1696177860, '__ci_last_regenerate|i:1696177707;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6guhphl1ts32133j4h9um2tahgr3kq0d', '::1', 1695668797, '__ci_last_regenerate|i:1695668797;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6j1k294el6omtt5ga0nmcg3otj33u60p', '::1', 1695674271, '__ci_last_regenerate|i:1695674271;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6mvgvdj2i5sqq4176mc2fc9lrsqcu59l', '103.131.145.159', 1696159670, '__ci_last_regenerate|i:1696159670;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6qon6v7nuc27htg65h1f4i3k80bv5vof', '69.171.249.12', 1695708188, '__ci_last_regenerate|i:1695708188;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6rt8f8780r5r064etmjm40m6lanljo0c', '205.169.39.148', 1695733095, '__ci_last_regenerate|i:1695733094;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6utdmkkvj80198ia52ns911vqr00okqk', '::1', 1695669429, '__ci_last_regenerate|i:1695669429;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('6uvrkm85vn54jh38mm4g4d9fol9gliul', '::1', 1695666066, '__ci_last_regenerate|i:1695666066;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('82kudj7j60esv1ree5gh5i8dgj0u9hfb', '159.203.3.151', 1695759065, '__ci_last_regenerate|i:1695759065;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8h8aab0h7stidnlgs67tvach7ctfeaoe', '176.53.219.252', 1695840502, '__ci_last_regenerate|i:1695840502;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8jhkbv8o9q136somtkagei7l0gpvo47t', '::1', 1695665349, '__ci_last_regenerate|i:1695665349;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;test-email-error|s:256:\"Mailer Error: SMTP connect() failed. https://github.com/PHPMailer/PHPMailer/wiki/TroubleshootingSMTP server error: Failed to connect to server SMTP code: 10061 Additional SMTP info: No connection could be made because the target machine actively refused it\";__ci_vars|a:1:{s:16:\"test-email-error\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8kh9ql4fkc12g2uabsfnib0vupkna311', '::1', 1695667655, '__ci_last_regenerate|i:1695667655;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('8r2gl86lqtqrnjmtfps7dn2314aii2an', '69.171.249.12', 1695708177, '__ci_last_regenerate|i:1695708177;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('93stl2jv7a1ng50gkhussmlpd6brjupu', '::1', 1695664673, '__ci_last_regenerate|i:1695664673;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('98fugl60itcpueik9rrrciri48lscidb', '::1', 1695674672, '__ci_last_regenerate|i:1695674616;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;params|a:17:{s:10:\"student_id\";s:1:\"1\";s:9:\"branch_id\";s:1:\"1\";s:14:\"student_mobile\";s:11:\"01775457008\";s:13:\"student_email\";s:23:\"shadhinhostbd@gmail.com\";s:10:\"class_name\";s:7:\"Class 1\";s:12:\"section_name\";N;s:12:\"student_name\";s:8:\"Md Abdul\";s:6:\"amount\";s:3:\"300\";s:8:\"currency\";s:3:\"BDT\";s:4:\"name\";s:17:\"Md mamunur Rashid\";s:5:\"email\";s:29:\"info.elitedesignsbd@gmail.com\";s:9:\"mobile_no\";s:11:\"01775457008\";s:9:\"post_code\";s:4:\"1216\";s:5:\"state\";s:2:\"kf\";s:7:\"address\";s:8:\"35/3/1-B\";s:14:\"payment_method\";s:10:\"sslcommerz\";s:7:\"tran_id\";s:17:\"SSLC6511e120c29cf\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9j74sndm54qacghbdui7m2mtj0d7ungp', '103.138.251.155', 1695731762, '__ci_last_regenerate|i:1695731717;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('9k0la2s3cu723er9pu1qvohhqe6bk95b', '103.173.173.5', 1696159589, '__ci_last_regenerate|i:1696159589;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a0ilerrb3qs9jnib9ne203c9ggns5u3g', '103.107.79.147', 1695725598, '__ci_last_regenerate|i:1695725598;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a6uve7ir7v98fhb0hjh3h3436pvqlc5d', '103.161.70.71', 1696177707, '__ci_last_regenerate|i:1696177707;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('a7r7ccdm4gvfgim4rt30gp2vv2adjtl9', '34.254.53.125', 1695708747, '__ci_last_regenerate|i:1695708746;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('aev1fsi51jfovv4rht7hdhpfa6nvgsm8', '144.48.84.43', 1696164456, '__ci_last_regenerate|i:1696164456;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b203691rivq5vceujgvc5at86juvlibd', '69.171.249.6', 1695708177, '__ci_last_regenerate|i:1695708177;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b25b9323m2t2shnqr1oicbboigm62b8c', '176.53.223.10', 1695759776, '__ci_last_regenerate|i:1695759776;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('b2ljgttkg466ir70ofhv3s0rm2p78m97', '103.173.173.5', 1696159620, '__ci_last_regenerate|i:1696159589;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('cku60cdt19fhj9ffpo20ccsp3amgsp4m', '103.107.79.147', 1695728564, '__ci_last_regenerate|i:1695728564;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('covbpd30h4ucmq5vtti7nb1adj1kp3lj', '207.154.236.54', 1696065047, '__ci_last_regenerate|i:1696065047;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ds3iramtghv2jsbjnes7sgn1rbsec69s', '::1', 1695668071, '__ci_last_regenerate|i:1695668071;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;alert-message-success|s:39:\"Information Has Been Saved Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('duvlv7fd1223fbv0gh4ffcbh0joiti15', '::1', 1695665018, '__ci_last_regenerate|i:1695665018;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('e64tc10jmfcdv6pcb6osvokg8rivshvu', '42.0.4.251', 1695708273, '__ci_last_regenerate|i:1695708269;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ebsk5aa85rq8ord0uis5vi9t7gms7qli', '::1', 1695666686, '__ci_last_regenerate|i:1695666686;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;alert-message-success|s:34:\"The Configuration Has Been Updated\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('eicbdpuru0n7pd1ugvuqifk7la63af0p', '103.131.145.159', 1695715746, '__ci_last_regenerate|i:1695715700;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('euktf6j3gls8ttphgtthdri17fuh7l8i', '::1', 1695670779, '__ci_last_regenerate|i:1695670779;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;params|a:17:{s:10:\"student_id\";s:1:\"1\";s:9:\"branch_id\";s:1:\"1\";s:14:\"student_mobile\";s:11:\"01775457008\";s:13:\"student_email\";s:23:\"shadhinhostbd@gmail.com\";s:10:\"class_name\";s:7:\"Class 1\";s:12:\"section_name\";N;s:12:\"student_name\";s:8:\"Md Abdul\";s:6:\"amount\";s:3:\"300\";s:8:\"currency\";s:3:\"BDT\";s:4:\"name\";s:17:\"Md mamunur Rashid\";s:5:\"email\";s:29:\"info.elitedesignsbd@gmail.com\";s:9:\"mobile_no\";s:11:\"01775457008\";s:9:\"post_code\";s:4:\"1216\";s:5:\"state\";s:2:\"kf\";s:7:\"address\";s:8:\"35/3/1-B\";s:14:\"payment_method\";s:10:\"sslcommerz\";s:7:\"tran_id\";s:17:\"SSLC6511e120c29cf\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ffpkfrkm7hqgnteebd0a21rbadt05nhl', '::1', 1695670101, '__ci_last_regenerate|i:1695670101;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;alert-message-success|s:41:\"Information Has Been Updated Successfully\";__ci_vars|a:1:{s:21:\"alert-message-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('g402l2187nnettcu7j00nrdrju61i3s7', '::1', 1695670435, '__ci_last_regenerate|i:1695670435;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gb7hgbdqoevhf69bgaos9ut01c9itdbk', '133.242.174.119', 1695718612, '__ci_last_regenerate|i:1695718611;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gj88aactbftqgqp55v2mosfhg9d58v36', '34.254.53.125', 1695708745, '__ci_last_regenerate|i:1695708745;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('gtrg2efpsm1hj9urp2u4u9ibb74uh1ib', '173.252.107.5', 1696159511, '__ci_last_regenerate|i:1696159511;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('guar12f48hjelbek9c4tusjbms83fgbe', '::1', 1695667346, '__ci_last_regenerate|i:1695667346;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('h9c27irvfuhm9qmvua68p071gaecpfn5', '34.254.53.125', 1695708726, '__ci_last_regenerate|i:1695708726;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ibb6kodfppv7sfc2l4rtt1187gpn6mjd', '183.129.153.157', 1695941173, '__ci_last_regenerate|i:1695941173;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('iphuvhpt0v9jbff6elfjhedbis58hbcp', '103.161.70.71', 1696176726, '__ci_last_regenerate|i:1696176726;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j0ct6j41ik28t9rbadtvh359l5a34p00', '103.106.237.138', 1695795659, '__ci_last_regenerate|i:1695795659;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j5o8umf2jnnuqka80slr3doc4ujdjdae', '173.252.107.118', 1695797712, '__ci_last_regenerate|i:1695797712;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j7fu396khp60nqkdape7mvo7t1p0uiov', '103.161.70.71', 1696177072, '__ci_last_regenerate|i:1696177072;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('j8ogu3iin46s63kvib2an270of2h0b0q', '103.161.70.71', 1696177404, '__ci_last_regenerate|i:1696177403;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jf15s2va5v0bk3lvb06ihcl2dleuvgk5', '89.104.111.124', 1695754240, '__ci_last_regenerate|i:1695754240;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('jvh8ocbefaagvn0j5cchkgp4749lel9u', '103.107.79.147', 1695731755, '__ci_last_regenerate|i:1695731755;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kaeen3ls6tsp7m3q2gp7hhbe4t2pvr0c', '::1', 1695669794, '__ci_last_regenerate|i:1695669794;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('kkdbk0rjgr6nb3e2bqka60h5t2uo3ovd', '103.131.145.159', 1696059267, '__ci_last_regenerate|i:1696059253;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lb791h7d3se71il2f3vjpha2u05ihbns', '::1', 1695671765, '__ci_last_regenerate|i:1695671765;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;params|a:17:{s:10:\"student_id\";s:1:\"1\";s:9:\"branch_id\";s:1:\"1\";s:14:\"student_mobile\";s:11:\"01775457008\";s:13:\"student_email\";s:23:\"shadhinhostbd@gmail.com\";s:10:\"class_name\";s:7:\"Class 1\";s:12:\"section_name\";N;s:12:\"student_name\";s:8:\"Md Abdul\";s:6:\"amount\";s:3:\"300\";s:8:\"currency\";s:3:\"BDT\";s:4:\"name\";s:17:\"Md mamunur Rashid\";s:5:\"email\";s:29:\"info.elitedesignsbd@gmail.com\";s:9:\"mobile_no\";s:11:\"01775457008\";s:9:\"post_code\";s:4:\"1216\";s:5:\"state\";s:2:\"kf\";s:7:\"address\";s:8:\"35/3/1-B\";s:14:\"payment_method\";s:10:\"sslcommerz\";s:7:\"tran_id\";s:17:\"SSLC6511e120c29cf\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lbse2c9hpk5cmmu66t4ov8s12b0rci2n', '::1', 1695671436, '__ci_last_regenerate|i:1695671436;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;params|a:17:{s:10:\"student_id\";s:1:\"1\";s:9:\"branch_id\";s:1:\"1\";s:14:\"student_mobile\";s:11:\"01775457008\";s:13:\"student_email\";s:23:\"shadhinhostbd@gmail.com\";s:10:\"class_name\";s:7:\"Class 1\";s:12:\"section_name\";N;s:12:\"student_name\";s:8:\"Md Abdul\";s:6:\"amount\";s:3:\"300\";s:8:\"currency\";s:3:\"BDT\";s:4:\"name\";s:17:\"Md mamunur Rashid\";s:5:\"email\";s:29:\"info.elitedesignsbd@gmail.com\";s:9:\"mobile_no\";s:11:\"01775457008\";s:9:\"post_code\";s:4:\"1216\";s:5:\"state\";s:2:\"kf\";s:7:\"address\";s:8:\"35/3/1-B\";s:14:\"payment_method\";s:10:\"sslcommerz\";s:7:\"tran_id\";s:17:\"SSLC6511e120c29cf\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('lhtl2u22m25noh2akrrdhp5rkbus44tc', '34.254.53.125', 1695708731, '__ci_last_regenerate|i:1695708731;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ltdkk9dgermp755lbprnvbqthfdvrq8v', '188.166.95.90', 1695875464, '__ci_last_regenerate|i:1695875464;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('m06jougsg8i19pqnni7ua5db8bi4nop9', '205.169.39.148', 1695733082, '__ci_last_regenerate|i:1695733081;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mg8fu87ajv8k3r2eeqd6f33b8g94kkra', '103.106.237.138', 1695795655, '__ci_last_regenerate|i:1695795655;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('modo52g2o6brskcor4rvi4ifet5gk52i', '::1', 1695668435, '__ci_last_regenerate|i:1695668435;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mpdeh03c9bbapa2n0d59a573mktlq53f', '103.131.145.159', 1695714924, '__ci_last_regenerate|i:1695714924;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('mu6vkv1u56d1d3j81g61nui42p3csg0g', '103.107.79.147', 1695729566, '__ci_last_regenerate|i:1695729566;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('ni662lsfab0kefavu2p6i8mno760ssrc', '::1', 1695665979, '__ci_last_regenerate|i:1695665979;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;test-email-success|i:1;__ci_vars|a:1:{s:18:\"test-email-success\";s:3:\"old\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('nm9ol6tdt09pasmirsbalbgt0lhgikgu', '103.107.79.147', 1695726178, '__ci_last_regenerate|i:1695726178;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o1dveoetgi331k9jb46md8pm9l857mha', '103.15.244.132', 1696110351, '__ci_last_regenerate|i:1696110351;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o55jiq53u11hgf37avoueievpfrksak0', '34.254.53.125', 1695708755, '__ci_last_regenerate|i:1695708755;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o69bjk4ovv63dhk1vpr78skg371ha7m3', '103.107.79.147', 1695731449, '__ci_last_regenerate|i:1695731449;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o89005j0brf83rou4f8qg8fofh2csi6g', '34.254.53.125', 1695708728, '__ci_last_regenerate|i:1695708727;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o8cauognqo1susa5djvrulnghvcjohn2', '103.100.235.73', 1696157568, '__ci_last_regenerate|i:1696157554;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('o91l7vlrsqv025ut24f3kj9ba2ct5n4u', '69.4.87.74', 1695713630, '__ci_last_regenerate|i:1695713630;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('of7u8lfvnov5vuev3ee0terdhe4kjjkn', '207.154.236.54', 1696065046, '__ci_last_regenerate|i:1696065046;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('omappahi9t6jnd9tgvusuqndt8jn8fes', '103.161.70.71', 1696176335, '__ci_last_regenerate|i:1696176335;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('oms3c2tu9o4vnu5p8demukjv5ke3gklp', '93.119.227.91', 1695710626, '__ci_last_regenerate|i:1695710626;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('q2er44afd9o9fjj5aig9djvkt221u8cp', '103.187.68.240', 1696059779, '__ci_last_regenerate|i:1696059576;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('qnfnv19eqj21qgm62s7su7cpip546149', '103.107.79.147', 1695731805, '__ci_last_regenerate|i:1695731755;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rarvr1m7a7jvmfsb74g1amohlm8f6aa3', '103.106.237.138', 1695795796, '__ci_last_regenerate|i:1695795525;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('riksrvq5pp47a58h87d4fndv7ipjj4hi', '93.119.227.91', 1695710626, '__ci_last_regenerate|i:1695710626;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('rl5urpnu22a5uqp46jo2frbdo24dot0e', '183.129.153.157', 1695928237, '__ci_last_regenerate|i:1695928237;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s0o4rd8ebal2drfk0ahf0hj4a0nvgf7j', '69.171.249.117', 1695708188, '__ci_last_regenerate|i:1695708188;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s2pgpi225ac7g25khadp2180loc245a1', '::1', 1695674616, '__ci_last_regenerate|i:1695674616;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;params|a:17:{s:10:\"student_id\";s:1:\"1\";s:9:\"branch_id\";s:1:\"1\";s:14:\"student_mobile\";s:11:\"01775457008\";s:13:\"student_email\";s:23:\"shadhinhostbd@gmail.com\";s:10:\"class_name\";s:7:\"Class 1\";s:12:\"section_name\";N;s:12:\"student_name\";s:8:\"Md Abdul\";s:6:\"amount\";s:3:\"300\";s:8:\"currency\";s:3:\"BDT\";s:4:\"name\";s:17:\"Md mamunur Rashid\";s:5:\"email\";s:29:\"info.elitedesignsbd@gmail.com\";s:9:\"mobile_no\";s:11:\"01775457008\";s:9:\"post_code\";s:4:\"1216\";s:5:\"state\";s:2:\"kf\";s:7:\"address\";s:8:\"35/3/1-B\";s:14:\"payment_method\";s:10:\"sslcommerz\";s:7:\"tran_id\";s:17:\"SSLC6511e120c29cf\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s441311a3kq3bm3157b29f9fjae67fsu', '::1', 1695665650, '__ci_last_regenerate|i:1695665650;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;test-email-success|i:1;__ci_vars|a:1:{s:18:\"test-email-success\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('s6bdfnvvb424lrsrp55ltepl8u9j5et9', '103.106.237.138', 1695795659, '__ci_last_regenerate|i:1695795659;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('sp9ov928u7s1loj12t1gt3dh28asijmc', '::1', 1695671116, '__ci_last_regenerate|i:1695671116;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;params|a:17:{s:10:\"student_id\";s:1:\"1\";s:9:\"branch_id\";s:1:\"1\";s:14:\"student_mobile\";s:11:\"01775457008\";s:13:\"student_email\";s:23:\"shadhinhostbd@gmail.com\";s:10:\"class_name\";s:7:\"Class 1\";s:12:\"section_name\";N;s:12:\"student_name\";s:8:\"Md Abdul\";s:6:\"amount\";s:3:\"300\";s:8:\"currency\";s:3:\"BDT\";s:4:\"name\";s:17:\"Md mamunur Rashid\";s:5:\"email\";s:29:\"info.elitedesignsbd@gmail.com\";s:9:\"mobile_no\";s:11:\"01775457008\";s:9:\"post_code\";s:4:\"1216\";s:5:\"state\";s:2:\"kf\";s:7:\"address\";s:8:\"35/3/1-B\";s:14:\"payment_method\";s:10:\"sslcommerz\";s:7:\"tran_id\";s:17:\"SSLC6511e120c29cf\";}alert-message-error|s:31:\"This application was not found.\";__ci_vars|a:1:{s:19:\"alert-message-error\";s:3:\"new\";}');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('tsdgbbk6idl25m1isqqogk33jsqu9e08', '::1', 1695674272, '__ci_last_regenerate|i:1695674271;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u1amgt5c7eiflkv218amtve4idn6pk29', '::1', 1695671941, '__ci_last_regenerate|i:1695671790;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('u9fv89bjqv8rgdunrre9p58mis55g7b8', '103.131.145.159', 1695715700, '__ci_last_regenerate|i:1695715700;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('umipk52hpb50nn2m2b5u0vg2l5bl2f4p', '103.107.79.147', 1695728873, '__ci_last_regenerate|i:1695728873;name|s:63:\"রুপনগর আবাসিক হাই স্কুল\";logger_photo|s:36:\"f7937d8aef6142144481a53e6b256300.png\";loggedin_branch|N;loggedin_id|s:1:\"1\";loggedin_userid|s:1:\"1\";loggedin_role_id|s:1:\"1\";loggedin_type|s:5:\"staff\";set_lang|s:7:\"english\";set_session_id|s:1:\"6\";loggedin|b:1;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('unqil9s0g00ln15hva1kskvnrtvcipq6', '103.140.62.77', 1695982893, '__ci_last_regenerate|i:1695982807;');
INSERT INTO `rm_sessions` (`id`, `ip_address`, `timestamp`, `data`) VALUES ('v7j3ht57erack8lr4chs0fg0v2mfkgbs', '176.53.220.224', 1695845822, '__ci_last_regenerate|i:1695845822;');


#
# TABLE STRUCTURE FOR: roles
#

DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `prefix` varchar(50) DEFAULT NULL,
  `is_system` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (1, 'Super Admin', 'superadmin', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (2, 'Admin', 'admin', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (3, 'Teacher', 'teacher', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (4, 'Accountant', 'accountant', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (5, 'Librarian', 'librarian', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (6, 'Parent', 'parent', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (7, 'Student', 'student', '1');
INSERT INTO `roles` (`id`, `name`, `prefix`, `is_system`) VALUES (8, 'Receptionist', 'receptionist', '1');


#
# TABLE STRUCTURE FOR: salary_template
#

DROP TABLE IF EXISTS `salary_template`;

CREATE TABLE `salary_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `basic_salary` decimal(18,2) NOT NULL,
  `overtime_salary` varchar(100) NOT NULL DEFAULT '0',
  `branch_id` tinyint(3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: salary_template_details
#

DROP TABLE IF EXISTS `salary_template_details`;

CREATE TABLE `salary_template_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `salary_template_id` varchar(20) NOT NULL,
  `name` varchar(200) NOT NULL,
  `amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `type` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: sales_bill
#

DROP TABLE IF EXISTS `sales_bill`;

CREATE TABLE `sales_bill` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bill_no` varchar(200) NOT NULL,
  `role_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `remarks` text NOT NULL,
  `total` decimal(18,2) NOT NULL DEFAULT 0.00,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `paid` decimal(18,2) NOT NULL DEFAULT 0.00,
  `due` decimal(18,2) NOT NULL DEFAULT 0.00,
  `payment_status` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `prepared_by` int(11) DEFAULT NULL,
  `modifier_id` int(11) DEFAULT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: sales_bill_details
#

DROP TABLE IF EXISTS `sales_bill_details`;

CREATE TABLE `sales_bill_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sales_bill_id` int(11) NOT NULL,
  `product_id` varchar(20) NOT NULL,
  `unit_price` decimal(18,2) NOT NULL DEFAULT 0.00,
  `quantity` varchar(20) NOT NULL,
  `discount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `sub_total` decimal(18,2) NOT NULL DEFAULT 0.00,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: sales_payment_history
#

DROP TABLE IF EXISTS `sales_payment_history`;

CREATE TABLE `sales_payment_history` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sales_bill_id` varchar(11) NOT NULL,
  `payment_by` int(11) DEFAULT NULL,
  `amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `pay_via` varchar(25) NOT NULL,
  `remarks` text NOT NULL,
  `attach_orig_name` varchar(255) DEFAULT NULL,
  `attach_file_name` varchar(255) DEFAULT NULL,
  `paid_on` date DEFAULT NULL,
  `coll_type` tinyint(4) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: schoolyear
#

DROP TABLE IF EXISTS `schoolyear`;

CREATE TABLE `schoolyear` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `school_year` varchar(255) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (1, '2019-2020', 1, '2020-02-25 14:35:41', '2020-02-26 16:54:49');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (3, '2020-2021', 1, '2020-02-25 14:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (4, '2021-2022', 1, '2020-02-25 14:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (5, '2022-2023', 1, '2020-02-25 14:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (6, '2023-2024', 1, '2020-02-25 14:35:41', '2020-02-26 01:35:41');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (7, '2024-2025', 1, '2020-02-25 14:35:41', '2020-02-26 01:20:04');
INSERT INTO `schoolyear` (`id`, `school_year`, `created_by`, `created_at`, `updated_at`) VALUES (9, '2025-2026', 1, '2020-02-26 02:00:10', '2020-02-26 13:00:24');


#
# TABLE STRUCTURE FOR: section
#

DROP TABLE IF EXISTS `section`;

CREATE TABLE `section` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `capacity` varchar(20) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (1, 'A', '30', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (2, 'B', '30', 1);
INSERT INTO `section` (`id`, `name`, `capacity`, `branch_id`) VALUES (3, 'C', '30', 1);


#
# TABLE STRUCTURE FOR: sections_allocation
#

DROP TABLE IF EXISTS `sections_allocation`;

CREATE TABLE `sections_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (1, 1, 1);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (2, 2, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (3, 3, 3);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (4, 4, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (5, 5, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (7, 1, 2);
INSERT INTO `sections_allocation` (`id`, `class_id`, `section_id`) VALUES (8, 1, 3);


#
# TABLE STRUCTURE FOR: sms_api
#

DROP TABLE IF EXISTS `sms_api`;

CREATE TABLE `sms_api` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `sms_api` (`id`, `name`) VALUES (1, 'twilio');
INSERT INTO `sms_api` (`id`, `name`) VALUES (2, 'clickatell');
INSERT INTO `sms_api` (`id`, `name`) VALUES (3, 'msg91');
INSERT INTO `sms_api` (`id`, `name`) VALUES (4, 'bulksms');
INSERT INTO `sms_api` (`id`, `name`) VALUES (5, 'textlocal');
INSERT INTO `sms_api` (`id`, `name`) VALUES (6, 'smscountry');
INSERT INTO `sms_api` (`id`, `name`) VALUES (7, 'bulksmsbd');
INSERT INTO `sms_api` (`id`, `name`) VALUES (8, 'customsms');


#
# TABLE STRUCTURE FOR: sms_credential
#

DROP TABLE IF EXISTS `sms_credential`;

CREATE TABLE `sms_credential` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `sms_api_id` int(11) NOT NULL,
  `field_one` varchar(300) NOT NULL,
  `field_two` varchar(300) NOT NULL,
  `field_three` varchar(300) NOT NULL,
  `field_four` varchar(300) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: sms_template
#

DROP TABLE IF EXISTS `sms_template`;

CREATE TABLE `sms_template` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `tags` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (1, 'admission', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (2, 'fee_collection', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {paid_amount}, {paid_date} ');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (3, 'attendance', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (4, 'exam_attendance', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {exam_name}, {term_name}, {subject}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (5, 'exam_results', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {exam_name}, {term_name}, {subject}, {marks}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (6, 'homework', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {subject}, {date_of_homework}, {date_of_submission}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (7, 'live_class', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {date_of_live_class}, {start_time}, {end_time}, {host_by}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (8, 'online_exam_publish', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {exam_title}, {start_time}, {end_time}, {time_duration}, {attempt}, {passing_mark}, {exam_fee}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (9, 'student_birthday_wishes', '{name}, {class}, {section}, {admission_date}, {roll}, {register_no}, {birthday}');
INSERT INTO `sms_template` (`id`, `name`, `tags`) VALUES (10, 'staff_birthday_wishes', '{name}, {birthday}, {joining_date}');


#
# TABLE STRUCTURE FOR: sms_template_details
#

DROP TABLE IF EXISTS `sms_template_details`;

CREATE TABLE `sms_template_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `template_id` int(11) NOT NULL,
  `dlt_template_id` varchar(255) DEFAULT NULL,
  `notify_student` tinyint(3) NOT NULL DEFAULT 1,
  `notify_parent` tinyint(3) NOT NULL DEFAULT 1,
  `template_body` longtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: staff
#

DROP TABLE IF EXISTS `staff`;

CREATE TABLE `staff` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` varchar(25) NOT NULL,
  `name` varchar(255) NOT NULL,
  `department` int(11) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `experience_details` varchar(255) DEFAULT NULL,
  `total_experience` varchar(255) DEFAULT NULL,
  `designation` int(11) NOT NULL,
  `joining_date` varchar(100) NOT NULL,
  `birthday` varchar(100) NOT NULL,
  `sex` varchar(20) NOT NULL,
  `religion` varchar(100) NOT NULL,
  `blood_group` varchar(20) NOT NULL,
  `present_address` text NOT NULL,
  `permanent_address` text NOT NULL,
  `mobileno` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `salary_template_id` int(11) DEFAULT 0,
  `branch_id` int(11) DEFAULT NULL,
  `photo` varchar(255) DEFAULT NULL,
  `facebook_url` varchar(255) DEFAULT NULL,
  `linkedin_url` varchar(255) DEFAULT NULL,
  `twitter_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (1, '733df1a', 'রুপনগর আবাসিক হাই স্কুল', 0, '', NULL, NULL, 0, '2023-09-22', '2023-05-14', 'male', 'Islam', 'O+', 'House: Munshi Bari, Beside Nayar Hat High School, Borobari, Lalmonir Hat', 'House: Munshi Bari, Beside Nayar Hat High School, Borobari, Lalmonir Hat', '+8801775457008', 'info@elitedesign.com.bd', 0, NULL, 'f7937d8aef6142144481a53e6b256300.png', 'https://www.facebook.com/elitedesignbd', 'https://www.facebook.com/elitedesignbd', 'https://www.facebook.com/elitedesignbd', '2023-09-22 04:05:33', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (2, 'a89a612', 'Md Shamim Mia', 1, 'BSC In English', '5 Years', '5', 3, '2023-09-24', '1980-02-27', 'male', 'Islam', 'O+', 'demo', 'demo', '01775457009', 'shamim@elitedesign.com.bd', 0, 1, '56fa40def2bd7b491be0cdb256d41bea.png', '', '', '', '2023-09-23 17:23:42', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (3, '6216a0e', 'Jhanara Begum', 4, 'MA in Bangla', '2 Years', '2', 2, '2023-09-05', '1999-12-01', 'female', 'Islam', 'O+', 'demo', 'demo', '0177545710', 'jahanara@elitedesign.com.bd', 0, 1, '4d59f9a74b0af902b36732cf932d0ffb.jpg', '', '', '', '2023-09-23 17:26:18', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (4, '82383d9', 'Md Nayeem Hossain', 5, 'MA in English', '4 Years', '4', 3, '2023-09-04', '2002-03-03', 'male', 'Islam', 'A-', 'demo', 'demo', '0177545711', 'nayeem@gmail.com', 0, 1, '60b9e42f4db185525870d7c346683664.png', '', '', '', '2023-09-23 17:29:36', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (5, 'c5cb343', 'Md Kokhon Mia', 6, 'BSC in Mathemetics', '3 Years', '2', 1, '2023-09-11', '1995-07-13', 'male', 'Islam', 'A-', 'demo', 'demo', '0177545712', 'kokhon@gmail.com', 0, 1, 'cdaf00f107d9ed98127ab622a4122ca9.jpeg', '', '', '', '2023-09-23 17:32:01', NULL);
INSERT INTO `staff` (`id`, `staff_id`, `name`, `department`, `qualification`, `experience_details`, `total_experience`, `designation`, `joining_date`, `birthday`, `sex`, `religion`, `blood_group`, `present_address`, `permanent_address`, `mobileno`, `email`, `salary_template_id`, `branch_id`, `photo`, `facebook_url`, `linkedin_url`, `twitter_url`, `created_at`, `updated_at`) VALUES (6, '1e9da39', 'Shahida Khatun', 1, 'Demo', 'demo', '3', 2, '2023-09-11', '1995-01-28', 'female', 'Islam', 'B+', 'demo', 'demo', '01775457112', 'shahida@gmail.com', 0, 1, 'f7f898617dcd73fe69c529ca3740c1bf.jpg', '', '', '', '2023-09-23 17:36:16', NULL);


#
# TABLE STRUCTURE FOR: staff_attendance
#

DROP TABLE IF EXISTS `staff_attendance`;

CREATE TABLE `staff_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `status` varchar(11) DEFAULT NULL COMMENT 'P=Present, A=Absent, H=Holiday, L=Late',
  `remark` varchar(255) NOT NULL,
  `date` date DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: staff_bank_account
#

DROP TABLE IF EXISTS `staff_bank_account`;

CREATE TABLE `staff_bank_account` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `bank_name` varchar(200) NOT NULL,
  `holder_name` varchar(255) NOT NULL,
  `bank_branch` varchar(255) NOT NULL,
  `bank_address` varchar(255) NOT NULL,
  `ifsc_code` varchar(200) NOT NULL,
  `account_no` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: staff_department
#

DROP TABLE IF EXISTS `staff_department`;

CREATE TABLE `staff_department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `staff_department` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (1, 'Class', 1, '2023-09-23 17:19:50', NULL);
INSERT INTO `staff_department` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (2, 'Computer', 1, '2023-09-23 17:19:57', NULL);
INSERT INTO `staff_department` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (3, 'Gym', 1, '2023-09-23 17:20:07', NULL);
INSERT INTO `staff_department` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (4, 'Bangla', 1, '2023-09-23 17:20:17', NULL);
INSERT INTO `staff_department` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (5, 'English', 1, '2023-09-23 17:20:24', NULL);
INSERT INTO `staff_department` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (6, 'Math', 1, '2023-09-23 17:20:33', NULL);


#
# TABLE STRUCTURE FOR: staff_designation
#

DROP TABLE IF EXISTS `staff_designation`;

CREATE TABLE `staff_designation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (1, 'SR Class Teacher', 1, '2023-09-23 17:20:50', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (2, 'Jr Classs Teacher', 1, '2023-09-23 17:21:01', NULL);
INSERT INTO `staff_designation` (`id`, `name`, `branch_id`, `created_at`, `updated_at`) VALUES (3, 'Professior', 1, '2023-09-23 17:21:17', NULL);


#
# TABLE STRUCTURE FOR: staff_documents
#

DROP TABLE IF EXISTS `staff_documents`;

CREATE TABLE `staff_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `staff_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `category_id` varchar(20) NOT NULL,
  `remarks` text NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `enc_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: staff_privileges
#

DROP TABLE IF EXISTS `staff_privileges`;

CREATE TABLE `staff_privileges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role_id` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `is_add` tinyint(1) NOT NULL,
  `is_edit` tinyint(1) NOT NULL,
  `is_view` tinyint(1) NOT NULL,
  `is_delete` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=804 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (1, 3, 1, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (2, 3, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (3, 3, 3, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (4, 3, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (5, 3, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (6, 3, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (7, 3, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (8, 3, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (9, 3, 6, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (10, 3, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (11, 3, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (12, 3, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (13, 3, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (14, 3, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (15, 3, 14, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (16, 3, 15, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (17, 3, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (18, 3, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (20, 3, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (21, 3, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (22, 3, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (23, 3, 22, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (24, 3, 23, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (25, 3, 24, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (26, 3, 25, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (27, 3, 26, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (28, 3, 27, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (29, 3, 28, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (30, 3, 29, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (31, 3, 32, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (32, 3, 31, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (33, 3, 33, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (34, 3, 34, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (35, 3, 35, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (36, 3, 36, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (37, 3, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (38, 3, 38, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (39, 3, 39, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (40, 3, 77, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (41, 3, 78, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (42, 3, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (43, 3, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (44, 3, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (45, 3, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (46, 3, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (47, 3, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (48, 3, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (49, 3, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (50, 3, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (51, 3, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (52, 3, 49, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (53, 3, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (54, 3, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (55, 3, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (56, 3, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (57, 3, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (58, 3, 55, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (59, 3, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (60, 3, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (61, 3, 58, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (62, 3, 59, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (63, 3, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (64, 3, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (65, 3, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (66, 3, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (67, 3, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (68, 3, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (69, 3, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (70, 3, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (71, 3, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (72, 3, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (73, 3, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (74, 3, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (75, 3, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (76, 3, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (77, 3, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (78, 3, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (79, 3, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (80, 3, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (81, 3, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (82, 3, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (83, 3, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (84, 3, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (85, 3, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (86, 3, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (87, 3, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (88, 2, 1, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (89, 2, 2, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (90, 2, 3, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (91, 2, 4, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (92, 2, 5, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (93, 2, 30, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (94, 2, 7, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (95, 2, 8, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (96, 2, 6, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (97, 2, 9, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (98, 2, 10, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (99, 2, 11, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (100, 2, 12, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (101, 2, 13, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (102, 2, 14, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (103, 2, 15, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (104, 2, 16, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (105, 2, 17, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (107, 2, 19, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (108, 2, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (109, 2, 21, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (110, 2, 22, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (111, 2, 23, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (112, 2, 24, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (113, 2, 25, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (114, 2, 26, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (115, 2, 27, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (116, 2, 28, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (117, 2, 29, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (118, 2, 32, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (119, 2, 31, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (120, 2, 33, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (121, 2, 34, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (122, 2, 35, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (123, 2, 36, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (124, 2, 37, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (125, 2, 38, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (126, 2, 39, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (127, 2, 77, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (128, 2, 78, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (129, 2, 79, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (130, 2, 40, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (131, 2, 41, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (132, 2, 42, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (133, 2, 43, 0, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (134, 2, 44, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (135, 2, 45, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (136, 2, 46, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (137, 2, 47, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (138, 2, 48, 0, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (139, 2, 49, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (140, 2, 50, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (141, 2, 51, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (142, 2, 52, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (143, 2, 53, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (144, 2, 54, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (145, 2, 55, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (146, 2, 56, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (147, 2, 57, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (148, 2, 58, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (149, 2, 59, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (150, 2, 60, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (151, 2, 61, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (152, 2, 62, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (153, 2, 80, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (154, 2, 69, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (155, 2, 70, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (156, 2, 71, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (157, 2, 72, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (158, 2, 73, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (159, 2, 74, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (160, 2, 75, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (161, 2, 76, 0, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (162, 2, 63, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (163, 2, 64, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (164, 2, 65, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (165, 2, 66, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (166, 2, 67, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (167, 2, 68, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (168, 2, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (169, 2, 82, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (170, 2, 83, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (171, 2, 84, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (172, 2, 85, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (173, 2, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (174, 2, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (175, 7, 1, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (176, 7, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (177, 7, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (178, 7, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (179, 7, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (180, 7, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (181, 7, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (182, 7, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (183, 7, 6, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (184, 7, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (185, 7, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (186, 7, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (187, 7, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (188, 7, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (189, 7, 14, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (190, 7, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (191, 7, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (192, 7, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (194, 7, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (195, 7, 20, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (196, 7, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (197, 7, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (198, 7, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (199, 7, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (200, 7, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (201, 7, 26, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (202, 7, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (203, 7, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (204, 7, 29, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (205, 7, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (206, 7, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (207, 7, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (208, 7, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (209, 7, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (210, 7, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (211, 7, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (212, 7, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (213, 7, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (214, 7, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (215, 7, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (216, 7, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (217, 7, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (218, 7, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (219, 7, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (220, 7, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (221, 7, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (222, 7, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (223, 7, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (224, 7, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (225, 7, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (226, 7, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (227, 7, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (228, 7, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (229, 7, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (230, 7, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (231, 7, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (232, 7, 55, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (233, 7, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (234, 7, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (235, 7, 58, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (236, 7, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (237, 7, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (238, 7, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (239, 7, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (240, 7, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (241, 7, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (242, 7, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (243, 7, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (244, 7, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (245, 7, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (246, 7, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (247, 7, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (248, 7, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (249, 7, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (250, 7, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (251, 7, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (252, 7, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (253, 7, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (254, 7, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (255, 7, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (256, 7, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (257, 7, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (258, 7, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (259, 7, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (260, 7, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (261, 7, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (262, 88, 88, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (263, 88, 88, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (264, 89, 89, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (265, 90, 90, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (266, 2, 88, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (267, 2, 89, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (268, 90, 90, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (269, 2, 90, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (270, 91, 91, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (271, 92, 92, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (272, 2, 91, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (273, 2, 92, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (274, 93, 93, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (275, 94, 94, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (276, 95, 95, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (277, 96, 96, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (278, 2, 93, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (279, 2, 94, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (280, 2, 95, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (281, 2, 96, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (282, 97, 97, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (283, 98, 98, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (284, 2, 97, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (285, 2, 98, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (286, 99, 99, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (287, 100, 100, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (288, 101, 101, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (289, 102, 102, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (290, 2, 99, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (291, 2, 100, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (292, 2, 101, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (293, 2, 102, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (294, 103, 103, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (295, 2, 103, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (296, 3, 91, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (297, 3, 92, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (298, 3, 93, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (299, 3, 94, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (300, 3, 95, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (301, 3, 96, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (302, 3, 97, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (303, 3, 98, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (304, 3, 99, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (305, 3, 100, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (306, 3, 101, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (307, 3, 102, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (308, 3, 88, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (309, 3, 89, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (310, 3, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (311, 3, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (312, 4, 91, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (313, 4, 92, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (314, 4, 93, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (315, 4, 94, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (316, 4, 95, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (317, 4, 96, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (318, 4, 97, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (319, 4, 98, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (320, 4, 99, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (321, 4, 100, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (322, 4, 101, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (323, 4, 102, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (324, 4, 1, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (325, 4, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (326, 4, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (327, 4, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (328, 4, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (329, 4, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (330, 4, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (331, 4, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (332, 4, 6, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (333, 4, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (334, 4, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (335, 4, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (336, 4, 12, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (337, 4, 13, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (338, 4, 14, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (339, 4, 15, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (340, 4, 16, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (341, 4, 17, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (343, 4, 19, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (344, 4, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (345, 4, 21, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (346, 4, 22, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (347, 4, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (348, 4, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (349, 4, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (350, 4, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (351, 4, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (352, 4, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (353, 4, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (354, 4, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (355, 4, 88, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (356, 4, 89, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (357, 4, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (358, 4, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (359, 4, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (360, 4, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (361, 4, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (362, 4, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (363, 4, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (364, 4, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (365, 4, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (366, 4, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (367, 4, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (368, 4, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (369, 4, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (370, 4, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (371, 4, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (372, 4, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (373, 4, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (374, 4, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (375, 4, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (376, 4, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (377, 4, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (378, 4, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (379, 4, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (380, 4, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (381, 4, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (382, 4, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (383, 4, 55, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (384, 4, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (385, 4, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (386, 4, 58, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (387, 4, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (388, 4, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (389, 4, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (390, 4, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (391, 4, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (392, 4, 69, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (393, 4, 70, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (394, 4, 71, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (395, 4, 72, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (396, 4, 73, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (397, 4, 74, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (398, 4, 75, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (399, 4, 76, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (400, 4, 63, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (401, 4, 64, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (402, 4, 65, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (403, 4, 66, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (404, 4, 67, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (405, 4, 68, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (406, 4, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (407, 4, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (408, 4, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (409, 4, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (410, 4, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (411, 4, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (412, 4, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (413, 4, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (414, 4, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (415, 5, 91, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (416, 5, 92, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (417, 5, 93, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (418, 5, 94, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (419, 5, 95, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (420, 5, 96, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (421, 5, 97, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (422, 5, 98, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (423, 5, 99, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (424, 5, 100, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (425, 5, 101, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (426, 5, 102, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (427, 5, 1, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (428, 5, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (429, 5, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (430, 5, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (431, 5, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (432, 5, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (433, 5, 7, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (434, 5, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (435, 5, 6, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (436, 5, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (437, 5, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (438, 5, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (439, 5, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (440, 5, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (441, 5, 14, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (442, 5, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (443, 5, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (444, 5, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (446, 5, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (447, 5, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (448, 5, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (449, 5, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (450, 5, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (451, 5, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (452, 5, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (453, 5, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (454, 5, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (455, 5, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (456, 5, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (457, 5, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (458, 5, 88, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (459, 5, 89, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (460, 5, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (461, 5, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (462, 5, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (463, 5, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (464, 5, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (465, 5, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (466, 5, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (467, 5, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (468, 5, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (469, 5, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (470, 5, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (471, 5, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (472, 5, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (473, 5, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (474, 5, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (475, 5, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (476, 5, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (477, 5, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (478, 5, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (479, 5, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (480, 5, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (481, 5, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (482, 5, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (483, 5, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (484, 5, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (485, 5, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (486, 5, 55, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (487, 5, 56, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (488, 5, 57, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (489, 5, 58, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (490, 5, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (491, 5, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (492, 5, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (493, 5, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (494, 5, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (495, 5, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (496, 5, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (497, 5, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (498, 5, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (499, 5, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (500, 5, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (501, 5, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (502, 5, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (503, 5, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (504, 5, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (505, 5, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (506, 5, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (507, 5, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (508, 5, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (509, 5, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (510, 5, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (511, 5, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (512, 5, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (513, 5, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (514, 5, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (515, 5, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (516, 5, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (517, 5, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (518, 104, 104, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (519, 2, 104, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (520, 4, 104, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (521, 2, 18, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (522, 2, 105, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (523, 2, 106, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (524, 2, 107, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (525, 2, 109, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (526, 2, 108, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (527, 3, 18, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (528, 3, 107, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (529, 3, 109, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (530, 3, 104, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (531, 3, 105, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (532, 3, 106, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (533, 3, 108, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (534, 2, 110, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (535, 2, 111, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (536, 2, 112, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (537, 2, 113, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (538, 2, 114, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (539, 2, 115, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (540, 2, 116, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (541, 2, 117, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (542, 3, 110, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (543, 3, 111, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (544, 3, 112, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (545, 3, 113, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (546, 3, 114, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (547, 3, 115, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (548, 3, 116, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (549, 3, 117, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (550, 2, 127, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (551, 2, 118, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (552, 2, 119, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (553, 2, 120, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (554, 2, 121, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (555, 2, 122, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (556, 2, 123, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (557, 2, 124, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (558, 2, 125, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (559, 2, 126, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (560, 3, 118, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (561, 3, 119, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (562, 3, 120, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (563, 3, 121, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (564, 3, 122, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (565, 3, 123, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (566, 3, 124, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (567, 3, 125, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (568, 3, 126, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (569, 3, 127, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (570, 3, 128, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (571, 2, 129, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (572, 2, 128, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (573, 2, 131, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (574, 2, 132, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (575, 2, 130, 0, 0, 0, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (576, 4, 118, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (577, 4, 119, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (578, 4, 120, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (579, 4, 121, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (580, 4, 122, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (581, 4, 123, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (582, 4, 124, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (583, 4, 125, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (584, 4, 126, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (585, 4, 131, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (586, 4, 132, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (587, 4, 127, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (588, 4, 113, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (589, 4, 114, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (590, 4, 115, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (591, 4, 116, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (592, 4, 117, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (593, 4, 110, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (594, 4, 111, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (595, 4, 112, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (596, 4, 18, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (597, 4, 107, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (598, 4, 109, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (599, 4, 129, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (600, 4, 130, 0, 0, 0, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (601, 4, 105, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (602, 4, 106, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (603, 4, 108, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (604, 4, 128, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (605, 2, 131, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (606, 2, 132, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (607, 2, 133, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (608, 3, 133, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (609, 2, 134, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (610, 2, 136, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (611, 2, 137, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (612, 2, 138, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (613, 2, 139, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (614, 2, 140, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (615, 2, 135, 0, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (616, 3, 131, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (617, 3, 132, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (618, 3, 129, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (619, 3, 130, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (620, 3, 136, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (621, 3, 137, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (622, 3, 138, 1, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (623, 3, 139, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (624, 3, 140, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (625, 3, 134, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (626, 3, 135, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (627, 2, 141, 1, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (628, 2, 142, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (629, 2, 143, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (630, 2, 144, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (631, 2, 145, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (632, 2, 146, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (633, 2, 147, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (634, 2, 148, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (635, 2, 149, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (636, 2, 150, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (637, 2, 151, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (638, 2, 152, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (639, 2, 153, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (640, 8, 91, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (641, 8, 92, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (642, 8, 93, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (643, 8, 94, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (644, 8, 95, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (645, 8, 96, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (646, 8, 97, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (647, 8, 98, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (648, 8, 99, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (649, 8, 100, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (650, 8, 101, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (651, 8, 102, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (652, 8, 151, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (653, 8, 152, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (654, 8, 118, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (655, 8, 119, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (656, 8, 120, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (657, 8, 121, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (658, 8, 122, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (659, 8, 123, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (660, 8, 124, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (661, 8, 125, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (662, 8, 126, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (663, 8, 131, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (664, 8, 132, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (665, 8, 1, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (666, 8, 2, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (667, 8, 3, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (668, 8, 4, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (669, 8, 5, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (670, 8, 30, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (671, 8, 127, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (672, 8, 7, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (673, 8, 8, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (674, 8, 6, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (675, 8, 9, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (676, 8, 10, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (677, 8, 11, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (678, 8, 113, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (679, 8, 114, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (680, 8, 115, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (681, 8, 116, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (682, 8, 117, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (683, 8, 110, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (684, 8, 111, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (685, 8, 112, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (686, 8, 12, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (687, 8, 13, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (688, 8, 14, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (689, 8, 15, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (690, 8, 16, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (691, 8, 17, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (692, 8, 18, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (693, 8, 19, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (694, 8, 20, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (695, 8, 21, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (696, 8, 22, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (697, 8, 107, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (698, 8, 23, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (699, 8, 24, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (700, 8, 25, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (701, 8, 26, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (702, 8, 27, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (703, 8, 28, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (704, 8, 29, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (705, 8, 133, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (706, 8, 109, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (707, 8, 129, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (708, 8, 31, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (709, 8, 33, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (710, 8, 32, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (711, 8, 88, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (712, 8, 89, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (713, 8, 34, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (714, 8, 35, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (715, 8, 36, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (716, 8, 37, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (717, 8, 38, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (718, 8, 39, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (719, 8, 77, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (720, 8, 78, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (721, 8, 79, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (722, 8, 153, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (723, 8, 40, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (724, 8, 41, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (725, 8, 42, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (726, 8, 43, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (727, 8, 44, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (728, 8, 45, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (729, 8, 46, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (730, 8, 47, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (731, 8, 48, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (732, 8, 49, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (733, 8, 50, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (734, 8, 51, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (735, 8, 52, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (736, 8, 53, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (737, 8, 54, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (738, 8, 55, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (739, 8, 56, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (740, 8, 57, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (741, 8, 58, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (742, 8, 59, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (743, 8, 60, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (744, 8, 61, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (745, 8, 62, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (746, 8, 80, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (747, 8, 149, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (748, 8, 150, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (749, 8, 69, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (750, 8, 70, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (751, 8, 71, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (752, 8, 72, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (753, 8, 73, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (754, 8, 74, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (755, 8, 75, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (756, 8, 76, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (757, 8, 104, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (758, 8, 130, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (759, 8, 63, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (760, 8, 64, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (761, 8, 65, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (762, 8, 66, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (763, 8, 67, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (764, 8, 68, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (765, 8, 136, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (766, 8, 137, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (767, 8, 138, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (768, 8, 139, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (769, 8, 140, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (770, 8, 141, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (771, 8, 142, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (772, 8, 143, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (773, 8, 144, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (774, 8, 145, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (775, 8, 146, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (776, 8, 147, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (777, 8, 148, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (778, 8, 81, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (779, 8, 82, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (780, 8, 83, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (781, 8, 84, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (782, 8, 85, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (783, 8, 86, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (784, 8, 87, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (785, 8, 90, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (786, 8, 103, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (787, 8, 105, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (788, 8, 106, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (789, 8, 108, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (790, 8, 128, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (791, 8, 134, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (792, 8, 135, 0, 0, 0, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (793, 2, 157, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (794, 2, 158, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (795, 2, 159, 1, 1, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (796, 2, 160, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (797, 2, 161, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (798, 2, 162, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (799, 2, 163, 1, 1, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (800, 2, 164, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (801, 2, 165, 0, 0, 1, 0);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (802, 2, 166, 1, 0, 1, 1);
INSERT INTO `staff_privileges` (`id`, `role_id`, `permission_id`, `is_add`, `is_edit`, `is_view`, `is_delete`) VALUES (803, 2, 167, 0, 0, 1, 0);


#
# TABLE STRUCTURE FOR: student
#

DROP TABLE IF EXISTS `student`;

CREATE TABLE `student` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `register_no` varchar(100) DEFAULT NULL,
  `admission_date` varchar(100) DEFAULT NULL,
  `first_name` varchar(255) DEFAULT NULL,
  `last_name` varchar(255) DEFAULT NULL,
  `gender` varchar(20) DEFAULT NULL,
  `birthday` varchar(100) DEFAULT NULL,
  `religion` varchar(100) DEFAULT NULL,
  `caste` varchar(100) DEFAULT NULL,
  `blood_group` varchar(100) DEFAULT NULL,
  `mother_tongue` varchar(100) DEFAULT NULL,
  `current_address` text DEFAULT NULL,
  `permanent_address` text DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `state` varchar(255) DEFAULT NULL,
  `mobileno` varchar(100) DEFAULT NULL,
  `category_id` int(11) NOT NULL DEFAULT 0,
  `email` varchar(100) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `route_id` int(11) NOT NULL DEFAULT 0,
  `vehicle_id` int(11) NOT NULL DEFAULT 0,
  `hostel_id` int(11) NOT NULL DEFAULT 0,
  `room_id` int(11) NOT NULL DEFAULT 0,
  `previous_details` text DEFAULT NULL,
  `photo` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `student` (`id`, `register_no`, `admission_date`, `first_name`, `last_name`, `gender`, `birthday`, `religion`, `caste`, `blood_group`, `mother_tongue`, `current_address`, `permanent_address`, `city`, `state`, `mobileno`, `category_id`, `email`, `parent_id`, `route_id`, `vehicle_id`, `hostel_id`, `room_id`, `previous_details`, `photo`, `created_at`, `updated_at`) VALUES (1, '1252', '2023-09-23', 'Md', 'Abu Sayed', 'male', '2010-02-02', 'Islam', '', 'O+', 'Bengali', '35/3/1', '35/3/1', 'Lalmonir Hat', 'LH', '01775457008', 1, 'sayed@gmail.com', 1, 0, 0, 0, 0, '{\"school_name\":\"Dhansiri Internation School\",\"qualification\":\"KG\",\"remarks\":\"N\\/A\"}', '2f3abbb19b44ff9cd69bcf5e71789155.jpg', '2023-09-24 06:47:00', NULL);
INSERT INTO `student` (`id`, `register_no`, `admission_date`, `first_name`, `last_name`, `gender`, `birthday`, `religion`, `caste`, `blood_group`, `mother_tongue`, `current_address`, `permanent_address`, `city`, `state`, `mobileno`, `category_id`, `email`, `parent_id`, `route_id`, `vehicle_id`, `hostel_id`, `room_id`, `previous_details`, `photo`, `created_at`, `updated_at`) VALUES (2, '12586', '2023-09-25', 'Md', 'Nayeem', 'male', '2008-10-21', 'Islam', '', 'O+', 'Bengali', '35/3/1-B', '', 'Dhaka', 'LH', '01775457008', 1, 'info.elitedesignsbd@gmail.com', 1, 0, 0, 0, 0, '{\"school_name\":\"Dhansiri Internation School\",\"qualification\":\"KG\",\"remarks\":\"\"}', 'ed367f7e8617bcbd4354ddbb677f44c4.png', '2023-09-25 13:47:31', NULL);
INSERT INTO `student` (`id`, `register_no`, `admission_date`, `first_name`, `last_name`, `gender`, `birthday`, `religion`, `caste`, `blood_group`, `mother_tongue`, `current_address`, `permanent_address`, `city`, `state`, `mobileno`, `category_id`, `email`, `parent_id`, `route_id`, `vehicle_id`, `hostel_id`, `room_id`, `previous_details`, `photo`, `created_at`, `updated_at`) VALUES (3, '125865', '2023-09-25', 'Md', 'Kuddus Ali', 'male', '2015-06-04', 'Islam', '', '', 'Bengali', '35/3/1-B', '', 'Dhaka', 'LH', '01775457008', 1, 'shadhinhostbd@gmail.com', 1, 0, 0, 0, 0, '{\"school_name\":\"\",\"qualification\":\"\",\"remarks\":\"\"}', '83001ce59013530ccb6893001be30aac.png', '2023-09-25 13:52:13', NULL);


#
# TABLE STRUCTURE FOR: student_admission_fields
#

DROP TABLE IF EXISTS `student_admission_fields`;

CREATE TABLE `student_admission_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fields_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `required` tinyint(4) NOT NULL DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: student_attendance
#

DROP TABLE IF EXISTS `student_attendance`;

CREATE TABLE `student_attendance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `enroll_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `status` varchar(4) DEFAULT NULL COMMENT 'P=Present, A=Absent, H=Holiday, L=Late',
  `remark` text DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: student_category
#

DROP TABLE IF EXISTS `student_category`;

CREATE TABLE `student_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `branch_id` int(11) NOT NULL DEFAULT 0,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `student_category` (`id`, `branch_id`, `name`) VALUES (1, 1, 'নিয়মিত');
INSERT INTO `student_category` (`id`, `branch_id`, `name`) VALUES (2, 1, 'অনিয়মিত');


#
# TABLE STRUCTURE FOR: student_documents
#

DROP TABLE IF EXISTS `student_documents`;

CREATE TABLE `student_documents` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `type` varchar(100) NOT NULL,
  `remarks` text NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `enc_name` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: student_fields
#

DROP TABLE IF EXISTS `student_fields`;

CREATE TABLE `student_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `prefix` varchar(255) NOT NULL,
  `default_status` tinyint(1) NOT NULL DEFAULT 1,
  `default_required` tinyint(4) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (1, 'roll', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (2, 'last_name', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (3, 'gender', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (4, 'birthday', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (5, 'admission_date', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (6, 'category', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (7, 'section', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (8, 'religion', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (9, 'caste', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (10, 'blood_group', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (11, 'mother_tongue', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (12, 'present_address', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (13, 'permanent_address', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (14, 'city', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (15, 'state', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (16, 'student_email', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (17, 'student_mobile_no', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (18, 'student_photo', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (19, 'previous_school_details', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (20, 'guardian_name', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (21, 'guardian_relation', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (22, 'father_name', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (23, 'mother_name', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (24, 'guardian_occupation', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (25, 'guardian_income', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (26, 'guardian_education', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (27, 'guardian_email', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (28, 'guardian_mobile_no', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (29, 'guardian_address', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (30, 'guardian_photo', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (31, 'upload_documents', 1, 1, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (32, 'guardian_city', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (33, 'guardian_state', 1, 0, '2022-04-25 20:27:04');
INSERT INTO `student_fields` (`id`, `prefix`, `default_status`, `default_required`, `created_at`) VALUES (34, 'first_name', 1, 1, '2022-04-25 20:27:04');


#
# TABLE STRUCTURE FOR: student_profile_fields
#

DROP TABLE IF EXISTS `student_profile_fields`;

CREATE TABLE `student_profile_fields` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `fields_id` int(11) NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 1,
  `required` tinyint(4) NOT NULL DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: subject
#

DROP TABLE IF EXISTS `subject`;

CREATE TABLE `subject` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `subject_code` varchar(200) NOT NULL,
  `subject_type` varchar(255) CHARACTER SET utf32 COLLATE utf32_unicode_ci NOT NULL,
  `subject_author` varchar(255) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (1, 'Bangla', '101', 'Theory', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (2, 'English', '102', 'Theory', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (3, 'Mathemetics', '103', 'Theory', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (4, 'Social Science', '104', 'Theory', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (5, 'Generel Science', '105', 'Theory', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (6, 'Islam', '106', 'Theory', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (7, 'Computer Science', '107', 'Practical', '', 1);
INSERT INTO `subject` (`id`, `name`, `subject_code`, `subject_type`, `subject_author`, `branch_id`) VALUES (8, 'Aggriclutre', '107', 'Practical', '', 1);


#
# TABLE STRUCTURE FOR: subject_assign
#

DROP TABLE IF EXISTS `subject_assign`;

CREATE TABLE `subject_assign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `subject_id` longtext NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (1, 1, 1, '1', 0, 1, 4, '2023-09-23 17:13:03', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (2, 1, 1, '2', 0, 1, 4, '2023-09-23 17:13:03', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (3, 1, 1, '3', 0, 1, 4, '2023-09-23 17:13:03', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (4, 2, 2, '1', 0, 1, 4, '2023-09-23 17:13:17', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (5, 2, 2, '2', 0, 1, 4, '2023-09-23 17:13:17', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (6, 2, 2, '3', 0, 1, 4, '2023-09-23 17:13:17', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (7, 3, 3, '1', 0, 1, 4, '2023-09-23 17:13:46', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (8, 3, 3, '2', 0, 1, 4, '2023-09-23 17:13:46', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (9, 3, 3, '3', 0, 1, 4, '2023-09-23 17:13:46', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (10, 3, 3, '4', 0, 1, 4, '2023-09-23 17:13:46', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (11, 3, 3, '5', 0, 1, 4, '2023-09-23 17:13:46', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (12, 3, 3, '6', 0, 1, 4, '2023-09-23 17:13:46', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (13, 3, 3, '7', 0, 1, 4, '2023-09-23 17:13:46', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (14, 4, 2, '1', 0, 1, 4, '2023-09-23 17:16:46', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (15, 4, 2, '2', 0, 1, 4, '2023-09-23 17:16:46', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (16, 4, 2, '3', 0, 1, 4, '2023-09-23 17:16:46', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (17, 4, 2, '4', 0, 1, 4, '2023-09-23 17:16:46', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (18, 4, 2, '5', 0, 1, 4, '2023-09-23 17:16:46', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (19, 4, 2, '6', 0, 1, 4, '2023-09-23 17:16:46', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (20, 4, 2, '7', 0, 1, 4, '2023-09-23 17:16:46', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (21, 4, 2, '8', 0, 1, 4, '2023-09-23 17:16:46', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (22, 5, 2, '1', 0, 1, 4, '2023-09-23 17:17:49', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (23, 5, 2, '2', 0, 1, 4, '2023-09-23 17:17:49', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (24, 5, 2, '3', 0, 1, 4, '2023-09-23 17:17:49', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (25, 5, 2, '4', 0, 1, 4, '2023-09-23 17:17:49', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (26, 5, 2, '5', 0, 1, 4, '2023-09-23 17:17:49', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (27, 5, 2, '6', 0, 1, 4, '2023-09-23 17:17:49', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (28, 1, 1, '1', 0, 1, 6, '2023-09-25 14:57:10', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (29, 1, 1, '2', 0, 1, 6, '2023-09-25 14:57:10', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (30, 1, 1, '3', 0, 1, 6, '2023-09-25 14:57:10', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (31, 1, 2, '1', 3, 1, 6, '2023-09-25 14:57:25', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (32, 1, 2, '2', 3, 1, 6, '2023-09-25 14:57:25', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (33, 1, 2, '3', 3, 1, 6, '2023-09-25 14:57:25', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (34, 1, 3, '1', 2, 1, 6, '2023-09-25 14:57:40', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (35, 1, 3, '2', 2, 1, 6, '2023-09-25 14:57:40', NULL);
INSERT INTO `subject_assign` (`id`, `class_id`, `section_id`, `subject_id`, `teacher_id`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (36, 1, 3, '3', 2, 1, 6, '2023-09-25 14:57:40', NULL);


#
# TABLE STRUCTURE FOR: teacher_allocation
#

DROP TABLE IF EXISTS `teacher_allocation`;

CREATE TABLE `teacher_allocation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `teacher_allocation` (`id`, `class_id`, `section_id`, `teacher_id`, `session_id`, `branch_id`) VALUES (1, 1, 1, 2, 4, 1);
INSERT INTO `teacher_allocation` (`id`, `class_id`, `section_id`, `teacher_id`, `session_id`, `branch_id`) VALUES (2, 2, 2, 3, 4, 1);
INSERT INTO `teacher_allocation` (`id`, `class_id`, `section_id`, `teacher_id`, `session_id`, `branch_id`) VALUES (3, 3, 3, 2, 4, 1);
INSERT INTO `teacher_allocation` (`id`, `class_id`, `section_id`, `teacher_id`, `session_id`, `branch_id`) VALUES (4, 5, 2, 2, 4, 1);
INSERT INTO `teacher_allocation` (`id`, `class_id`, `section_id`, `teacher_id`, `session_id`, `branch_id`) VALUES (5, 1, 2, 3, 6, 1);
INSERT INTO `teacher_allocation` (`id`, `class_id`, `section_id`, `teacher_id`, `session_id`, `branch_id`) VALUES (6, 1, 3, 2, 6, 1);


#
# TABLE STRUCTURE FOR: teacher_note
#

DROP TABLE IF EXISTS `teacher_note`;

CREATE TABLE `teacher_note` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` longtext NOT NULL,
  `description` longtext NOT NULL,
  `file_name` longtext NOT NULL,
  `enc_name` longtext NOT NULL,
  `type_id` int(11) NOT NULL,
  `class_id` longtext NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: theme_settings
#

DROP TABLE IF EXISTS `theme_settings`;

CREATE TABLE `theme_settings` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `border_mode` varchar(200) NOT NULL,
  `dark_skin` varchar(200) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `theme_settings` (`id`, `border_mode`, `dark_skin`, `created_at`, `updated_at`) VALUES (1, 'true', 'false', '2018-10-23 12:59:38', '2020-05-10 14:08:47');


#
# TABLE STRUCTURE FOR: timetable_class
#

DROP TABLE IF EXISTS `timetable_class`;

CREATE TABLE `timetable_class` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `break` varchar(11) DEFAULT 'false',
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `class_room` varchar(100) DEFAULT NULL,
  `time_start` time NOT NULL,
  `time_end` time NOT NULL,
  `day` varchar(20) NOT NULL,
  `session_id` int(11) NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (1, 1, 1, '0', 1, 2, '101', '08:00:00', '09:00:00', 'sunday', 6, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (2, 1, 1, '0', 2, 3, '101', '09:00:00', '10:00:00', 'sunday', 6, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (3, 1, 1, '1', 0, 0, '', '10:00:00', '10:30:00', 'sunday', 6, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (4, 1, 1, '0', 3, 5, '101', '10:30:00', '11:30:00', 'sunday', 6, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (5, 1, 1, '0', 1, 2, '101', '08:15:00', '09:15:00', 'monday', 6, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (6, 1, 1, '0', 2, 3, '101', '09:15:00', '10:15:00', 'monday', 6, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (7, 1, 1, '1', 0, 0, '', '10:00:00', '10:30:00', 'monday', 6, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (8, 1, 1, '0', 3, 5, '101', '01:15:00', '01:15:00', 'monday', 6, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (9, 1, 1, '0', 1, 2, '101', '01:15:00', '01:15:00', 'tuesday', 6, 1);
INSERT INTO `timetable_class` (`id`, `class_id`, `section_id`, `break`, `subject_id`, `teacher_id`, `class_room`, `time_start`, `time_end`, `day`, `session_id`, `branch_id`) VALUES (10, 1, 1, '0', 1, 4, '101', '01:15:00', '01:15:00', 'tuesday', 6, 1);


#
# TABLE STRUCTURE FOR: timetable_exam
#

DROP TABLE IF EXISTS `timetable_exam`;

CREATE TABLE `timetable_exam` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `exam_id` int(11) NOT NULL,
  `class_id` int(11) NOT NULL,
  `section_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `time_start` varchar(20) NOT NULL,
  `time_end` varchar(20) NOT NULL,
  `mark_distribution` text NOT NULL,
  `hall_id` int(11) NOT NULL,
  `exam_date` date NOT NULL,
  `branch_id` int(11) NOT NULL,
  `session_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `timetable_exam` (`id`, `exam_id`, `class_id`, `section_id`, `subject_id`, `time_start`, `time_end`, `mark_distribution`, `hall_id`, `exam_date`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (1, 1, 1, 1, 1, '1:05 AM', '1:05 AM', '{\"1\":{\"full_mark\":\"30\",\"pass_mark\":\"20\"},\"2\":{\"full_mark\":\"70\",\"pass_mark\":\"22\"}}', 2, '2023-09-26', 1, 6, '2023-09-25 15:05:21', NULL);
INSERT INTO `timetable_exam` (`id`, `exam_id`, `class_id`, `section_id`, `subject_id`, `time_start`, `time_end`, `mark_distribution`, `hall_id`, `exam_date`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (2, 1, 1, 1, 2, '1:05 AM', '1:05 AM', '{\"1\":{\"full_mark\":\"30\",\"pass_mark\":\"20\"},\"2\":{\"full_mark\":\"70\",\"pass_mark\":\"22\"}}', 3, '2023-09-26', 1, 6, '2023-09-25 15:05:21', NULL);
INSERT INTO `timetable_exam` (`id`, `exam_id`, `class_id`, `section_id`, `subject_id`, `time_start`, `time_end`, `mark_distribution`, `hall_id`, `exam_date`, `branch_id`, `session_id`, `created_at`, `updated_at`) VALUES (3, 1, 1, 1, 3, '1:05 AM', '1:05 AM', '{\"1\":{\"full_mark\":\"30\",\"pass_mark\":\"20\"},\"2\":{\"full_mark\":\"70\",\"pass_mark\":\"22\"}}', 1, '2023-09-26', 1, 6, '2023-09-25 15:05:21', NULL);


#
# TABLE STRUCTURE FOR: transactions
#

DROP TABLE IF EXISTS `transactions`;

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` varchar(20) NOT NULL,
  `voucher_head_id` int(11) NOT NULL,
  `type` varchar(100) NOT NULL,
  `category` varchar(20) NOT NULL,
  `ref` varchar(255) NOT NULL,
  `amount` decimal(18,2) NOT NULL DEFAULT 0.00,
  `dr` decimal(18,2) NOT NULL DEFAULT 0.00,
  `cr` decimal(18,2) NOT NULL DEFAULT 0.00,
  `bal` decimal(18,2) NOT NULL DEFAULT 0.00,
  `date` date NOT NULL,
  `pay_via` varchar(20) NOT NULL,
  `description` text NOT NULL,
  `attachments` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `system` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: transactions_links
#

DROP TABLE IF EXISTS `transactions_links`;

CREATE TABLE `transactions_links` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `status` tinyint(3) DEFAULT NULL,
  `deposit` tinyint(3) DEFAULT NULL,
  `expense` tinyint(3) DEFAULT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: transactions_links_details
#

DROP TABLE IF EXISTS `transactions_links_details`;

CREATE TABLE `transactions_links_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `payment_id` int(11) NOT NULL,
  `transactions_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: transport_assign
#

DROP TABLE IF EXISTS `transport_assign`;

CREATE TABLE `transport_assign` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `route_id` int(11) NOT NULL,
  `stoppage_id` int(11) NOT NULL,
  `vehicle_id` int(11) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: transport_route
#

DROP TABLE IF EXISTS `transport_route`;

CREATE TABLE `transport_route` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` longtext NOT NULL,
  `start_place` longtext NOT NULL,
  `remarks` longtext NOT NULL,
  `stop_place` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: transport_stoppage
#

DROP TABLE IF EXISTS `transport_stoppage`;

CREATE TABLE `transport_stoppage` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `stop_position` varchar(255) NOT NULL,
  `stop_time` time NOT NULL,
  `route_fare` decimal(18,2) NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: transport_vehicle
#

DROP TABLE IF EXISTS `transport_vehicle`;

CREATE TABLE `transport_vehicle` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `vehicle_no` longtext NOT NULL,
  `capacity` longtext NOT NULL,
  `insurance_renewal` longtext NOT NULL,
  `driver_name` longtext NOT NULL,
  `driver_phone` longtext NOT NULL,
  `driver_license` longtext NOT NULL,
  `branch_id` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: visitor_log
#

DROP TABLE IF EXISTS `visitor_log`;

CREATE TABLE `visitor_log` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) DEFAULT NULL,
  `number` varchar(255) DEFAULT NULL,
  `purpose_id` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `entry_time` time DEFAULT NULL,
  `exit_time` time DEFAULT NULL,
  `number_of_visitor` float DEFAULT NULL,
  `id_number` varchar(255) DEFAULT NULL,
  `token_pass` varchar(255) DEFAULT NULL,
  `note` text CHARACTER SET utf8 COLLATE utf8_unicode_ci NOT NULL,
  `branch_id` int(11) NOT NULL,
  `created_by` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: visitor_purpose
#

DROP TABLE IF EXISTS `visitor_purpose`;

CREATE TABLE `visitor_purpose` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: voucher_head
#

DROP TABLE IF EXISTS `voucher_head`;

CREATE TABLE `voucher_head` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `type` varchar(20) NOT NULL,
  `system` tinyint(1) DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

#
# TABLE STRUCTURE FOR: whatsapp_agent
#

DROP TABLE IF EXISTS `whatsapp_agent`;

CREATE TABLE `whatsapp_agent` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `agent_name` varchar(255) NOT NULL,
  `agent_image` varchar(255) NOT NULL,
  `agent_designation` varchar(255) NOT NULL,
  `whataspp_number` varchar(255) NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `weekend` varchar(20) DEFAULT NULL,
  `enable` tinyint(1) NOT NULL DEFAULT 1,
  `branch_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `whatsapp_agent` (`id`, `agent_name`, `agent_image`, `agent_designation`, `whataspp_number`, `start_time`, `end_time`, `weekend`, `enable`, `branch_id`, `created_at`) VALUES (1, 'Elite Design', '65ede990ab4a4ce8426e059700917f31.png', 'CEO', '+8801775457008', '00:00:00', '12:00:00', '0', 1, 1, '2023-09-26 00:28:46');


#
# TABLE STRUCTURE FOR: whatsapp_chat
#

DROP TABLE IF EXISTS `whatsapp_chat`;

CREATE TABLE `whatsapp_chat` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `header_title` varchar(255) NOT NULL,
  `subtitle` varchar(355) DEFAULT NULL,
  `footer_text` varchar(255) DEFAULT NULL,
  `popup_message` varchar(255) DEFAULT NULL,
  `frontend_enable_chat` tinyint(1) NOT NULL DEFAULT 0,
  `backend_enable_chat` tinyint(1) NOT NULL DEFAULT 0,
  `branch_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

INSERT INTO `whatsapp_chat` (`id`, `header_title`, `subtitle`, `footer_text`, `popup_message`, `frontend_enable_chat`, `backend_enable_chat`, `branch_id`, `created_at`) VALUES (1, 'এলিট ডিজাইন', 'আমাদের সাথে কথা বলা শুরু করুন', 'আমি এই স্কুল ম্যানেজমেন্ট সফটওয়্যারটি নিতে চাচ্ছি', NULL, 1, 1, 1, '2022-02-16 13:49:13');
INSERT INTO `whatsapp_chat` (`id`, `header_title`, `subtitle`, `footer_text`, `popup_message`, `frontend_enable_chat`, `backend_enable_chat`, `branch_id`, `created_at`) VALUES (2, 'Conversation', 'Hi! Click one of our members below to chat on WhatsApp ;)', 'Use this feature to chat with our agent.', NULL, 1, 1, 2, '2022-02-16 13:49:13');


#
# TABLE STRUCTURE FOR: zoom_own_api
#

DROP TABLE IF EXISTS `zoom_own_api`;

CREATE TABLE `zoom_own_api` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_type` tinyint(1) NOT NULL,
  `user_id` int(11) NOT NULL,
  `zoom_api_key` varchar(255) NOT NULL,
  `zoom_api_secret` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

